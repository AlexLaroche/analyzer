typedef void (apr_opt_fn_t)(void);
void apr_dynamic_fn_register(const char *szName,
                                                  apr_opt_fn_t *pfn);
apr_opt_fn_t * apr_dynamic_fn_retrieve(const char *szName);

typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef long int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino_t ino_t;
typedef __ino64_t ino64_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off_t off_t;
typedef __off64_t off64_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;
typedef __clockid_t clockid_t;
typedef __time_t time_t;
typedef __timer_t timer_t;
typedef __useconds_t useconds_t;
typedef __suseconds_t suseconds_t;
typedef long unsigned int size_t;
typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef int register_t __attribute__ ((__mode__ (__word__)));
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{
  return __builtin_bswap16 (__bsx);
}
static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{
  return __builtin_bswap32 (__bsx);
}
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return __builtin_bswap64 (__bsx);
}
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}
static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}
static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
typedef __sigset_t sigset_t;
struct timeval
{
  __time_t tv_sec;
  __suseconds_t tv_usec;
};
struct timespec
{
  __time_t tv_sec;
  __syscall_slong_t tv_nsec;
};
typedef long int __fd_mask;
typedef struct
  {
    __fd_mask fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];
  } fd_set;
typedef __fd_mask fd_mask;

extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);

typedef __blksize_t blksize_t;
typedef __blkcnt_t blkcnt_t;
typedef __fsblkcnt_t fsblkcnt_t;
typedef __fsfilcnt_t fsfilcnt_t;
typedef __blkcnt64_t blkcnt64_t;
typedef __fsblkcnt64_t fsblkcnt64_t;
typedef __fsfilcnt64_t fsfilcnt64_t;
typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;
typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;
  unsigned int __nusers;
  int __kind;
  short __spins;
  short __elision;
  __pthread_list_t __list;
};
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  signed char __rwelision;
  unsigned char __pad1[7];
  unsigned long int __pad2;
  unsigned int __flags;
};
struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_refs[2] ;
  unsigned int __g_size[2];
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
};
typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;
typedef struct
{
  int __data ;
} __once_flag;
typedef unsigned long int pthread_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
union pthread_attr_t
{
  char __size[56];
  long int __align;
};
typedef union pthread_attr_t pthread_attr_t;
typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;
typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;
typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;
typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;
typedef volatile int pthread_spinlock_t;
typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;


struct iovec
  {
    void *iov_base;
    size_t iov_len;
  };
typedef __socklen_t socklen_t;
enum __socket_type
{
  SOCK_STREAM = 1,
  SOCK_DGRAM = 2,
  SOCK_RAW = 3,
  SOCK_RDM = 4,
  SOCK_SEQPACKET = 5,
  SOCK_DCCP = 6,
  SOCK_PACKET = 10,
  SOCK_CLOEXEC = 02000000,
  SOCK_NONBLOCK = 00004000
};
typedef unsigned short int sa_family_t;
struct sockaddr
  {
    sa_family_t sa_family;
    char sa_data[14];
  };
struct sockaddr_storage
  {
    sa_family_t ss_family;
    char __ss_padding[(128 - (sizeof (unsigned short int)) - sizeof (unsigned long int))];
    unsigned long int __ss_align;
  };
enum
  {
    MSG_OOB = 0x01,
    MSG_PEEK = 0x02,
    MSG_DONTROUTE = 0x04,
    MSG_TRYHARD = MSG_DONTROUTE,
    MSG_CTRUNC = 0x08,
    MSG_PROXY = 0x10,
    MSG_TRUNC = 0x20,
    MSG_DONTWAIT = 0x40,
    MSG_EOR = 0x80,
    MSG_WAITALL = 0x100,
    MSG_FIN = 0x200,
    MSG_SYN = 0x400,
    MSG_CONFIRM = 0x800,
    MSG_RST = 0x1000,
    MSG_ERRQUEUE = 0x2000,
    MSG_NOSIGNAL = 0x4000,
    MSG_MORE = 0x8000,
    MSG_WAITFORONE = 0x10000,
    MSG_BATCH = 0x40000,
    MSG_ZEROCOPY = 0x4000000,
    MSG_FASTOPEN = 0x20000000,
    MSG_CMSG_CLOEXEC = 0x40000000
  };
struct msghdr
  {
    void *msg_name;
    socklen_t msg_namelen;
    struct iovec *msg_iov;
    size_t msg_iovlen;
    void *msg_control;
    size_t msg_controllen;
    int msg_flags;
  };
struct cmsghdr
  {
    size_t cmsg_len;
    int cmsg_level;
    int cmsg_type;
    __extension__ unsigned char __cmsg_data [];
  };
extern struct cmsghdr *__cmsg_nxthdr (struct msghdr *__mhdr,
          struct cmsghdr *__cmsg) __attribute__ ((__nothrow__ , __leaf__));
enum
  {
    SCM_RIGHTS = 0x01
    , SCM_CREDENTIALS = 0x02
    , SCM_SECURITY = 0x03
    , SCM_PIDFD = 0x04
  };
struct ucred
{
  pid_t pid;
  uid_t uid;
  gid_t gid;
};
typedef struct {
 unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;
typedef void (*__kernel_sighandler_t)(int);
typedef int __kernel_key_t;
typedef int __kernel_mqd_t;
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;
typedef unsigned long __kernel_old_dev_t;
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_ino_t;
typedef unsigned int __kernel_mode_t;
typedef int __kernel_pid_t;
typedef int __kernel_ipc_pid_t;
typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;
typedef __kernel_long_t __kernel_suseconds_t;
typedef int __kernel_daddr_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;
typedef struct {
 int val[2];
} __kernel_fsid_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef __kernel_long_t __kernel_old_time_t;
typedef __kernel_long_t __kernel_time_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
struct linger
  {
    int l_onoff;
    int l_linger;
  };
struct osockaddr
{
  unsigned short int sa_family;
  unsigned char sa_data[14];
};
enum
{
  SHUT_RD = 0,
  SHUT_WR,
  SHUT_RDWR
};
typedef union { struct sockaddr *__restrict __sockaddr__; struct sockaddr_at *__restrict __sockaddr_at__; struct sockaddr_ax25 *__restrict __sockaddr_ax25__; struct sockaddr_dl *__restrict __sockaddr_dl__; struct sockaddr_eon *__restrict __sockaddr_eon__; struct sockaddr_in *__restrict __sockaddr_in__; struct sockaddr_in6 *__restrict __sockaddr_in6__; struct sockaddr_inarp *__restrict __sockaddr_inarp__; struct sockaddr_ipx *__restrict __sockaddr_ipx__; struct sockaddr_iso *__restrict __sockaddr_iso__; struct sockaddr_ns *__restrict __sockaddr_ns__; struct sockaddr_un *__restrict __sockaddr_un__; struct sockaddr_x25 *__restrict __sockaddr_x25__;
       } __SOCKADDR_ARG __attribute__ ((__transparent_union__));
typedef union { const struct sockaddr *__restrict __sockaddr__; const struct sockaddr_at *__restrict __sockaddr_at__; const struct sockaddr_ax25 *__restrict __sockaddr_ax25__; const struct sockaddr_dl *__restrict __sockaddr_dl__; const struct sockaddr_eon *__restrict __sockaddr_eon__; const struct sockaddr_in *__restrict __sockaddr_in__; const struct sockaddr_in6 *__restrict __sockaddr_in6__; const struct sockaddr_inarp *__restrict __sockaddr_inarp__; const struct sockaddr_ipx *__restrict __sockaddr_ipx__; const struct sockaddr_iso *__restrict __sockaddr_iso__; const struct sockaddr_ns *__restrict __sockaddr_ns__; const struct sockaddr_un *__restrict __sockaddr_un__; const struct sockaddr_x25 *__restrict __sockaddr_x25__;
       } __CONST_SOCKADDR_ARG __attribute__ ((__transparent_union__));
struct mmsghdr
  {
    struct msghdr msg_hdr;
    unsigned int msg_len;
  };
extern int socket (int __domain, int __type, int __protocol) __attribute__ ((__nothrow__ , __leaf__));
extern int socketpair (int __domain, int __type, int __protocol,
         int __fds[2]) __attribute__ ((__nothrow__ , __leaf__));
extern int bind (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len)
     __attribute__ ((__nothrow__ , __leaf__));
extern int getsockname (int __fd, __SOCKADDR_ARG __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ , __leaf__));
extern int connect (int __fd, __CONST_SOCKADDR_ARG __addr, socklen_t __len);
extern int getpeername (int __fd, __SOCKADDR_ARG __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ , __leaf__));
extern ssize_t send (int __fd, const void *__buf, size_t __n, int __flags);
extern ssize_t recv (int __fd, void *__buf, size_t __n, int __flags);
extern ssize_t sendto (int __fd, const void *__buf, size_t __n,
         int __flags, __CONST_SOCKADDR_ARG __addr,
         socklen_t __addr_len);
extern ssize_t recvfrom (int __fd, void *__restrict __buf, size_t __n,
    int __flags, __SOCKADDR_ARG __addr,
    socklen_t *__restrict __addr_len);
extern ssize_t sendmsg (int __fd, const struct msghdr *__message,
   int __flags);
extern int sendmmsg (int __fd, struct mmsghdr *__vmessages,
       unsigned int __vlen, int __flags);
extern ssize_t recvmsg (int __fd, struct msghdr *__message, int __flags);
extern int recvmmsg (int __fd, struct mmsghdr *__vmessages,
       unsigned int __vlen, int __flags,
       struct timespec *__tmo);
extern int getsockopt (int __fd, int __level, int __optname,
         void *__restrict __optval,
         socklen_t *__restrict __optlen) __attribute__ ((__nothrow__ , __leaf__));
extern int setsockopt (int __fd, int __level, int __optname,
         const void *__optval, socklen_t __optlen) __attribute__ ((__nothrow__ , __leaf__));
extern int listen (int __fd, int __n) __attribute__ ((__nothrow__ , __leaf__));
extern int accept (int __fd, __SOCKADDR_ARG __addr,
     socklen_t *__restrict __addr_len);
extern int accept4 (int __fd, __SOCKADDR_ARG __addr,
      socklen_t *__restrict __addr_len, int __flags);
extern int shutdown (int __fd, int __how) __attribute__ ((__nothrow__ , __leaf__));
extern int sockatmark (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern int isfdtype (int __fd, int __fdtype) __attribute__ ((__nothrow__ , __leaf__));

typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
typedef int __gwchar_t;

typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));
extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ , __leaf__));
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
extern intmax_t strtoimax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoimax") __attribute__ ((__nothrow__ , __leaf__));
extern uintmax_t strtoumax (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoumax") __attribute__ ((__nothrow__ , __leaf__));
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoimax") __attribute__ ((__nothrow__ , __leaf__));
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr, __gwchar_t **__restrict __endptr, int __base) __asm__ ("" "__isoc23_wcstoumax") __attribute__ ((__nothrow__ , __leaf__));



typedef __sig_atomic_t sig_atomic_t;
union sigval
{
  int sival_int;
  void *sival_ptr;
};
typedef union sigval __sigval_t;
typedef struct
  {
    int si_signo;
    int si_errno;
    int si_code;
    int __pad0;
    union
      {
 int _pad[((128 / sizeof (int)) - 4)];
 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
   } _kill;
 struct
   {
     int si_tid;
     int si_overrun;
     __sigval_t si_sigval;
   } _timer;
 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     __sigval_t si_sigval;
   } _rt;
 struct
   {
     __pid_t si_pid;
     __uid_t si_uid;
     int si_status;
     __clock_t si_utime;
     __clock_t si_stime;
   } _sigchld;
 struct
   {
     void *si_addr;
    
     short int si_addr_lsb;
     union
       {
  struct
    {
      void *_lower;
      void *_upper;
    } _addr_bnd;
  __uint32_t _pkey;
       } _bounds;
   } _sigfault;
 struct
   {
     long int si_band;
     int si_fd;
   } _sigpoll;
 struct
   {
     void *_call_addr;
     int _syscall;
     unsigned int _arch;
   } _sigsys;
      } _sifields;
  } siginfo_t ;
enum
{
  SI_ASYNCNL = -60,
  SI_DETHREAD = -7,
  SI_TKILL,
  SI_SIGIO,
  SI_ASYNCIO,
  SI_MESGQ,
  SI_TIMER,
  SI_QUEUE,
  SI_USER,
  SI_KERNEL = 0x80
};
enum
{
  ILL_ILLOPC = 1,
  ILL_ILLOPN,
  ILL_ILLADR,
  ILL_ILLTRP,
  ILL_PRVOPC,
  ILL_PRVREG,
  ILL_COPROC,
  ILL_BADSTK,
  ILL_BADIADDR
};
enum
{
  FPE_INTDIV = 1,
  FPE_INTOVF,
  FPE_FLTDIV,
  FPE_FLTOVF,
  FPE_FLTUND,
  FPE_FLTRES,
  FPE_FLTINV,
  FPE_FLTSUB,
  FPE_FLTUNK = 14,
  FPE_CONDTRAP
};
enum
{
  SEGV_MAPERR = 1,
  SEGV_ACCERR,
  SEGV_BNDERR,
  SEGV_PKUERR,
  SEGV_ACCADI,
  SEGV_ADIDERR,
  SEGV_ADIPERR,
  SEGV_MTEAERR,
  SEGV_MTESERR,
  SEGV_CPERR
};
enum
{
  BUS_ADRALN = 1,
  BUS_ADRERR,
  BUS_OBJERR,
  BUS_MCEERR_AR,
  BUS_MCEERR_AO
};
enum
{
  TRAP_BRKPT = 1,
  TRAP_TRACE,
  TRAP_BRANCH,
  TRAP_HWBKPT,
  TRAP_UNK
};
enum
{
  CLD_EXITED = 1,
  CLD_KILLED,
  CLD_DUMPED,
  CLD_TRAPPED,
  CLD_STOPPED,
  CLD_CONTINUED
};
enum
{
  POLL_IN = 1,
  POLL_OUT,
  POLL_MSG,
  POLL_ERR,
  POLL_PRI,
  POLL_HUP
};
typedef __sigval_t sigval_t;
typedef struct sigevent
  {
    __sigval_t sigev_value;
    int sigev_signo;
    int sigev_notify;
    union
      {
 int _pad[((64 / sizeof (int)) - 4)];
 __pid_t _tid;
 struct
   {
     void (*_function) (__sigval_t);
     pthread_attr_t *_attribute;
   } _sigev_thread;
      } _sigev_un;
  } sigevent_t;
enum
{
  SIGEV_SIGNAL = 0,
  SIGEV_NONE,
  SIGEV_THREAD,
  SIGEV_THREAD_ID = 4
};
typedef void (*__sighandler_t) (int);
extern __sighandler_t __sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
extern __sighandler_t sysv_signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
extern __sighandler_t signal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
extern int kill (__pid_t __pid, int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern int killpg (__pid_t __pgrp, int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern int raise (int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern __sighandler_t ssignal (int __sig, __sighandler_t __handler)
     __attribute__ ((__nothrow__ , __leaf__));
extern int gsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern void psignal (int __sig, const char *__s);
extern void psiginfo (const siginfo_t *__pinfo, const char *__s);
extern int sigpause (int __sig) __asm__ ("__xpg_sigpause")
  __attribute__ ((__deprecated__ ("Use the sigsuspend function instead")));
extern int sigblock (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int sigsetmask (int __mask) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int siggetmask (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
typedef __sighandler_t sighandler_t;
typedef __sighandler_t sig_t;
extern int sigemptyset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigfillset (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigaddset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigdelset (sigset_t *__set, int __signo) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigismember (const sigset_t *__set, int __signo)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigisemptyset (const sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigandset (sigset_t *__set, const sigset_t *__left,
        const sigset_t *__right) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int sigorset (sigset_t *__set, const sigset_t *__left,
       const sigset_t *__right) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3)));
struct sigaction
  {
    union
      {
 __sighandler_t sa_handler;
 void (*sa_sigaction) (int, siginfo_t *, void *);
      }
    __sigaction_handler;
    __sigset_t sa_mask;
    int sa_flags;
    void (*sa_restorer) (void);
  };
extern int sigprocmask (int __how, const sigset_t *__restrict __set,
   sigset_t *__restrict __oset) __attribute__ ((__nothrow__ , __leaf__));
extern int sigsuspend (const sigset_t *__set) __attribute__ ((__nonnull__ (1)));
extern int sigaction (int __sig, const struct sigaction *__restrict __act,
        struct sigaction *__restrict __oact) __attribute__ ((__nothrow__ , __leaf__));
extern int sigpending (sigset_t *__set) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sigwait (const sigset_t *__restrict __set, int *__restrict __sig)
     __attribute__ ((__nonnull__ (1, 2)));
extern int sigwaitinfo (const sigset_t *__restrict __set,
   siginfo_t *__restrict __info) __attribute__ ((__nonnull__ (1)));
extern int sigtimedwait (const sigset_t *__restrict __set,
    siginfo_t *__restrict __info,
    const struct timespec *__restrict __timeout)
     __attribute__ ((__nonnull__ (1)));
extern int sigqueue (__pid_t __pid, int __sig, const union sigval __val)
     __attribute__ ((__nothrow__ , __leaf__));
struct _fpx_sw_bytes
{
  __uint32_t magic1;
  __uint32_t extended_size;
  __uint64_t xstate_bv;
  __uint32_t xstate_size;
  __uint32_t __glibc_reserved1[7];
};
struct _fpreg
{
  unsigned short significand[4];
  unsigned short exponent;
};
struct _fpxreg
{
  unsigned short significand[4];
  unsigned short exponent;
  unsigned short __glibc_reserved1[3];
};
struct _xmmreg
{
  __uint32_t element[4];
};
struct _fpstate
{
  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _fpxreg _st[8];
  struct _xmmreg _xmm[16];
  __uint32_t __glibc_reserved1[24];
};
struct sigcontext
{
  __uint64_t r8;
  __uint64_t r9;
  __uint64_t r10;
  __uint64_t r11;
  __uint64_t r12;
  __uint64_t r13;
  __uint64_t r14;
  __uint64_t r15;
  __uint64_t rdi;
  __uint64_t rsi;
  __uint64_t rbp;
  __uint64_t rbx;
  __uint64_t rdx;
  __uint64_t rax;
  __uint64_t rcx;
  __uint64_t rsp;
  __uint64_t rip;
  __uint64_t eflags;
  unsigned short cs;
  unsigned short gs;
  unsigned short fs;
  unsigned short __pad0;
  __uint64_t err;
  __uint64_t trapno;
  __uint64_t oldmask;
  __uint64_t cr2;
  __extension__ union
    {
      struct _fpstate * fpstate;
      __uint64_t __fpstate_word;
    };
  __uint64_t __reserved1 [8];
};
struct _xsave_hdr
{
  __uint64_t xstate_bv;
  __uint64_t __glibc_reserved1[2];
  __uint64_t __glibc_reserved2[5];
};
struct _ymmh_state
{
  __uint32_t ymmh_space[64];
};
struct _xstate
{
  struct _fpstate fpstate;
  struct _xsave_hdr xstate_hdr;
  struct _ymmh_state ymmh;
};
extern int sigreturn (struct sigcontext *__scp) __attribute__ ((__nothrow__ , __leaf__));
typedef struct
  {
    void *ss_sp;
    int ss_flags;
    size_t ss_size;
  } stack_t;
__extension__ typedef long long int greg_t;
typedef greg_t gregset_t[23];
enum
{
  REG_R8 = 0,
  REG_R9,
  REG_R10,
  REG_R11,
  REG_R12,
  REG_R13,
  REG_R14,
  REG_R15,
  REG_RDI,
  REG_RSI,
  REG_RBP,
  REG_RBX,
  REG_RDX,
  REG_RAX,
  REG_RCX,
  REG_RSP,
  REG_RIP,
  REG_EFL,
  REG_CSGSFS,
  REG_ERR,
  REG_TRAPNO,
  REG_OLDMASK,
  REG_CR2
};
struct _libc_fpxreg
{
  unsigned short int significand[4];
  unsigned short int exponent;
  unsigned short int __glibc_reserved1[3];
};
struct _libc_xmmreg
{
  __uint32_t element[4];
};
struct _libc_fpstate
{
  __uint16_t cwd;
  __uint16_t swd;
  __uint16_t ftw;
  __uint16_t fop;
  __uint64_t rip;
  __uint64_t rdp;
  __uint32_t mxcsr;
  __uint32_t mxcr_mask;
  struct _libc_fpxreg _st[8];
  struct _libc_xmmreg _xmm[16];
  __uint32_t __glibc_reserved1[24];
};
typedef struct _libc_fpstate *fpregset_t;
typedef struct
  {
    gregset_t gregs;
    fpregset_t fpregs;
    __extension__ unsigned long long __reserved1 [8];
} mcontext_t;
typedef struct ucontext_t
  {
    unsigned long int uc_flags;
    struct ucontext_t *uc_link;
    stack_t uc_stack;
    mcontext_t uc_mcontext;
    sigset_t uc_sigmask;
    struct _libc_fpstate __fpregs_mem;
    __extension__ unsigned long long int __ssp[4];
  } ucontext_t;
extern int siginterrupt (int __sig, int __interrupt) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("Use sigaction with SA_RESTART instead")));

extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int euidaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int eaccess (const char *__name, int __type)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int execveat (int __fd, const char *__path, char *const __argv[],
                     char *const __envp[], int __flags)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ , __leaf__));
extern __off64_t lseek64 (int __fd, __off64_t __offset, int __whence)
     __attribute__ ((__nothrow__ , __leaf__));
extern int close (int __fd);
extern void closefrom (int __lowfd) __attribute__ ((__nothrow__ , __leaf__));
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern ssize_t write (int __fd, const void *__buf, size_t __n)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pread64 (int __fd, void *__buf, size_t __nbytes,
   __off64_t __offset)
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern ssize_t pwrite64 (int __fd, const void *__buf, size_t __n,
    __off64_t __offset)
    __attribute__ ((__access__ (__read_only__, 2, 3)));
extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int pipe2 (int __pipedes[2], int __flags) __attribute__ ((__nothrow__ , __leaf__)) ;
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned int sleep (unsigned int __seconds);
extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ , __leaf__));
extern int usleep (__useconds_t __useconds);
extern int pause (void);
extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) ;
extern int chdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int fchdir (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ , __leaf__)) ;
extern char *get_current_dir_name (void) __attribute__ ((__nothrow__ , __leaf__));
extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__))
    __attribute__ ((__access__ (__write_only__, 1)));
extern int dup (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ , __leaf__));
extern int dup3 (int __fd, int __fd2, int __flags) __attribute__ ((__nothrow__ , __leaf__));
extern char **__environ;
extern char **environ;
extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int execvpe (const char *__file, char *const __argv[],
      char *const __envp[])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nice (int __inc) __attribute__ ((__nothrow__ , __leaf__)) ;
extern void _exit (int __status) __attribute__ ((__noreturn__));
enum
  {
    _PC_LINK_MAX,
    _PC_MAX_CANON,
    _PC_MAX_INPUT,
    _PC_NAME_MAX,
    _PC_PATH_MAX,
    _PC_PIPE_BUF,
    _PC_CHOWN_RESTRICTED,
    _PC_NO_TRUNC,
    _PC_VDISABLE,
    _PC_SYNC_IO,
    _PC_ASYNC_IO,
    _PC_PRIO_IO,
    _PC_SOCK_MAXBUF,
    _PC_FILESIZEBITS,
    _PC_REC_INCR_XFER_SIZE,
    _PC_REC_MAX_XFER_SIZE,
    _PC_REC_MIN_XFER_SIZE,
    _PC_REC_XFER_ALIGN,
    _PC_ALLOC_SIZE_MIN,
    _PC_SYMLINK_MAX,
    _PC_2_SYMLINKS
  };
enum
  {
    _SC_ARG_MAX,
    _SC_CHILD_MAX,
    _SC_CLK_TCK,
    _SC_NGROUPS_MAX,
    _SC_OPEN_MAX,
    _SC_STREAM_MAX,
    _SC_TZNAME_MAX,
    _SC_JOB_CONTROL,
    _SC_SAVED_IDS,
    _SC_REALTIME_SIGNALS,
    _SC_PRIORITY_SCHEDULING,
    _SC_TIMERS,
    _SC_ASYNCHRONOUS_IO,
    _SC_PRIORITIZED_IO,
    _SC_SYNCHRONIZED_IO,
    _SC_FSYNC,
    _SC_MAPPED_FILES,
    _SC_MEMLOCK,
    _SC_MEMLOCK_RANGE,
    _SC_MEMORY_PROTECTION,
    _SC_MESSAGE_PASSING,
    _SC_SEMAPHORES,
    _SC_SHARED_MEMORY_OBJECTS,
    _SC_AIO_LISTIO_MAX,
    _SC_AIO_MAX,
    _SC_AIO_PRIO_DELTA_MAX,
    _SC_DELAYTIMER_MAX,
    _SC_MQ_OPEN_MAX,
    _SC_MQ_PRIO_MAX,
    _SC_VERSION,
    _SC_PAGESIZE,
    _SC_RTSIG_MAX,
    _SC_SEM_NSEMS_MAX,
    _SC_SEM_VALUE_MAX,
    _SC_SIGQUEUE_MAX,
    _SC_TIMER_MAX,
    _SC_BC_BASE_MAX,
    _SC_BC_DIM_MAX,
    _SC_BC_SCALE_MAX,
    _SC_BC_STRING_MAX,
    _SC_COLL_WEIGHTS_MAX,
    _SC_EQUIV_CLASS_MAX,
    _SC_EXPR_NEST_MAX,
    _SC_LINE_MAX,
    _SC_RE_DUP_MAX,
    _SC_CHARCLASS_NAME_MAX,
    _SC_2_VERSION,
    _SC_2_C_BIND,
    _SC_2_C_DEV,
    _SC_2_FORT_DEV,
    _SC_2_FORT_RUN,
    _SC_2_SW_DEV,
    _SC_2_LOCALEDEF,
    _SC_PII,
    _SC_PII_XTI,
    _SC_PII_SOCKET,
    _SC_PII_INTERNET,
    _SC_PII_OSI,
    _SC_POLL,
    _SC_SELECT,
    _SC_UIO_MAXIOV,
    _SC_IOV_MAX = _SC_UIO_MAXIOV,
    _SC_PII_INTERNET_STREAM,
    _SC_PII_INTERNET_DGRAM,
    _SC_PII_OSI_COTS,
    _SC_PII_OSI_CLTS,
    _SC_PII_OSI_M,
    _SC_T_IOV_MAX,
    _SC_THREADS,
    _SC_THREAD_SAFE_FUNCTIONS,
    _SC_GETGR_R_SIZE_MAX,
    _SC_GETPW_R_SIZE_MAX,
    _SC_LOGIN_NAME_MAX,
    _SC_TTY_NAME_MAX,
    _SC_THREAD_DESTRUCTOR_ITERATIONS,
    _SC_THREAD_KEYS_MAX,
    _SC_THREAD_STACK_MIN,
    _SC_THREAD_THREADS_MAX,
    _SC_THREAD_ATTR_STACKADDR,
    _SC_THREAD_ATTR_STACKSIZE,
    _SC_THREAD_PRIORITY_SCHEDULING,
    _SC_THREAD_PRIO_INHERIT,
    _SC_THREAD_PRIO_PROTECT,
    _SC_THREAD_PROCESS_SHARED,
    _SC_NPROCESSORS_CONF,
    _SC_NPROCESSORS_ONLN,
    _SC_PHYS_PAGES,
    _SC_AVPHYS_PAGES,
    _SC_ATEXIT_MAX,
    _SC_PASS_MAX,
    _SC_XOPEN_VERSION,
    _SC_XOPEN_XCU_VERSION,
    _SC_XOPEN_UNIX,
    _SC_XOPEN_CRYPT,
    _SC_XOPEN_ENH_I18N,
    _SC_XOPEN_SHM,
    _SC_2_CHAR_TERM,
    _SC_2_C_VERSION,
    _SC_2_UPE,
    _SC_XOPEN_XPG2,
    _SC_XOPEN_XPG3,
    _SC_XOPEN_XPG4,
    _SC_CHAR_BIT,
    _SC_CHAR_MAX,
    _SC_CHAR_MIN,
    _SC_INT_MAX,
    _SC_INT_MIN,
    _SC_LONG_BIT,
    _SC_WORD_BIT,
    _SC_MB_LEN_MAX,
    _SC_NZERO,
    _SC_SSIZE_MAX,
    _SC_SCHAR_MAX,
    _SC_SCHAR_MIN,
    _SC_SHRT_MAX,
    _SC_SHRT_MIN,
    _SC_UCHAR_MAX,
    _SC_UINT_MAX,
    _SC_ULONG_MAX,
    _SC_USHRT_MAX,
    _SC_NL_ARGMAX,
    _SC_NL_LANGMAX,
    _SC_NL_MSGMAX,
    _SC_NL_NMAX,
    _SC_NL_SETMAX,
    _SC_NL_TEXTMAX,
    _SC_XBS5_ILP32_OFF32,
    _SC_XBS5_ILP32_OFFBIG,
    _SC_XBS5_LP64_OFF64,
    _SC_XBS5_LPBIG_OFFBIG,
    _SC_XOPEN_LEGACY,
    _SC_XOPEN_REALTIME,
    _SC_XOPEN_REALTIME_THREADS,
    _SC_ADVISORY_INFO,
    _SC_BARRIERS,
    _SC_BASE,
    _SC_C_LANG_SUPPORT,
    _SC_C_LANG_SUPPORT_R,
    _SC_CLOCK_SELECTION,
    _SC_CPUTIME,
    _SC_THREAD_CPUTIME,
    _SC_DEVICE_IO,
    _SC_DEVICE_SPECIFIC,
    _SC_DEVICE_SPECIFIC_R,
    _SC_FD_MGMT,
    _SC_FIFO,
    _SC_PIPE,
    _SC_FILE_ATTRIBUTES,
    _SC_FILE_LOCKING,
    _SC_FILE_SYSTEM,
    _SC_MONOTONIC_CLOCK,
    _SC_MULTI_PROCESS,
    _SC_SINGLE_PROCESS,
    _SC_NETWORKING,
    _SC_READER_WRITER_LOCKS,
    _SC_SPIN_LOCKS,
    _SC_REGEXP,
    _SC_REGEX_VERSION,
    _SC_SHELL,
    _SC_SIGNALS,
    _SC_SPAWN,
    _SC_SPORADIC_SERVER,
    _SC_THREAD_SPORADIC_SERVER,
    _SC_SYSTEM_DATABASE,
    _SC_SYSTEM_DATABASE_R,
    _SC_TIMEOUTS,
    _SC_TYPED_MEMORY_OBJECTS,
    _SC_USER_GROUPS,
    _SC_USER_GROUPS_R,
    _SC_2_PBS,
    _SC_2_PBS_ACCOUNTING,
    _SC_2_PBS_LOCATE,
    _SC_2_PBS_MESSAGE,
    _SC_2_PBS_TRACK,
    _SC_SYMLOOP_MAX,
    _SC_STREAMS,
    _SC_2_PBS_CHECKPOINT,
    _SC_V6_ILP32_OFF32,
    _SC_V6_ILP32_OFFBIG,
    _SC_V6_LP64_OFF64,
    _SC_V6_LPBIG_OFFBIG,
    _SC_HOST_NAME_MAX,
    _SC_TRACE,
    _SC_TRACE_EVENT_FILTER,
    _SC_TRACE_INHERIT,
    _SC_TRACE_LOG,
    _SC_LEVEL1_ICACHE_SIZE,
    _SC_LEVEL1_ICACHE_ASSOC,
    _SC_LEVEL1_ICACHE_LINESIZE,
    _SC_LEVEL1_DCACHE_SIZE,
    _SC_LEVEL1_DCACHE_ASSOC,
    _SC_LEVEL1_DCACHE_LINESIZE,
    _SC_LEVEL2_CACHE_SIZE,
    _SC_LEVEL2_CACHE_ASSOC,
    _SC_LEVEL2_CACHE_LINESIZE,
    _SC_LEVEL3_CACHE_SIZE,
    _SC_LEVEL3_CACHE_ASSOC,
    _SC_LEVEL3_CACHE_LINESIZE,
    _SC_LEVEL4_CACHE_SIZE,
    _SC_LEVEL4_CACHE_ASSOC,
    _SC_LEVEL4_CACHE_LINESIZE,
    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,
    _SC_RAW_SOCKETS,
    _SC_V7_ILP32_OFF32,
    _SC_V7_ILP32_OFFBIG,
    _SC_V7_LP64_OFF64,
    _SC_V7_LPBIG_OFFBIG,
    _SC_SS_REPL_MAX,
    _SC_TRACE_EVENT_NAME_MAX,
    _SC_TRACE_NAME_MAX,
    _SC_TRACE_SYS_MAX,
    _SC_TRACE_USER_EVENT_MAX,
    _SC_XOPEN_STREAMS,
    _SC_THREAD_ROBUST_PRIO_INHERIT,
    _SC_THREAD_ROBUST_PRIO_PROTECT,
    _SC_MINSIGSTKSZ,
    _SC_SIGSTKSZ
  };
enum
  {
    _CS_PATH,
    _CS_V6_WIDTH_RESTRICTED_ENVS,
    _CS_GNU_LIBC_VERSION,
    _CS_GNU_LIBPTHREAD_VERSION,
    _CS_V5_WIDTH_RESTRICTED_ENVS,
    _CS_V7_WIDTH_RESTRICTED_ENVS,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS,
    _CS_LFS_LIBS,
    _CS_LFS_LINTFLAGS,
    _CS_LFS64_CFLAGS,
    _CS_LFS64_LDFLAGS,
    _CS_LFS64_LIBS,
    _CS_LFS64_LINTFLAGS,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS,
    _CS_XBS5_ILP32_OFF32_LIBS,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LIBS,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,
    _CS_XBS5_LP64_OFF64_CFLAGS,
    _CS_XBS5_LP64_OFF64_LDFLAGS,
    _CS_XBS5_LP64_OFF64_LIBS,
    _CS_XBS5_LP64_OFF64_LINTFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LIBS,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LIBS,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LIBS,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LIBS,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LIBS,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,
    _CS_V6_ENV,
    _CS_V7_ENV
  };
extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ , __leaf__));
extern long int sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));
extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
extern __pid_t getpid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t getppid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));
extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ , __leaf__));
extern int setpgrp (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t setsid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));
extern __uid_t getuid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __uid_t geteuid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __gid_t getgid (void) __attribute__ ((__nothrow__ , __leaf__));
extern __gid_t getegid (void) __attribute__ ((__nothrow__ , __leaf__));
extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__write_only__, 2, 1)));
extern int group_member (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__));
extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int getresuid (__uid_t *__ruid, __uid_t *__euid, __uid_t *__suid)
     __attribute__ ((__nothrow__ , __leaf__));
extern int getresgid (__gid_t *__rgid, __gid_t *__egid, __gid_t *__sgid)
     __attribute__ ((__nothrow__ , __leaf__));
extern int setresuid (__uid_t __ruid, __uid_t __euid, __uid_t __suid)
     __attribute__ ((__nothrow__ , __leaf__)) ;
extern int setresgid (__gid_t __rgid, __gid_t __egid, __gid_t __sgid)
     __attribute__ ((__nothrow__ , __leaf__)) ;
extern __pid_t fork (void) __attribute__ ((__nothrow__));
extern __pid_t vfork (void) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t _Fork (void) __attribute__ ((__nothrow__ , __leaf__));
extern char *ttyname (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int isatty (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern int ttyslot (void) __attribute__ ((__nothrow__ , __leaf__));
extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;
extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4))) ;
extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) ;
extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
     __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3))) ;
extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)))
     __attribute__ ((__access__ (__write_only__, 3, 4)));
extern int unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int rmdir (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ , __leaf__));
extern char *getlogin (void);
extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int setlogin (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

extern char *optarg;
extern int optind;
extern int opterr;
extern int optopt;
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));



extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__read_only__, 1, 2)));
extern int sethostid (long int __id) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
     __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__access__ (__read_only__, 1, 2)));
extern int vhangup (void) __attribute__ ((__nothrow__ , __leaf__));
extern int revoke (const char *__file) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int acct (const char *__name) __attribute__ ((__nothrow__ , __leaf__));
extern char *getusershell (void) __attribute__ ((__nothrow__ , __leaf__));
extern void endusershell (void) __attribute__ ((__nothrow__ , __leaf__));
extern void setusershell (void) __attribute__ ((__nothrow__ , __leaf__));
extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int chroot (const char *__path) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));
extern int fsync (int __fd);
extern int syncfs (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern long int gethostid (void);
extern void sync (void) __attribute__ ((__nothrow__ , __leaf__));
extern int getpagesize (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int getdtablesize (void) __attribute__ ((__nothrow__ , __leaf__));
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int truncate64 (const char *__file, __off64_t __length)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int ftruncate64 (int __fd, __off64_t __length) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int brk (void *__addr) __attribute__ ((__nothrow__ , __leaf__)) ;
extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ , __leaf__));
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ , __leaf__));
extern int lockf (int __fd, int __cmd, __off_t __len) ;
extern int lockf64 (int __fd, int __cmd, __off64_t __len) ;
ssize_t copy_file_range (int __infd, __off64_t *__pinoff,
    int __outfd, __off64_t *__poutoff,
    size_t __length, unsigned int __flags);
extern int fdatasync (int __fildes);
extern char *crypt (const char *__key, const char *__salt)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void swab (const void *__restrict __from, void *__restrict __to,
    ssize_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)))
    __attribute__ ((__access__ (__read_only__, 1, 3)))
    __attribute__ ((__access__ (__write_only__, 2, 3)));
int getentropy (void *__buffer, size_t __length)
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern int close_range (unsigned int __fd, unsigned int __max_fd,
   int __flags) __attribute__ ((__nothrow__ , __leaf__));
extern __pid_t gettid (void) __attribute__ ((__nothrow__ , __leaf__));

enum
{
  SS_ONSTACK = 1,
  SS_DISABLE
};
extern int sigaltstack (const stack_t *__restrict __ss,
   stack_t *__restrict __oss) __attribute__ ((__nothrow__ , __leaf__));
struct sigstack
  {
    void *ss_sp;
    int ss_onstack;
  };
extern int sigstack (struct sigstack *__ss, struct sigstack *__oss)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int sighold (int __sig) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("Use the sigprocmask function instead")));
extern int sigrelse (int __sig) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("Use the sigprocmask function instead")));
extern int sigignore (int __sig) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("Use the signal function instead")));
extern __sighandler_t sigset (int __sig, __sighandler_t __disp) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("Use the signal and sigprocmask functions instead")));
extern int pthread_sigmask (int __how,
       const __sigset_t *__restrict __newmask,
       __sigset_t *__restrict __oldmask)__attribute__ ((__nothrow__ , __leaf__));
extern int pthread_kill (pthread_t __threadid, int __signo) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_sigqueue (pthread_t __threadid, int __signo,
        const union sigval __value) __attribute__ ((__nothrow__ , __leaf__));
extern int __libc_current_sigrtmin (void) __attribute__ ((__nothrow__ , __leaf__));
extern int __libc_current_sigrtmax (void) __attribute__ ((__nothrow__ , __leaf__));
extern int tgkill (__pid_t __tgid, __pid_t __tid, int __signal);

typedef enum
{
  P_ALL,
  P_PID,
  P_PGID,
  P_PIDFD,
} idtype_t;
extern __pid_t wait (int *__stat_loc);
extern __pid_t waitpid (__pid_t __pid, int *__stat_loc, int __options);
extern int waitid (idtype_t __idtype, __id_t __id, siginfo_t *__infop,
     int __options);
struct rusage;
extern __pid_t wait3 (int *__stat_loc, int __options,
        struct rusage * __usage) __attribute__ ((__nothrow__));
extern __pid_t wait4 (__pid_t __pid, int *__stat_loc, int __options,
        struct rusage *__usage) __attribute__ ((__nothrow__));


extern long int __sysconf (int __name) __attribute__ ((__nothrow__ , __leaf__));

typedef unsigned char apr_byte_t;
typedef short apr_int16_t;
typedef unsigned short apr_uint16_t;
typedef int apr_int32_t;
typedef unsigned int apr_uint32_t;
 typedef int64_t apr_int64_t;
 typedef uint64_t apr_uint64_t;
typedef size_t apr_size_t;
typedef ssize_t apr_ssize_t;
typedef off_t apr_off_t;
typedef socklen_t apr_socklen_t;
typedef ino_t apr_ino_t;
typedef apr_uint64_t apr_uintptr_t;

extern int *__errno_location (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern char *program_invocation_name;
extern char *program_invocation_short_name;
typedef int error_t;

typedef int apr_status_t;
char * apr_strerror(apr_status_t statcode, char *buf,
                                 apr_size_t bufsize);
typedef int apr_signum_t;
apr_status_t apr_initialize(void);
apr_status_t apr_app_initialize(int *argc,
                                             char const * const * *argv,
                                             char const * const * *env);
void apr_terminate(void);
void apr_terminate2(void);
apr_status_t apr_generate_random_bytes(unsigned char * buf,
                                                    apr_size_t length);

extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 4)));
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern void *rawmemchr (const void *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern void *memrchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)))
      __attribute__ ((__access__ (__read_only__, 1, 3)));
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 1, 3)));
struct __locale_struct
{
  struct __locale_data *__locales[13];
  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;
  const char *__names[13];
};
typedef struct __locale_struct *__locale_t;
typedef __locale_t locale_t;
extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)))
     __attribute__ ((__access__ (__write_only__, 1, 3)));
extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
    __attribute__ ((__access__ (__read_only__, 1, 2)))
    __attribute__ ((__access__ (__read_only__, 3, 4)));
extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ , __leaf__));
extern char *strerror_r (int __errnum, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern const char *strerrordesc_np (int __err) __attribute__ ((__nothrow__ , __leaf__));
extern const char *strerrorname_np (int __err) __attribute__ ((__nothrow__ , __leaf__));
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ , __leaf__));

extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern int ffs (int __i) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int ffsl (long int __l) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));

extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__write_only__, 1, 2)));
extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern const char *sigabbrev_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern const char *sigdescr_np (int __sig) __attribute__ ((__nothrow__ , __leaf__));
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__write_only__, 1, 3)));
extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__access__ (__read_write__, 1, 3)));
extern int strverscmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strfry (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void *memfrob (void *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
    __attribute__ ((__access__ (__read_write__, 1, 2)));
extern char *basename (const char *__filename) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

typedef struct apr_pool_t apr_pool_t;
typedef int (*apr_abortfunc_t)(int retcode);
apr_status_t apr_pool_initialize(void);
void apr_pool_terminate(void);
typedef struct apr_allocator_t apr_allocator_t;
typedef struct apr_memnode_t apr_memnode_t;
struct apr_memnode_t {
    apr_memnode_t *next;
    apr_memnode_t **ref;
    apr_uint32_t index;
    apr_uint32_t free_index;
    char *first_avail;
    char *endp;
};
apr_status_t apr_allocator_create(apr_allocator_t **allocator)
                          __attribute__((nonnull(1)));
void apr_allocator_destroy(apr_allocator_t *allocator)
                  __attribute__((nonnull(1)));
apr_memnode_t * apr_allocator_alloc(apr_allocator_t *allocator,
                                                 apr_size_t size)
                             __attribute__((nonnull(1)));
void apr_allocator_free(apr_allocator_t *allocator,
                                     apr_memnode_t *memnode)
                  __attribute__((nonnull(1,2)));
apr_size_t apr_allocator_align(apr_allocator_t *allocator,
                                            apr_size_t size);
void apr_allocator_owner_set(apr_allocator_t *allocator,
                                          apr_pool_t *pool)
                  __attribute__((nonnull(1)));
apr_pool_t * apr_allocator_owner_get(apr_allocator_t *allocator)
                          __attribute__((nonnull(1)));
void apr_allocator_max_free_set(apr_allocator_t *allocator,
                                             apr_size_t size)
                  __attribute__((nonnull(1)));
typedef struct apr_thread_mutex_t apr_thread_mutex_t;
 extern const char apr_month_snames[12][4];
 extern const char apr_day_snames[7][4];
typedef apr_int64_t apr_time_t;
typedef apr_int64_t apr_interval_time_t;
typedef apr_int32_t apr_short_interval_time_t;
apr_time_t apr_time_now(void);
typedef struct apr_time_exp_t apr_time_exp_t;
struct apr_time_exp_t {
    apr_int32_t tm_usec;
    apr_int32_t tm_sec;
    apr_int32_t tm_min;
    apr_int32_t tm_hour;
    apr_int32_t tm_mday;
    apr_int32_t tm_mon;
    apr_int32_t tm_year;
    apr_int32_t tm_wday;
    apr_int32_t tm_yday;
    apr_int32_t tm_isdst;
    apr_int32_t tm_gmtoff;
};
apr_status_t apr_time_ansi_put(apr_time_t *result,
                                                    time_t input);
apr_status_t apr_time_exp_tz(apr_time_exp_t *result,
                                          apr_time_t input,
                                          apr_int32_t offs);
apr_status_t apr_time_exp_gmt(apr_time_exp_t *result,
                                           apr_time_t input);
apr_status_t apr_time_exp_lt(apr_time_exp_t *result,
                                          apr_time_t input);
apr_status_t apr_time_exp_get(apr_time_t *result,
                                           apr_time_exp_t *input);
apr_status_t apr_time_exp_gmt_get(apr_time_t *result,
                                               apr_time_exp_t *input);
void apr_sleep(apr_interval_time_t t);
apr_status_t apr_rfc822_date(char *date_str, apr_time_t t);
apr_status_t apr_ctime(char *date_str, apr_time_t t);
apr_status_t apr_strftime(char *s, apr_size_t *retsize,
                                       apr_size_t max, const char *format,
                                       apr_time_exp_t *tm);
void apr_time_clock_hires(apr_pool_t *p);
apr_status_t apr_thread_mutex_create(apr_thread_mutex_t **mutex,
                                                  unsigned int flags,
                                                  apr_pool_t *pool);
apr_status_t apr_thread_mutex_lock(apr_thread_mutex_t *mutex);
apr_status_t apr_thread_mutex_trylock(apr_thread_mutex_t *mutex);
apr_status_t apr_thread_mutex_timedlock(apr_thread_mutex_t *mutex,
                                                 apr_interval_time_t timeout);
apr_status_t apr_thread_mutex_unlock(apr_thread_mutex_t *mutex);
apr_status_t apr_thread_mutex_destroy(apr_thread_mutex_t *mutex);
apr_pool_t * apr_thread_mutex_pool_get (const apr_thread_mutex_t *thethread_mutex);
void apr_allocator_mutex_set(apr_allocator_t *allocator,
                                          apr_thread_mutex_t *mutex)
                  __attribute__((nonnull(1)));
apr_thread_mutex_t * apr_allocator_mutex_get(
                                          apr_allocator_t *allocator)
                                  __attribute__((nonnull(1)));
apr_status_t apr_pool_create_ex(apr_pool_t **newpool,
                                             apr_pool_t *parent,
                                             apr_abortfunc_t abort_fn,
                                             apr_allocator_t *allocator)
                          __attribute__((nonnull(1)));
apr_status_t apr_pool_create_core_ex(apr_pool_t **newpool,
                                                  apr_abortfunc_t abort_fn,
                                                  apr_allocator_t *allocator);
apr_status_t apr_pool_create_unmanaged_ex(apr_pool_t **newpool,
                                                   apr_abortfunc_t abort_fn,
                                                   apr_allocator_t *allocator)
                          __attribute__((nonnull(1)));
apr_status_t apr_pool_create_ex_debug(apr_pool_t **newpool,
                                                   apr_pool_t *parent,
                                                   apr_abortfunc_t abort_fn,
                                                   apr_allocator_t *allocator,
                                                   const char *file_line)
                          __attribute__((nonnull(1)));
apr_status_t apr_pool_create_core_ex_debug(apr_pool_t **newpool,
                                                   apr_abortfunc_t abort_fn,
                                                   apr_allocator_t *allocator,
                                                   const char *file_line);
apr_status_t apr_pool_create_unmanaged_ex_debug(apr_pool_t **newpool,
                                                   apr_abortfunc_t abort_fn,
                                                   apr_allocator_t *allocator,
                                                   const char *file_line)
                          __attribute__((nonnull(1)));
apr_allocator_t * apr_pool_allocator_get(apr_pool_t *pool)
                               __attribute__((nonnull(1)));
void apr_pool_clear(apr_pool_t *p) __attribute__((nonnull(1)));
void apr_pool_clear_debug(apr_pool_t *p,
                                       const char *file_line)
                  __attribute__((nonnull(1)));
void apr_pool_destroy(apr_pool_t *p) __attribute__((nonnull(1)));
void apr_pool_destroy_debug(apr_pool_t *p,
                                         const char *file_line)
                  __attribute__((nonnull(1)));
void * apr_palloc(apr_pool_t *p, apr_size_t size)
                    __attribute__((alloc_size(2)))
                    __attribute__((nonnull(1)));
void * apr_palloc_debug(apr_pool_t *p, apr_size_t size,
                                     const char *file_line)
                    __attribute__((alloc_size(2)))
                    __attribute__((nonnull(1)));
void * apr_pcalloc_debug(apr_pool_t *p, apr_size_t size,
                                      const char *file_line)
                    __attribute__((nonnull(1)));
void apr_pool_abort_set(apr_abortfunc_t abortfunc,
                                     apr_pool_t *pool)
                  __attribute__((nonnull(2)));
apr_abortfunc_t apr_pool_abort_get(apr_pool_t *pool)
                             __attribute__((nonnull(1)));
apr_pool_t * apr_pool_parent_get(apr_pool_t *pool)
                          __attribute__((nonnull(1)));
int apr_pool_is_ancestor(apr_pool_t *a, apr_pool_t *b);
void apr_pool_tag(apr_pool_t *pool, const char *tag)
                  __attribute__((nonnull(1)));
apr_status_t apr_pool_userdata_set(const void *data,
                                                const char *key,
                                                apr_status_t (*cleanup)(void *),
                                                apr_pool_t *pool)
                          __attribute__((nonnull(2,4)));
apr_status_t apr_pool_userdata_setn(
                                const void *data, const char *key,
                                apr_status_t (*cleanup)(void *),
                                apr_pool_t *pool)
                          __attribute__((nonnull(2,4)));
apr_status_t apr_pool_userdata_get(void **data, const char *key,
                                                apr_pool_t *pool)
                          __attribute__((nonnull(1,2,3)));
void apr_pool_cleanup_register(
                            apr_pool_t *p, const void *data,
                            apr_status_t (*plain_cleanup)(void *),
                            apr_status_t (*child_cleanup)(void *))
                  __attribute__((nonnull(3,4)));
void apr_pool_pre_cleanup_register(
                            apr_pool_t *p, const void *data,
                            apr_status_t (*plain_cleanup)(void *))
                  __attribute__((nonnull(3)));
void apr_pool_cleanup_kill(apr_pool_t *p, const void *data,
                                        apr_status_t (*cleanup)(void *))
                  __attribute__((nonnull(3)));
void apr_pool_child_cleanup_set(
                        apr_pool_t *p, const void *data,
                        apr_status_t (*plain_cleanup)(void *),
                        apr_status_t (*child_cleanup)(void *))
                  __attribute__((nonnull(3,4)));
apr_status_t apr_pool_cleanup_run(apr_pool_t *p, void *data,
                                               apr_status_t (*cleanup)(void *))
                          __attribute__((nonnull(3)));
apr_status_t apr_pool_cleanup_null(void *data);
void apr_pool_cleanup_for_exec(void);
typedef __builtin_va_list __gnuc_va_list;
typedef __gnuc_va_list va_list;
typedef struct apr_table_t apr_table_t;
typedef struct apr_array_header_t apr_array_header_t;
struct apr_array_header_t {
    apr_pool_t *pool;
    int elt_size;
    int nelts;
    int nalloc;
    char *elts;
};
typedef struct apr_table_entry_t apr_table_entry_t;
struct apr_table_entry_t {
    char *key;
    char *val;
    apr_uint32_t key_checksum;
};
const apr_array_header_t * apr_table_elts(const apr_table_t *t);
int apr_is_empty_table(const apr_table_t *t);
int apr_is_empty_array(const apr_array_header_t *a);
apr_array_header_t * apr_array_make(apr_pool_t *p,
                                                 int nelts, int elt_size);
void * apr_array_push(apr_array_header_t *arr);
void * apr_array_pop(apr_array_header_t *arr);
void apr_array_clear(apr_array_header_t *arr);
void apr_array_cat(apr_array_header_t *dst,
           const apr_array_header_t *src);
apr_array_header_t * apr_array_copy(apr_pool_t *p,
                                      const apr_array_header_t *arr);
apr_array_header_t * apr_array_copy_hdr(apr_pool_t *p,
                                      const apr_array_header_t *arr);
apr_array_header_t * apr_array_append(apr_pool_t *p,
                                      const apr_array_header_t *first,
                                      const apr_array_header_t *second);
char * apr_array_pstrcat(apr_pool_t *p,
          const apr_array_header_t *arr,
          const char sep);
apr_table_t * apr_table_make(apr_pool_t *p, int nelts);
apr_table_t * apr_table_copy(apr_pool_t *p,
                                          const apr_table_t *t);
apr_table_t * apr_table_clone(apr_pool_t *p,
                                           const apr_table_t *t);
void apr_table_clear(apr_table_t *t);
const char * apr_table_get(const apr_table_t *t, const char *key);
const char * apr_table_getm(apr_pool_t *p, const apr_table_t *t,
                                         const char *key);
void apr_table_set(apr_table_t *t, const char *key,
                                const char *val);
void apr_table_setn(apr_table_t *t, const char *key,
                                 const char *val);
void apr_table_unset(apr_table_t *t, const char *key);
void apr_table_merge(apr_table_t *t, const char *key,
                                  const char *val);
void apr_table_mergen(apr_table_t *t, const char *key,
                                   const char *val);
void apr_table_add(apr_table_t *t, const char *key,
                                const char *val);
void apr_table_addn(apr_table_t *t, const char *key,
                                 const char *val);
apr_table_t * apr_table_overlay(apr_pool_t *p,
                                             const apr_table_t *overlay,
                                             const apr_table_t *base);
typedef int (apr_table_do_callback_fn_t)(void *rec, const char *key,
                                                    const char *value);
int apr_table_do(apr_table_do_callback_fn_t *comp,
                                     void *rec, const apr_table_t *t, ...)
    __attribute__((sentinel))
    ;
int apr_table_vdo(apr_table_do_callback_fn_t *comp,
                               void *rec, const apr_table_t *t, va_list vp);
void apr_table_overlap(apr_table_t *a, const apr_table_t *b,
                                     unsigned flags);
void apr_table_compress(apr_table_t *t, unsigned flags);
void apr_optional_hook_add(const char *szName,void (*pfn)(void),
     const char * const *aszPre,
     const char * const *aszSucc,
     int nOrder);
apr_array_header_t * apr_optional_hook_get(const char *szName);

extern ssize_t readv (int __fd, const struct iovec *__iovec, int __count)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t writev (int __fd, const struct iovec *__iovec, int __count)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t preadv (int __fd, const struct iovec *__iovec, int __count,
         __off_t __offset)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pwritev (int __fd, const struct iovec *__iovec, int __count,
   __off_t __offset)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t preadv64 (int __fd, const struct iovec *__iovec, int __count,
    __off64_t __offset)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pwritev64 (int __fd, const struct iovec *__iovec, int __count,
     __off64_t __offset)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t preadv2 (int __fp, const struct iovec *__iovec, int __count,
   __off_t __offset, int ___flags)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pwritev2 (int __fd, const struct iovec *__iodev, int __count,
    __off_t __offset, int __flags) ;
extern ssize_t preadv64v2 (int __fp, const struct iovec *__iovec,
      int __count, __off64_t __offset,
      int ___flags)
  __attribute__ ((__access__ (__read_only__, 2, 3)));
extern ssize_t pwritev64v2 (int __fd, const struct iovec *__iodev,
       int __count, __off64_t __offset,
       int __flags)
  __attribute__ ((__access__ (__read_only__, 2, 3)));


extern ssize_t process_vm_readv (pid_t __pid, const struct iovec *__lvec,
     unsigned long int __liovcnt,
     const struct iovec *__rvec,
     unsigned long int __riovcnt,
     unsigned long int __flags)
  __attribute__ ((__nothrow__ , __leaf__));
extern ssize_t process_vm_writev (pid_t __pid, const struct iovec *__lvec,
      unsigned long int __liovcnt,
      const struct iovec *__rvec,
      unsigned long int __riovcnt,
      unsigned long int __flags)
  __attribute__ ((__nothrow__ , __leaf__));

int apr_strnatcmp(char const *a, char const *b);
int apr_strnatcasecmp(char const *a, char const *b);
char * apr_pstrdup(apr_pool_t *p, const char *s);
char * apr_pstrmemdup(apr_pool_t *p, const char *s, apr_size_t n)
    __attribute__((alloc_size(3)))
    ;
char * apr_pstrndup(apr_pool_t *p, const char *s, apr_size_t n);
void * apr_pmemdup(apr_pool_t *p, const void *m, apr_size_t n)
    __attribute__((alloc_size(3)))
    ;
char * apr_pstrcat(apr_pool_t *p, ...)
    __attribute__((sentinel))
    ;
char * apr_pstrcatv(apr_pool_t *p, const struct iovec *vec,
                                 apr_size_t nvec, apr_size_t *nbytes);
char * apr_pvsprintf(apr_pool_t *p, const char *fmt, va_list ap);
char * apr_psprintf(apr_pool_t *p, const char *fmt, ...)
        __attribute__((format(printf,2,3)));
char * apr_cpystrn(char *dst, const char *src,
                                apr_size_t dst_size);
char * apr_collapse_spaces(char *dest, const char *src);
apr_status_t apr_tokenize_to_argv(const char *arg_str,
                                               char ***argv_out,
                                               apr_pool_t *token_context);
char * apr_strtok(char *str, const char *sep, char **last);
int apr_snprintf(char *buf, apr_size_t len,
                                     const char *format, ...)
        __attribute__((format(printf,3,4)));
int apr_vsnprintf(char *buf, apr_size_t len, const char *format,
                               va_list ap);
char * apr_itoa(apr_pool_t *p, int n);
char * apr_ltoa(apr_pool_t *p, long n);
char * apr_off_t_toa(apr_pool_t *p, apr_off_t n);
apr_status_t apr_strtoff(apr_off_t *offset, const char *buf,
                                      char **end, int base);
apr_int64_t apr_strtoi64(const char *buf, char **end, int base);
apr_int64_t apr_atoi64(const char *buf);
char * apr_strfsize(apr_off_t size, char *buf);
 extern apr_pool_t *apr_hook_global_pool;
 extern int apr_hook_debug_enabled;
 extern const char *apr_hook_debug_current;
void apr_hook_sort_register(const char *szHookName,
                                        apr_array_header_t **aHooks);
void apr_hook_sort_all(void);
void apr_hook_debug_show(const char *szName,
                                      const char * const *aszPre,
                                      const char * const *aszSucc);
void apr_hook_deregister_all(void);
typedef struct {
    int major;
    int minor;
    int patch;
    int is_dev;
} apr_version_t;
void apr_version(apr_version_t *pvsn);
const char * apr_version_string(void);
typedef uid_t apr_uid_t;
typedef gid_t apr_gid_t;
apr_status_t apr_uid_current(apr_uid_t *userid,
                                          apr_gid_t *groupid,
                                          apr_pool_t *p);
apr_status_t apr_uid_name_get(char **username, apr_uid_t userid,
                                           apr_pool_t *p);
apr_status_t apr_uid_get(apr_uid_t *userid, apr_gid_t *groupid,
                                      const char *username, apr_pool_t *p);
apr_status_t apr_uid_homepath_get(char **dirname,
                                               const char *username,
                                               apr_pool_t *p);
apr_status_t apr_gid_name_get(char **groupname,
                                             apr_gid_t groupid, apr_pool_t *p);
apr_status_t apr_gid_get(apr_gid_t *groupid,
                                      const char *groupname, apr_pool_t *p);
typedef enum {
    APR_NOFILE = 0,
    APR_REG,
    APR_DIR,
    APR_CHR,
    APR_BLK,
    APR_PIPE,
    APR_LNK,
    APR_SOCK,
    APR_UNKFILE = 127
} apr_filetype_e;
typedef struct apr_dir_t apr_dir_t;
typedef apr_int32_t apr_fileperms_t;
typedef dev_t apr_dev_t;
typedef struct apr_finfo_t apr_finfo_t;
struct apr_finfo_t {
    apr_pool_t *pool;
    apr_int32_t valid;
    apr_fileperms_t protection;
    apr_filetype_e filetype;
    apr_uid_t user;
    apr_gid_t group;
    apr_ino_t inode;
    apr_dev_t device;
    apr_int32_t nlink;
    apr_off_t size;
    apr_off_t csize;
    apr_time_t atime;
    apr_time_t mtime;
    apr_time_t ctime;
    const char *fname;
    const char *name;
    struct apr_file_t *filehand;
};
apr_status_t apr_stat(apr_finfo_t *finfo, const char *fname,
                                   apr_int32_t wanted, apr_pool_t *pool);
apr_status_t apr_dir_open(apr_dir_t **new_dir,
                                       const char *dirname,
                                       apr_pool_t *pool);
apr_status_t apr_dir_close(apr_dir_t *thedir);
apr_status_t apr_dir_read(apr_finfo_t *finfo, apr_int32_t wanted,
                                       apr_dir_t *thedir);
apr_status_t apr_dir_rewind(apr_dir_t *thedir);
apr_status_t apr_filepath_root(const char **rootpath,
                                            const char **filepath,
                                            apr_int32_t flags,
                                            apr_pool_t *p);
apr_status_t apr_filepath_merge(char **newpath,
                                             const char *rootpath,
                                             const char *addpath,
                                             apr_int32_t flags,
                                             apr_pool_t *p);
apr_status_t apr_filepath_list_split(apr_array_header_t **pathelts,
                                                  const char *liststr,
                                                  apr_pool_t *p);
apr_status_t apr_filepath_list_merge(char **liststr,
                                                  apr_array_header_t *pathelts,
                                                  apr_pool_t *p);
apr_status_t apr_filepath_get(char **path, apr_int32_t flags,
                                           apr_pool_t *p);
apr_status_t apr_filepath_set(const char *path, apr_pool_t *p);
apr_status_t apr_filepath_encoding(int *style, apr_pool_t *p);

typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
struct _IO_FILE;
typedef struct _IO_FILE __FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;
struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;
typedef void _IO_lock_t;
struct _IO_FILE
{
  int _flags;
  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;
  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;
  struct _IO_marker *_markers;
  struct _IO_FILE *_chain;
  int _fileno;
  int _flags2;
  __off_t _old_offset;
  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];
  _IO_lock_t *_lock;
  __off64_t _offset;
  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  size_t __pad5;
  int _mode;
  char _unused2[15 * sizeof (int) - 4 * sizeof (void *) - sizeof (size_t)];
};
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);
typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);
typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);
typedef int cookie_close_function_t (void *__cookie);
typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
typedef __fpos_t fpos_t;
typedef __fpos64_t fpos64_t;
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;
extern int remove (const char *__filename) __attribute__ ((__nothrow__ , __leaf__));
extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ , __leaf__));
extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ , __leaf__));
extern int renameat2 (int __oldfd, const char *__old, int __newfd,
        const char *__new, unsigned int __flags) __attribute__ ((__nothrow__ , __leaf__));
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *tmpfile64 (void)
   __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ , __leaf__)) ;
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (__builtin_free, 1)));
extern int fflush (FILE *__stream);
extern int fflush_unlocked (FILE *__stream);
extern int fcloseall (void);
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern FILE *fopen64 (const char *__restrict __filename,
        const char *__restrict __modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *freopen64 (const char *__restrict __filename,
   const char *__restrict __modes,
   FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (fclose, 1))) ;
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__nonnull__ (1)));
extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int printf (const char *__restrict __format, ...);
extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));
extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));
extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);
extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));
extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));
extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) ;
extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ , __leaf__));
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc23_fscanf") __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc23_scanf") ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc23_sscanf") __attribute__ ((__nothrow__ , __leaf__));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vfscanf")
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vscanf")
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc23_vsscanf") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar (void);
extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar (int __c);
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
     __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
extern char *fgets_unlocked (char *__restrict __s, int __n,
        FILE *__restrict __stream)
    __attribute__ ((__access__ (__write_only__, 1, 2))) __attribute__ ((__nonnull__ (3)));
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));
extern int puts (const char *__s);
extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
extern int fputs_unlocked (const char *__restrict __s,
      FILE *__restrict __stream) __attribute__ ((__nonnull__ (2)));
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
extern int fseeko64 (FILE *__stream, __off64_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off64_t ftello64 (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos64 (FILE *__restrict __stream, fpos64_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos64 (FILE *__stream, const fpos64_t *__pos) __attribute__ ((__nonnull__ (1)));
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void perror (const char *__s) __attribute__ ((__cold__));
extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (pclose, 1))) ;
extern char *ctermid (char *__s) __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1)));
extern char *cuserid (char *__s)
  __attribute__ ((__access__ (__write_only__, 1)));
struct obstack;
extern int obstack_printf (struct obstack *__restrict __obstack,
      const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3)));
extern int obstack_vprintf (struct obstack *__restrict __obstack,
       const char *__restrict __format,
       __gnuc_va_list __args)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0)));
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);

typedef apr_uint32_t apr_fileattrs_t;
typedef int apr_seek_where_t;
typedef struct apr_file_t apr_file_t;
apr_status_t apr_file_open(apr_file_t **newf, const char *fname,
                                        apr_int32_t flag, apr_fileperms_t perm,
                                        apr_pool_t *pool);
apr_status_t apr_file_close(apr_file_t *file);
apr_status_t apr_file_remove(const char *path, apr_pool_t *pool);
apr_status_t apr_file_rename(const char *from_path,
                                          const char *to_path,
                                          apr_pool_t *pool);
apr_status_t apr_file_link(const char *from_path,
                                          const char *to_path);
apr_status_t apr_file_copy(const char *from_path,
                                        const char *to_path,
                                        apr_fileperms_t perms,
                                        apr_pool_t *pool);
apr_status_t apr_file_append(const char *from_path,
                                          const char *to_path,
                                          apr_fileperms_t perms,
                                          apr_pool_t *pool);
apr_status_t apr_file_eof(apr_file_t *fptr);
apr_status_t apr_file_open_stderr(apr_file_t **thefile,
                                               apr_pool_t *pool);
apr_status_t apr_file_open_stdout(apr_file_t **thefile,
                                               apr_pool_t *pool);
apr_status_t apr_file_open_stdin(apr_file_t **thefile,
                                              apr_pool_t *pool);
apr_status_t apr_file_open_flags_stderr(apr_file_t **thefile,
                                                     apr_int32_t flags,
                                                     apr_pool_t *pool);
apr_status_t apr_file_open_flags_stdout(apr_file_t **thefile,
                                                     apr_int32_t flags,
                                                     apr_pool_t *pool);
apr_status_t apr_file_open_flags_stdin(apr_file_t **thefile,
                                                     apr_int32_t flags,
                                                     apr_pool_t *pool);
apr_status_t apr_file_read(apr_file_t *thefile, void *buf,
                                        apr_size_t *nbytes);
apr_status_t apr_file_write(apr_file_t *thefile, const void *buf,
                                         apr_size_t *nbytes);
apr_status_t apr_file_writev(apr_file_t *thefile,
                                          const struct iovec *vec,
                                          apr_size_t nvec, apr_size_t *nbytes);
apr_status_t apr_file_read_full(apr_file_t *thefile, void *buf,
                                             apr_size_t nbytes,
                                             apr_size_t *bytes_read);
apr_status_t apr_file_write_full(apr_file_t *thefile,
                                              const void *buf,
                                              apr_size_t nbytes,
                                              apr_size_t *bytes_written);
apr_status_t apr_file_writev_full(apr_file_t *thefile,
                                               const struct iovec *vec,
                                               apr_size_t nvec,
                                               apr_size_t *nbytes);
apr_status_t apr_file_putc(char ch, apr_file_t *thefile);
apr_status_t apr_file_getc(char *ch, apr_file_t *thefile);
apr_status_t apr_file_ungetc(char ch, apr_file_t *thefile);
apr_status_t apr_file_gets(char *str, int len,
                                        apr_file_t *thefile);
apr_status_t apr_file_puts(const char *str, apr_file_t *thefile);
apr_status_t apr_file_flush(apr_file_t *thefile);
apr_status_t apr_file_sync(apr_file_t *thefile);
apr_status_t apr_file_datasync(apr_file_t *thefile);
apr_status_t apr_file_dup(apr_file_t **new_file,
                                       apr_file_t *old_file,
                                       apr_pool_t *p);
apr_status_t apr_file_dup2(apr_file_t *new_file,
                                        apr_file_t *old_file,
                                        apr_pool_t *p);
apr_status_t apr_file_setaside(apr_file_t **new_file,
                                            apr_file_t *old_file,
                                            apr_pool_t *p);
apr_status_t apr_file_buffer_set(apr_file_t *thefile,
                                              char * buffer,
                                              apr_size_t bufsize);
apr_size_t apr_file_buffer_size_get(apr_file_t *thefile);
apr_status_t apr_file_seek(apr_file_t *thefile,
                                   apr_seek_where_t where,
                                   apr_off_t *offset);
apr_status_t apr_file_pipe_create(apr_file_t **in,
                                               apr_file_t **out,
                                               apr_pool_t *pool);
apr_status_t apr_file_pipe_create_ex(apr_file_t **in,
                                                  apr_file_t **out,
                                                  apr_int32_t blocking,
                                                  apr_pool_t *pool);
apr_status_t apr_file_pipe_create_pools(apr_file_t **in,
                                                     apr_file_t **out,
                                                     apr_int32_t blocking,
                                                     apr_pool_t *pool_in,
                                                     apr_pool_t *pool_out);
apr_status_t apr_file_namedpipe_create(const char *filename,
                                                    apr_fileperms_t perm,
                                                    apr_pool_t *pool);
apr_status_t apr_file_pipe_timeout_get(apr_file_t *thepipe,
                                               apr_interval_time_t *timeout);
apr_status_t apr_file_pipe_timeout_set(apr_file_t *thepipe,
                                                  apr_interval_time_t timeout);
apr_status_t apr_file_lock(apr_file_t *thefile, int type);
apr_status_t apr_file_unlock(apr_file_t *thefile);
apr_status_t apr_file_name_get(const char **new_path,
                                            apr_file_t *thefile);
apr_status_t apr_file_data_get(void **data, const char *key,
                                            apr_file_t *file);
apr_status_t apr_file_data_set(apr_file_t *file, void *data,
                                            const char *key,
                                            apr_status_t (*cleanup)(void *));
int apr_file_printf(apr_file_t *fptr,
                                        const char *format, ...)
        __attribute__((format(printf,2,3)));
apr_status_t apr_file_perms_set(const char *fname,
                                             apr_fileperms_t perms);
apr_status_t apr_file_attrs_set(const char *fname,
                                             apr_fileattrs_t attributes,
                                             apr_fileattrs_t attr_mask,
                                             apr_pool_t *pool);
apr_status_t apr_file_mtime_set(const char *fname,
                                             apr_time_t mtime,
                                             apr_pool_t *pool);
apr_status_t apr_dir_make(const char *path, apr_fileperms_t perm,
                                       apr_pool_t *pool);
apr_status_t apr_dir_make_recursive(const char *path,
                                                 apr_fileperms_t perm,
                                                 apr_pool_t *pool);
apr_status_t apr_dir_remove(const char *path, apr_pool_t *pool);
apr_status_t apr_file_info_get(apr_finfo_t *finfo,
                                            apr_int32_t wanted,
                                            apr_file_t *thefile);
apr_status_t apr_file_trunc(apr_file_t *fp, apr_off_t offset);
apr_int32_t apr_file_flags_get(apr_file_t *f);
apr_pool_t * apr_file_pool_get (const apr_file_t *thefile);
apr_status_t apr_file_inherit_set( apr_file_t *thefile);
apr_status_t apr_file_inherit_unset( apr_file_t *thefile);
apr_status_t apr_file_mktemp(apr_file_t **fp, char *templ,
                                          apr_int32_t flags, apr_pool_t *p);
apr_status_t apr_temp_dir_get(const char **temp_dir,
                                           apr_pool_t *p);
typedef apr_status_t (apr_perms_setfn_t)(void *object, apr_fileperms_t perms,
                                         apr_uid_t uid, apr_gid_t gid);

typedef uint32_t in_addr_t;
struct in_addr
  {
    in_addr_t s_addr;
  };
struct ip_opts
  {
    struct in_addr ip_dst;
    char ip_opts[40];
  };
struct in_pktinfo
  {
    int ipi_ifindex;
    struct in_addr ipi_spec_dst;
    struct in_addr ipi_addr;
  };
enum
  {
    IPPROTO_IP = 0,
    IPPROTO_ICMP = 1,
    IPPROTO_IGMP = 2,
    IPPROTO_IPIP = 4,
    IPPROTO_TCP = 6,
    IPPROTO_EGP = 8,
    IPPROTO_PUP = 12,
    IPPROTO_UDP = 17,
    IPPROTO_IDP = 22,
    IPPROTO_TP = 29,
    IPPROTO_DCCP = 33,
    IPPROTO_IPV6 = 41,
    IPPROTO_RSVP = 46,
    IPPROTO_GRE = 47,
    IPPROTO_ESP = 50,
    IPPROTO_AH = 51,
    IPPROTO_MTP = 92,
    IPPROTO_BEETPH = 94,
    IPPROTO_ENCAP = 98,
    IPPROTO_PIM = 103,
    IPPROTO_COMP = 108,
    IPPROTO_L2TP = 115,
    IPPROTO_SCTP = 132,
    IPPROTO_UDPLITE = 136,
    IPPROTO_MPLS = 137,
    IPPROTO_ETHERNET = 143,
    IPPROTO_RAW = 255,
    IPPROTO_MPTCP = 262,
    IPPROTO_MAX
  };
enum
  {
    IPPROTO_HOPOPTS = 0,
    IPPROTO_ROUTING = 43,
    IPPROTO_FRAGMENT = 44,
    IPPROTO_ICMPV6 = 58,
    IPPROTO_NONE = 59,
    IPPROTO_DSTOPTS = 60,
    IPPROTO_MH = 135
  };
typedef uint16_t in_port_t;
enum
  {
    IPPORT_ECHO = 7,
    IPPORT_DISCARD = 9,
    IPPORT_SYSTAT = 11,
    IPPORT_DAYTIME = 13,
    IPPORT_NETSTAT = 15,
    IPPORT_FTP = 21,
    IPPORT_TELNET = 23,
    IPPORT_SMTP = 25,
    IPPORT_TIMESERVER = 37,
    IPPORT_NAMESERVER = 42,
    IPPORT_WHOIS = 43,
    IPPORT_MTP = 57,
    IPPORT_TFTP = 69,
    IPPORT_RJE = 77,
    IPPORT_FINGER = 79,
    IPPORT_TTYLINK = 87,
    IPPORT_SUPDUP = 95,
    IPPORT_EXECSERVER = 512,
    IPPORT_LOGINSERVER = 513,
    IPPORT_CMDSERVER = 514,
    IPPORT_EFSSERVER = 520,
    IPPORT_BIFFUDP = 512,
    IPPORT_WHOSERVER = 513,
    IPPORT_ROUTESERVER = 520,
    IPPORT_RESERVED = 1024,
    IPPORT_USERRESERVED = 5000
  };
struct in6_addr
  {
    union
      {
 uint8_t __u6_addr8[16];
 uint16_t __u6_addr16[8];
 uint32_t __u6_addr32[4];
      } __in6_u;
  };
extern const struct in6_addr in6addr_any;
extern const struct in6_addr in6addr_loopback;
struct sockaddr_in
  {
    sa_family_t sin_family;
    in_port_t sin_port;
    struct in_addr sin_addr;
    unsigned char sin_zero[sizeof (struct sockaddr)
      - (sizeof (unsigned short int))
      - sizeof (in_port_t)
      - sizeof (struct in_addr)];
  };
struct sockaddr_in6
  {
    sa_family_t sin6_family;
    in_port_t sin6_port;
    uint32_t sin6_flowinfo;
    struct in6_addr sin6_addr;
    uint32_t sin6_scope_id;
  };
struct ip_mreq
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
  };
struct ip_mreqn
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_address;
    int imr_ifindex;
  };
struct ip_mreq_source
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
    struct in_addr imr_sourceaddr;
  };
struct ipv6_mreq
  {
    struct in6_addr ipv6mr_multiaddr;
    unsigned int ipv6mr_interface;
  };
struct group_req
  {
    uint32_t gr_interface;
    struct sockaddr_storage gr_group;
  };
struct group_source_req
  {
    uint32_t gsr_interface;
    struct sockaddr_storage gsr_group;
    struct sockaddr_storage gsr_source;
  };
struct ip_msfilter
  {
    struct in_addr imsf_multiaddr;
    struct in_addr imsf_interface;
    uint32_t imsf_fmode;
    uint32_t imsf_numsrc;
    struct in_addr imsf_slist[1];
  };
struct group_filter
  {
    uint32_t gf_interface;
    struct sockaddr_storage gf_group;
    uint32_t gf_fmode;
    uint32_t gf_numsrc;
    struct sockaddr_storage gf_slist[1];
};
extern uint32_t ntohl (uint32_t __netlong) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern uint16_t ntohs (uint16_t __netshort)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern uint32_t htonl (uint32_t __hostlong)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern uint16_t htons (uint16_t __hostshort)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int bindresvport (int __sockfd, struct sockaddr_in *__sock_in) __attribute__ ((__nothrow__ , __leaf__));
extern int bindresvport6 (int __sockfd, struct sockaddr_in6 *__sock_in)
     __attribute__ ((__nothrow__ , __leaf__));
struct cmsghdr;
struct in6_pktinfo
  {
    struct in6_addr ipi6_addr;
    unsigned int ipi6_ifindex;
  };
struct ip6_mtuinfo
  {
    struct sockaddr_in6 ip6m_addr;
    uint32_t ip6m_mtu;
  };
extern int inet6_option_space (int __nbytes)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int inet6_option_init (void *__bp, struct cmsghdr **__cmsgp,
         int __type) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int inet6_option_append (struct cmsghdr *__cmsg,
    const uint8_t *__typep, int __multx,
    int __plusy) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern uint8_t *inet6_option_alloc (struct cmsghdr *__cmsg, int __datalen,
        int __multx, int __plusy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int inet6_option_next (const struct cmsghdr *__cmsg,
         uint8_t **__tptrp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int inet6_option_find (const struct cmsghdr *__cmsg,
         uint8_t **__tptrp, int __type)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__deprecated__));
extern int inet6_opt_init (void *__extbuf, socklen_t __extlen) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_append (void *__extbuf, socklen_t __extlen, int __offset,
        uint8_t __type, socklen_t __len, uint8_t __align,
        void **__databufp) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_finish (void *__extbuf, socklen_t __extlen, int __offset)
     __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_set_val (void *__databuf, int __offset, void *__val,
         socklen_t __vallen) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_next (void *__extbuf, socklen_t __extlen, int __offset,
      uint8_t *__typep, socklen_t *__lenp,
      void **__databufp) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_find (void *__extbuf, socklen_t __extlen, int __offset,
      uint8_t __type, socklen_t *__lenp,
      void **__databufp) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_opt_get_val (void *__databuf, int __offset, void *__val,
         socklen_t __vallen) __attribute__ ((__nothrow__ , __leaf__));
extern socklen_t inet6_rth_space (int __type, int __segments) __attribute__ ((__nothrow__ , __leaf__));
extern void *inet6_rth_init (void *__bp, socklen_t __bp_len, int __type,
        int __segments) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_rth_add (void *__bp, const struct in6_addr *__addr) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_rth_reverse (const void *__in, void *__out) __attribute__ ((__nothrow__ , __leaf__));
extern int inet6_rth_segments (const void *__bp) __attribute__ ((__nothrow__ , __leaf__));
extern struct in6_addr *inet6_rth_getaddr (const void *__bp, int __index)
     __attribute__ ((__nothrow__ , __leaf__));
extern int getipv4sourcefilter (int __s, struct in_addr __interface_addr,
    struct in_addr __group, uint32_t *__fmode,
    uint32_t *__numsrc, struct in_addr *__slist)
     __attribute__ ((__nothrow__ , __leaf__));
extern int setipv4sourcefilter (int __s, struct in_addr __interface_addr,
    struct in_addr __group, uint32_t __fmode,
    uint32_t __numsrc,
    const struct in_addr *__slist)
     __attribute__ ((__nothrow__ , __leaf__));
extern int getsourcefilter (int __s, uint32_t __interface_addr,
       const struct sockaddr *__group,
       socklen_t __grouplen, uint32_t *__fmode,
       uint32_t *__numsrc,
       struct sockaddr_storage *__slist) __attribute__ ((__nothrow__ , __leaf__));
extern int setsourcefilter (int __s, uint32_t __interface_addr,
       const struct sockaddr *__group,
       socklen_t __grouplen, uint32_t __fmode,
       uint32_t __numsrc,
       const struct sockaddr_storage *__slist) __attribute__ ((__nothrow__ , __leaf__));


struct sockaddr_un
  {
    sa_family_t sun_family;
    char sun_path[108];
  };
typedef long int ptrdiff_t;
typedef int wchar_t;
typedef struct {
  long long __max_align_ll __attribute__((__aligned__(__alignof__(long long))));
  long double __max_align_ld __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;

typedef enum {
    APR_SHUTDOWN_READ,
    APR_SHUTDOWN_WRITE,
    APR_SHUTDOWN_READWRITE
} apr_shutdown_how_e;
typedef enum {
    APR_LOCAL,
    APR_REMOTE
} apr_interface_e;
typedef struct apr_socket_t apr_socket_t;
typedef struct apr_hdtr_t apr_hdtr_t;
typedef struct in_addr apr_in_addr_t;
typedef struct apr_ipsubnet_t apr_ipsubnet_t;
typedef apr_uint16_t apr_port_t;
typedef struct apr_sockaddr_t apr_sockaddr_t;
struct apr_sockaddr_t {
    apr_pool_t *pool;
    char *hostname;
    char *servname;
    apr_port_t port;
    apr_int32_t family;
    apr_socklen_t salen;
    int ipaddr_len;
    int addr_str_len;
    void *ipaddr_ptr;
    apr_sockaddr_t *next;
    union {
        struct sockaddr_in sin;
        struct sockaddr_in6 sin6;
        struct sockaddr_storage sas;
        struct sockaddr_un unx;
    } sa;
};
struct apr_hdtr_t {
    struct iovec* headers;
    int numheaders;
    struct iovec* trailers;
    int numtrailers;
};
apr_status_t apr_socket_create(apr_socket_t **new_sock,
                                            int family, int type,
                                            int protocol,
                                            apr_pool_t *cont);
apr_status_t apr_socket_shutdown(apr_socket_t *thesocket,
                                              apr_shutdown_how_e how);
apr_status_t apr_socket_close(apr_socket_t *thesocket);
apr_status_t apr_socket_bind(apr_socket_t *sock,
                                          apr_sockaddr_t *sa);
apr_status_t apr_socket_listen(apr_socket_t *sock,
                                            apr_int32_t backlog);
apr_status_t apr_socket_accept(apr_socket_t **new_sock,
                                            apr_socket_t *sock,
                                            apr_pool_t *connection_pool);
apr_status_t apr_socket_connect(apr_socket_t *sock,
                                             apr_sockaddr_t *sa);
apr_status_t apr_socket_atreadeof(apr_socket_t *sock,
                                               int *atreadeof);
apr_status_t apr_sockaddr_info_get(apr_sockaddr_t **sa,
                                          const char *hostname,
                                          apr_int32_t family,
                                          apr_port_t port,
                                          apr_int32_t flags,
                                          apr_pool_t *p);
apr_status_t apr_sockaddr_info_copy(apr_sockaddr_t **dst,
                                                 const apr_sockaddr_t *src,
                                                 apr_pool_t *p);
apr_status_t apr_sockaddr_zone_set(apr_sockaddr_t *sa,
                                                const char *zone_id);
apr_status_t apr_sockaddr_zone_get(const apr_sockaddr_t *sa,
                                                const char **name,
                                                apr_uint32_t *id,
                                                apr_pool_t *p);
apr_status_t apr_getnameinfo(char **hostname,
                                          apr_sockaddr_t *sa,
                                          apr_int32_t flags);
apr_status_t apr_parse_addr_port(char **addr,
                                              char **scope_id,
                                              apr_port_t *port,
                                              const char *str,
                                              apr_pool_t *p);
apr_status_t apr_gethostname(char *buf, int len, apr_pool_t *cont);
apr_status_t apr_socket_data_get(void **data, const char *key,
                                              apr_socket_t *sock);
apr_status_t apr_socket_data_set(apr_socket_t *sock, void *data,
                                              const char *key,
                                              apr_status_t (*cleanup)(void*));
apr_status_t apr_socket_send(apr_socket_t *sock, const char *buf,
                                          apr_size_t *len);
apr_status_t apr_socket_sendv(apr_socket_t *sock,
                                           const struct iovec *vec,
                                           apr_int32_t nvec, apr_size_t *len);
apr_status_t apr_socket_sendto(apr_socket_t *sock,
                                            apr_sockaddr_t *where,
                                            apr_int32_t flags, const char *buf,
                                            apr_size_t *len);
apr_status_t apr_socket_recvfrom(apr_sockaddr_t *from,
                                              apr_socket_t *sock,
                                              apr_int32_t flags, char *buf,
                                              apr_size_t *len);
apr_status_t apr_socket_sendfile(apr_socket_t *sock,
                                              apr_file_t *file,
                                              apr_hdtr_t *hdtr,
                                              apr_off_t *offset,
                                              apr_size_t *len,
                                              apr_int32_t flags);
apr_status_t apr_socket_recv(apr_socket_t *sock,
                                   char *buf, apr_size_t *len);
apr_status_t apr_socket_opt_set(apr_socket_t *sock,
                                             apr_int32_t opt, apr_int32_t on);
apr_status_t apr_socket_timeout_set(apr_socket_t *sock,
                                                 apr_interval_time_t t);
apr_status_t apr_socket_opt_get(apr_socket_t *sock,
                                             apr_int32_t opt, apr_int32_t *on);
apr_status_t apr_socket_timeout_get(apr_socket_t *sock,
                                                 apr_interval_time_t *t);
apr_status_t apr_socket_atmark(apr_socket_t *sock,
                                            int *atmark);
apr_status_t apr_socket_addr_get(apr_sockaddr_t **sa,
                                              apr_interface_e which,
                                              apr_socket_t *sock);
apr_status_t apr_sockaddr_ip_get(char **addr,
                                              apr_sockaddr_t *sockaddr);
apr_status_t apr_sockaddr_ip_getbuf(char *buf, apr_size_t buflen,
                                                 apr_sockaddr_t *sockaddr);
int apr_sockaddr_equal(const apr_sockaddr_t *addr1,
                                    const apr_sockaddr_t *addr2);
int apr_sockaddr_is_wildcard(const apr_sockaddr_t *addr);
apr_status_t apr_socket_type_get(apr_socket_t *sock,
                                              int *type);
apr_status_t apr_getservbyname(apr_sockaddr_t *sockaddr,
                                            const char *servname);
apr_status_t apr_ipsubnet_create(apr_ipsubnet_t **ipsub,
                                              const char *ipstr,
                                              const char *mask_or_numbits,
                                              apr_pool_t *p);
int apr_ipsubnet_test(apr_ipsubnet_t *ipsub, apr_sockaddr_t *sa);
apr_status_t apr_socket_protocol_get(apr_socket_t *sock,
                                                  int *protocol);
apr_pool_t * apr_socket_pool_get (const apr_socket_t *thesocket);
apr_status_t apr_socket_inherit_set( apr_socket_t *thesocket);
apr_status_t apr_socket_inherit_unset( apr_socket_t *thesocket);
apr_status_t apr_socket_perms_set (void *thesocket, apr_fileperms_t perms, apr_uid_t uid, apr_gid_t gid);
apr_status_t apr_mcast_join(apr_socket_t *sock,
                                         apr_sockaddr_t *join,
                                         apr_sockaddr_t *iface,
                                         apr_sockaddr_t *source);
apr_status_t apr_mcast_leave(apr_socket_t *sock,
                                          apr_sockaddr_t *addr,
                                          apr_sockaddr_t *iface,
                                          apr_sockaddr_t *source);
apr_status_t apr_mcast_hops(apr_socket_t *sock,
                                         apr_byte_t ttl);
apr_status_t apr_mcast_loopback(apr_socket_t *sock,
                                             apr_byte_t opt);
apr_status_t apr_mcast_interface(apr_socket_t *sock,
                                              apr_sockaddr_t *iface);
typedef struct apr_mmap_t apr_mmap_t;
struct apr_mmap_t {
    apr_pool_t *cntxt;
    void *mm;
    apr_size_t size;
    struct { struct apr_mmap_t * volatile next; struct apr_mmap_t * volatile prev; } link;
};
apr_status_t apr_mmap_create(apr_mmap_t **newmmap,
                                          apr_file_t *file, apr_off_t offset,
                                          apr_size_t size, apr_int32_t flag,
                                          apr_pool_t *cntxt);
apr_status_t apr_mmap_dup(apr_mmap_t **new_mmap,
                                       apr_mmap_t *old_mmap,
                                       apr_pool_t *p);
apr_status_t apr_mmap_delete(apr_mmap_t *mm);
apr_status_t apr_mmap_offset(void **addr, apr_mmap_t *mm,
                                          apr_off_t offset);
typedef enum {
    APR_BLOCK_READ,
    APR_NONBLOCK_READ
} apr_read_type_e;
typedef struct apr_bucket_brigade apr_bucket_brigade;
typedef struct apr_bucket apr_bucket;
typedef struct apr_bucket_alloc_t apr_bucket_alloc_t;
typedef struct apr_bucket_type_t apr_bucket_type_t;
struct apr_bucket_type_t {
    const char *name;
    int num_func;
    enum {
        APR_BUCKET_DATA = 0,
        APR_BUCKET_METADATA = 1
    } is_metadata;
    void (*destroy)(void *data);
    apr_status_t (*read)(apr_bucket *b, const char **str, apr_size_t *len,
                         apr_read_type_e block);
    apr_status_t (*setaside)(apr_bucket *e, apr_pool_t *pool);
    apr_status_t (*split)(apr_bucket *e, apr_size_t point);
    apr_status_t (*copy)(apr_bucket *e, apr_bucket **c);
};
struct apr_bucket {
    struct { struct apr_bucket * volatile next; struct apr_bucket * volatile prev; } link;
    const apr_bucket_type_t *type;
    apr_size_t length;
    apr_off_t start;
    void *data;
    void (*free)(void *e);
    apr_bucket_alloc_t *list;
};
struct apr_bucket_brigade {
    apr_pool_t *p;
    struct apr_bucket_list { struct apr_bucket * volatile next; struct apr_bucket * volatile prev; } list;
    apr_bucket_alloc_t *bucket_alloc;
};
typedef apr_status_t (*apr_brigade_flush)(apr_bucket_brigade *bb, void *ctx);
typedef struct apr_bucket_refcount apr_bucket_refcount;
struct apr_bucket_refcount {
    int refcount;
};
typedef struct apr_bucket_heap apr_bucket_heap;
struct apr_bucket_heap {
    apr_bucket_refcount refcount;
    char *base;
    apr_size_t alloc_len;
    void (*free_func)(void *data);
};
typedef struct apr_bucket_pool apr_bucket_pool;
struct apr_bucket_pool {
    apr_bucket_heap heap;
    const char *base;
    apr_pool_t *pool;
    apr_bucket_alloc_t *list;
};
typedef struct apr_bucket_mmap apr_bucket_mmap;
struct apr_bucket_mmap {
    apr_bucket_refcount refcount;
    apr_mmap_t *mmap;
};
typedef struct apr_bucket_file apr_bucket_file;
struct apr_bucket_file {
    apr_bucket_refcount refcount;
    apr_file_t *fd;
    apr_pool_t *readpool;
    int can_mmap;
    apr_size_t read_size;
};
typedef union apr_bucket_structs apr_bucket_structs;
union apr_bucket_structs {
    apr_bucket b;
    apr_bucket_heap heap;
    apr_bucket_pool pool;
    apr_bucket_mmap mmap;
    apr_bucket_file file;
};
apr_bucket_brigade * apr_brigade_create(apr_pool_t *p,
                                                     apr_bucket_alloc_t *list);
apr_status_t apr_brigade_destroy(apr_bucket_brigade *b);
apr_status_t apr_brigade_cleanup(void *data);
apr_bucket_brigade * apr_brigade_split_ex(apr_bucket_brigade *b,
                                                       apr_bucket *e,
                                                       apr_bucket_brigade *a);
apr_bucket_brigade * apr_brigade_split(apr_bucket_brigade *b,
                                                    apr_bucket *e);
apr_status_t apr_brigade_partition(apr_bucket_brigade *b,
                                                apr_off_t point,
                                                apr_bucket **after_point);
apr_status_t apr_brigade_length(apr_bucket_brigade *bb,
                                             int read_all,
                                             apr_off_t *length);
apr_status_t apr_brigade_flatten(apr_bucket_brigade *bb,
                                              char *c,
                                              apr_size_t *len);
apr_status_t apr_brigade_pflatten(apr_bucket_brigade *bb,
                                               char **c,
                                               apr_size_t *len,
                                               apr_pool_t *pool);
apr_status_t apr_brigade_split_line(apr_bucket_brigade *bbOut,
                                                 apr_bucket_brigade *bbIn,
                                                 apr_read_type_e block,
                                                 apr_off_t maxbytes);
apr_status_t apr_brigade_to_iovec(apr_bucket_brigade *b,
                                               struct iovec *vec, int *nvec);
apr_status_t apr_brigade_vputstrs(apr_bucket_brigade *b,
                                               apr_brigade_flush flush,
                                               void *ctx,
                                               va_list va);
apr_status_t apr_brigade_write(apr_bucket_brigade *b,
                                            apr_brigade_flush flush, void *ctx,
                                            const char *str, apr_size_t nbyte);
apr_status_t apr_brigade_writev(apr_bucket_brigade *b,
                                             apr_brigade_flush flush,
                                             void *ctx,
                                             const struct iovec *vec,
                                             apr_size_t nvec);
apr_status_t apr_brigade_puts(apr_bucket_brigade *bb,
                                           apr_brigade_flush flush, void *ctx,
                                           const char *str);
apr_status_t apr_brigade_putc(apr_bucket_brigade *b,
                                           apr_brigade_flush flush, void *ctx,
                                           const char c);
apr_status_t apr_brigade_putstrs(apr_bucket_brigade *b,
                                                     apr_brigade_flush flush,
                                                     void *ctx, ...);
apr_status_t apr_brigade_printf(apr_bucket_brigade *b,
                                                    apr_brigade_flush flush,
                                                    void *ctx,
                                                    const char *fmt, ...)
        __attribute__((format(printf,4,5)));
apr_status_t apr_brigade_vprintf(apr_bucket_brigade *b,
                                              apr_brigade_flush flush,
                                              void *ctx,
                                              const char *fmt, va_list va);
apr_bucket * apr_brigade_insert_file(apr_bucket_brigade *bb,
                                                  apr_file_t *f,
                                                  apr_off_t start,
                                                  apr_off_t len,
                                                  apr_pool_t *p);
apr_bucket_alloc_t * apr_bucket_alloc_create(apr_pool_t *p);
apr_bucket_alloc_t * apr_bucket_alloc_create_ex(apr_allocator_t *allocator);
void apr_bucket_alloc_destroy(apr_bucket_alloc_t *list);
apr_size_t apr_bucket_alloc_aligned_floor(apr_bucket_alloc_t *list,
                                                              apr_size_t size)
                         __attribute__((nonnull(1)));
void * apr_bucket_alloc(apr_size_t size, apr_bucket_alloc_t *list);
void apr_bucket_free(void *block);
apr_status_t apr_bucket_setaside_noop(apr_bucket *data,
                                                          apr_pool_t *pool);
apr_status_t apr_bucket_setaside_notimpl(apr_bucket *data,
                                                             apr_pool_t *pool);
apr_status_t apr_bucket_split_notimpl(apr_bucket *data,
                                                          apr_size_t point);
apr_status_t apr_bucket_copy_notimpl(apr_bucket *e,
                                                         apr_bucket **c);
void apr_bucket_destroy_noop(void *data);
 extern const apr_bucket_type_t apr_bucket_type_flush;
 extern const apr_bucket_type_t apr_bucket_type_eos;
 extern const apr_bucket_type_t apr_bucket_type_file;
 extern const apr_bucket_type_t apr_bucket_type_heap;
 extern const apr_bucket_type_t apr_bucket_type_mmap;
 extern const apr_bucket_type_t apr_bucket_type_pool;
 extern const apr_bucket_type_t apr_bucket_type_pipe;
 extern const apr_bucket_type_t apr_bucket_type_immortal;
 extern const apr_bucket_type_t apr_bucket_type_transient;
 extern const apr_bucket_type_t apr_bucket_type_socket;
apr_status_t apr_bucket_simple_split(apr_bucket *b,
                                                         apr_size_t point);
apr_status_t apr_bucket_simple_copy(apr_bucket *a,
                                                        apr_bucket **b);
apr_bucket * apr_bucket_shared_make(apr_bucket *b, void *data,
                     apr_off_t start,
                                                 apr_size_t length);
int apr_bucket_shared_destroy(void *data);
apr_status_t apr_bucket_shared_split(apr_bucket *b,
                                                         apr_size_t point);
apr_status_t apr_bucket_shared_copy(apr_bucket *a,
                                                        apr_bucket **b);
apr_bucket * apr_bucket_eos_create(apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_eos_make(apr_bucket *b);
apr_bucket * apr_bucket_flush_create(apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_flush_make(apr_bucket *b);
apr_bucket * apr_bucket_immortal_create(const char *buf,
                                                     apr_size_t nbyte,
                                                     apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_immortal_make(apr_bucket *b,
                                                   const char *buf,
                                                   apr_size_t nbyte);
apr_bucket * apr_bucket_transient_create(const char *buf,
                                                      apr_size_t nbyte,
                                                      apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_transient_make(apr_bucket *b,
                                                    const char *buf,
                                                    apr_size_t nbyte);
apr_bucket * apr_bucket_heap_create(const char *buf,
                                                 apr_size_t nbyte,
                                                 void (*free_func)(void *data),
                                                 apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_heap_make(apr_bucket *b, const char *buf,
                                               apr_size_t nbyte,
                                               void (*free_func)(void *data));
apr_bucket * apr_bucket_pool_create(const char *buf,
                                                 apr_size_t length,
                                                 apr_pool_t *pool,
                                                 apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_pool_make(apr_bucket *b, const char *buf,
                                               apr_size_t length,
                                               apr_pool_t *pool);
apr_bucket * apr_bucket_mmap_create(apr_mmap_t *mm,
                                                 apr_off_t start,
                                                 apr_size_t length,
                                                 apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_mmap_make(apr_bucket *b, apr_mmap_t *mm,
                                               apr_off_t start,
                                               apr_size_t length);
apr_bucket * apr_bucket_socket_create(apr_socket_t *thissock,
                                                   apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_socket_make(apr_bucket *b,
                                                 apr_socket_t *thissock);
apr_bucket * apr_bucket_pipe_create(apr_file_t *thispipe,
                                                 apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_pipe_make(apr_bucket *b,
                                               apr_file_t *thispipe);
apr_bucket * apr_bucket_file_create(apr_file_t *fd,
                                                 apr_off_t offset,
                                                 apr_size_t len,
                                                 apr_pool_t *p,
                                                 apr_bucket_alloc_t *list);
apr_bucket * apr_bucket_file_make(apr_bucket *b, apr_file_t *fd,
                                               apr_off_t offset,
                                               apr_size_t len, apr_pool_t *p);
apr_status_t apr_bucket_file_enable_mmap(apr_bucket *b,
                                                      int enabled);
apr_status_t apr_bucket_file_set_buf_size(apr_bucket *b,
                                                       apr_size_t size);
typedef enum {
    APR_POLLSET_DEFAULT,
    APR_POLLSET_SELECT,
    APR_POLLSET_KQUEUE,
    APR_POLLSET_PORT,
    APR_POLLSET_EPOLL,
    APR_POLLSET_POLL,
    APR_POLLSET_AIO_MSGQ
} apr_pollset_method_e;
typedef enum {
    APR_NO_DESC,
    APR_POLL_SOCKET,
    APR_POLL_FILE,
    APR_POLL_LASTDESC
} apr_datatype_e ;
typedef union {
    apr_file_t *f;
    apr_socket_t *s;
} apr_descriptor;
typedef struct apr_pollfd_t apr_pollfd_t;
struct apr_pollfd_t {
    apr_pool_t *p;
    apr_datatype_e desc_type;
    apr_int16_t reqevents;
    apr_int16_t rtnevents;
    apr_descriptor desc;
    void *client_data;
};
typedef struct apr_pollset_t apr_pollset_t;
apr_status_t apr_pollset_create(apr_pollset_t **pollset,
                                             apr_uint32_t size,
                                             apr_pool_t *p,
                                             apr_uint32_t flags);
apr_status_t apr_pollset_create_ex(apr_pollset_t **pollset,
                                                apr_uint32_t size,
                                                apr_pool_t *p,
                                                apr_uint32_t flags,
                                                apr_pollset_method_e method);
apr_status_t apr_pollset_destroy(apr_pollset_t *pollset);
apr_status_t apr_pollset_add(apr_pollset_t *pollset,
                                          const apr_pollfd_t *descriptor);
apr_status_t apr_pollset_remove(apr_pollset_t *pollset,
                                             const apr_pollfd_t *descriptor);
apr_status_t apr_pollset_poll(apr_pollset_t *pollset,
                                           apr_interval_time_t timeout,
                                           apr_int32_t *num,
                                           const apr_pollfd_t **descriptors);
apr_status_t apr_pollset_wakeup(apr_pollset_t *pollset);
apr_status_t apr_poll(apr_pollfd_t *aprset, apr_int32_t numsock,
                                   apr_int32_t *nsds,
                                   apr_interval_time_t timeout);
const char * apr_pollset_method_name(apr_pollset_t *pollset);
const char * apr_poll_method_defname(void);
typedef struct apr_pollcb_t apr_pollcb_t;
apr_status_t apr_pollcb_create(apr_pollcb_t **pollcb,
                                            apr_uint32_t size,
                                            apr_pool_t *p,
                                            apr_uint32_t flags);
apr_status_t apr_pollcb_create_ex(apr_pollcb_t **pollcb,
                                               apr_uint32_t size,
                                               apr_pool_t *p,
                                               apr_uint32_t flags,
                                               apr_pollset_method_e method);
apr_status_t apr_pollcb_add(apr_pollcb_t *pollcb,
                                         apr_pollfd_t *descriptor);
apr_status_t apr_pollcb_remove(apr_pollcb_t *pollcb,
                                            apr_pollfd_t *descriptor);
typedef apr_status_t (*apr_pollcb_cb_t)(void *baton, apr_pollfd_t *descriptor);
apr_status_t apr_pollcb_poll(apr_pollcb_t *pollcb,
                                          apr_interval_time_t timeout,
                                          apr_pollcb_cb_t func,
                                          void *baton);
apr_status_t apr_pollcb_wakeup(apr_pollcb_t *pollcb);
const char * apr_pollcb_method_name(apr_pollcb_t *pollcb);

struct timezone
  {
    int tz_minuteswest;
    int tz_dsttime;
  };
extern int gettimeofday (struct timeval *__restrict __tv,
    void *__restrict __tz) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int settimeofday (const struct timeval *__tv,
    const struct timezone *__tz)
     __attribute__ ((__nothrow__ , __leaf__));
extern int adjtime (const struct timeval *__delta,
      struct timeval *__olddelta) __attribute__ ((__nothrow__ , __leaf__));
enum __itimer_which
  {
    ITIMER_REAL = 0,
    ITIMER_VIRTUAL = 1,
    ITIMER_PROF = 2
  };
struct itimerval
  {
    struct timeval it_interval;
    struct timeval it_value;
  };
typedef enum __itimer_which __itimer_which_t;
extern int getitimer (__itimer_which_t __which,
        struct itimerval *__value) __attribute__ ((__nothrow__ , __leaf__));
extern int setitimer (__itimer_which_t __which,
        const struct itimerval *__restrict __new,
        struct itimerval *__restrict __old) __attribute__ ((__nothrow__ , __leaf__));
extern int utimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int lutimes (const char *__file, const struct timeval __tvp[2])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int futimes (int __fd, const struct timeval __tvp[2]) __attribute__ ((__nothrow__ , __leaf__));
extern int futimesat (int __fd, const char *__file,
        const struct timeval __tvp[2]) __attribute__ ((__nothrow__ , __leaf__));

enum __rlimit_resource
{
  RLIMIT_CPU = 0,
  RLIMIT_FSIZE = 1,
  RLIMIT_DATA = 2,
  RLIMIT_STACK = 3,
  RLIMIT_CORE = 4,
  __RLIMIT_RSS = 5,
  RLIMIT_NOFILE = 7,
  __RLIMIT_OFILE = RLIMIT_NOFILE,
  RLIMIT_AS = 9,
  __RLIMIT_NPROC = 6,
  __RLIMIT_MEMLOCK = 8,
  __RLIMIT_LOCKS = 10,
  __RLIMIT_SIGPENDING = 11,
  __RLIMIT_MSGQUEUE = 12,
  __RLIMIT_NICE = 13,
  __RLIMIT_RTPRIO = 14,
  __RLIMIT_RTTIME = 15,
  __RLIMIT_NLIMITS = 16,
  __RLIM_NLIMITS = __RLIMIT_NLIMITS
};
typedef __rlim_t rlim_t;
typedef __rlim64_t rlim64_t;
struct rlimit
  {
    rlim_t rlim_cur;
    rlim_t rlim_max;
  };
struct rlimit64
  {
    rlim64_t rlim_cur;
    rlim64_t rlim_max;
 };
enum __rusage_who
{
  RUSAGE_SELF = 0,
  RUSAGE_CHILDREN = -1
  ,
  RUSAGE_THREAD = 1
};
struct rusage
  {
    struct timeval ru_utime;
    struct timeval ru_stime;
    __extension__ union
      {
 long int ru_maxrss;
 __syscall_slong_t __ru_maxrss_word;
      };
    __extension__ union
      {
 long int ru_ixrss;
 __syscall_slong_t __ru_ixrss_word;
      };
    __extension__ union
      {
 long int ru_idrss;
 __syscall_slong_t __ru_idrss_word;
      };
    __extension__ union
      {
 long int ru_isrss;
  __syscall_slong_t __ru_isrss_word;
      };
    __extension__ union
      {
 long int ru_minflt;
 __syscall_slong_t __ru_minflt_word;
      };
    __extension__ union
      {
 long int ru_majflt;
 __syscall_slong_t __ru_majflt_word;
      };
    __extension__ union
      {
 long int ru_nswap;
 __syscall_slong_t __ru_nswap_word;
      };
    __extension__ union
      {
 long int ru_inblock;
 __syscall_slong_t __ru_inblock_word;
      };
    __extension__ union
      {
 long int ru_oublock;
 __syscall_slong_t __ru_oublock_word;
      };
    __extension__ union
      {
 long int ru_msgsnd;
 __syscall_slong_t __ru_msgsnd_word;
      };
    __extension__ union
      {
 long int ru_msgrcv;
 __syscall_slong_t __ru_msgrcv_word;
      };
    __extension__ union
      {
 long int ru_nsignals;
 __syscall_slong_t __ru_nsignals_word;
      };
    __extension__ union
      {
 long int ru_nvcsw;
 __syscall_slong_t __ru_nvcsw_word;
      };
    __extension__ union
      {
 long int ru_nivcsw;
 __syscall_slong_t __ru_nivcsw_word;
      };
  };
enum __priority_which
{
  PRIO_PROCESS = 0,
  PRIO_PGRP = 1,
  PRIO_USER = 2
};

extern int prlimit (__pid_t __pid, enum __rlimit_resource __resource,
      const struct rlimit *__new_limit,
      struct rlimit *__old_limit) __attribute__ ((__nothrow__ , __leaf__));
extern int prlimit64 (__pid_t __pid, enum __rlimit_resource __resource,
        const struct rlimit64 *__new_limit,
        struct rlimit64 *__old_limit) __attribute__ ((__nothrow__ , __leaf__));


typedef enum __rlimit_resource __rlimit_resource_t;
typedef enum __rusage_who __rusage_who_t;
typedef enum __priority_which __priority_which_t;
extern int getrlimit (__rlimit_resource_t __resource,
        struct rlimit *__rlimits) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int getrlimit64 (__rlimit_resource_t __resource,
   struct rlimit64 *__rlimits) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int setrlimit (__rlimit_resource_t __resource,
        const struct rlimit *__rlimits) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int setrlimit64 (__rlimit_resource_t __resource,
   const struct rlimit64 *__rlimits) __attribute__ ((__nothrow__ , __leaf__))
   __attribute__ ((__nonnull__ (2)));
extern int getrusage (__rusage_who_t __who, struct rusage *__usage) __attribute__ ((__nothrow__ , __leaf__));
extern int getpriority (__priority_which_t __which, id_t __who) __attribute__ ((__nothrow__ , __leaf__));
extern int setpriority (__priority_which_t __which, id_t __who, int __prio)
     __attribute__ ((__nothrow__ , __leaf__));

typedef enum {
    APR_SHELLCMD,
    APR_PROGRAM,
    APR_PROGRAM_ENV,
    APR_PROGRAM_PATH,
    APR_SHELLCMD_ENV
} apr_cmdtype_e;
typedef enum {
    APR_WAIT,
    APR_NOWAIT
} apr_wait_how_e;
typedef enum {
    APR_PROC_EXIT = 1,
    APR_PROC_SIGNAL = 2,
    APR_PROC_SIGNAL_CORE = 4
} apr_exit_why_e;
typedef struct apr_proc_t {
    pid_t pid;
    apr_file_t *in;
    apr_file_t *out;
    apr_file_t *err;
} apr_proc_t;
typedef void (apr_child_errfn_t)(apr_pool_t *proc, apr_status_t err,
                                 const char *description);
typedef struct apr_thread_t apr_thread_t;
typedef struct apr_threadattr_t apr_threadattr_t;
typedef struct apr_procattr_t apr_procattr_t;
typedef struct apr_thread_once_t apr_thread_once_t;
typedef struct apr_threadkey_t apr_threadkey_t;
typedef struct apr_other_child_rec_t apr_other_child_rec_t;
typedef void *( *apr_thread_start_t)(apr_thread_t*, void*);
typedef enum {
    APR_KILL_NEVER,
    APR_KILL_ALWAYS,
    APR_KILL_AFTER_TIMEOUT,
    APR_JUST_WAIT,
    APR_KILL_ONLY_ONCE
} apr_kill_conditions_e;
apr_status_t apr_threadattr_create(apr_threadattr_t **new_attr,
                                                apr_pool_t *cont);
apr_status_t apr_threadattr_detach_set(apr_threadattr_t *attr,
                                                    apr_int32_t on);
apr_status_t apr_threadattr_detach_get(apr_threadattr_t *attr);
apr_status_t apr_threadattr_stacksize_set(apr_threadattr_t *attr,
                                                       apr_size_t stacksize);
apr_status_t apr_threadattr_guardsize_set(apr_threadattr_t *attr,
                                                       apr_size_t guardsize);
apr_status_t apr_thread_create(apr_thread_t **new_thread,
                                            apr_threadattr_t *attr,
                                            apr_thread_start_t func,
                                            void *data, apr_pool_t *cont);
apr_status_t apr_thread_exit(apr_thread_t *thd,
                                          apr_status_t retval);
apr_status_t apr_thread_join(apr_status_t *retval,
                                          apr_thread_t *thd);
void apr_thread_yield(void);
apr_status_t apr_thread_once_init(apr_thread_once_t **control,
                                               apr_pool_t *p);
apr_status_t apr_thread_once(apr_thread_once_t *control,
                                          void (*func)(void));
apr_status_t apr_thread_detach(apr_thread_t *thd);
apr_status_t apr_thread_data_get(void **data, const char *key,
                                             apr_thread_t *thread);
apr_status_t apr_thread_data_set(void *data, const char *key,
                                             apr_status_t (*cleanup) (void *),
                                             apr_thread_t *thread);
apr_status_t apr_threadkey_private_create(apr_threadkey_t **key,
                                                    void (*dest)(void *),
                                                    apr_pool_t *cont);
apr_status_t apr_threadkey_private_get(void **new_mem,
                                                 apr_threadkey_t *key);
apr_status_t apr_threadkey_private_set(void *priv,
                                                 apr_threadkey_t *key);
apr_status_t apr_threadkey_private_delete(apr_threadkey_t *key);
apr_status_t apr_threadkey_data_get(void **data, const char *key,
                                                apr_threadkey_t *threadkey);
apr_status_t apr_threadkey_data_set(void *data, const char *key,
                                                apr_status_t (*cleanup) (void *),
                                                apr_threadkey_t *threadkey);
apr_status_t apr_procattr_create(apr_procattr_t **new_attr,
                                                  apr_pool_t *cont);
apr_status_t apr_procattr_io_set(apr_procattr_t *attr,
                                             apr_int32_t in, apr_int32_t out,
                                             apr_int32_t err);
apr_status_t apr_procattr_child_in_set(struct apr_procattr_t *attr,
                                                  apr_file_t *child_in,
                                                  apr_file_t *parent_in);
apr_status_t apr_procattr_child_out_set(struct apr_procattr_t *attr,
                                                   apr_file_t *child_out,
                                                   apr_file_t *parent_out);
apr_status_t apr_procattr_child_err_set(struct apr_procattr_t *attr,
                                                   apr_file_t *child_err,
                                                   apr_file_t *parent_err);
apr_status_t apr_procattr_dir_set(apr_procattr_t *attr,
                                              const char *dir);
apr_status_t apr_procattr_cmdtype_set(apr_procattr_t *attr,
                                                  apr_cmdtype_e cmd);
apr_status_t apr_procattr_detach_set(apr_procattr_t *attr,
                                                 apr_int32_t detach);
apr_status_t apr_procattr_limit_set(apr_procattr_t *attr,
                                                apr_int32_t what,
                                                struct rlimit *limit);
apr_status_t apr_procattr_child_errfn_set(apr_procattr_t *attr,
                                                       apr_child_errfn_t *errfn);
apr_status_t apr_procattr_error_check_set(apr_procattr_t *attr,
                                                       apr_int32_t chk);
apr_status_t apr_procattr_addrspace_set(apr_procattr_t *attr,
                                                       apr_int32_t addrspace);
apr_status_t apr_procattr_user_set(apr_procattr_t *attr,
                                                const char *username,
                                                const char *password);
apr_status_t apr_procattr_group_set(apr_procattr_t *attr,
                                                 const char *groupname);
apr_status_t apr_procattr_perms_set_register(apr_procattr_t *attr,
                                                 apr_perms_setfn_t *perms_set_fn,
                                                 void *data,
                                                 apr_fileperms_t perms);
apr_status_t apr_proc_fork(apr_proc_t *proc, apr_pool_t *cont);
apr_status_t apr_proc_create(apr_proc_t *new_proc,
                                          const char *progname,
                                          const char * const *args,
                                          const char * const *env,
                                          apr_procattr_t *attr,
                                          apr_pool_t *pool);
apr_status_t apr_proc_wait(apr_proc_t *proc,
                                        int *exitcode, apr_exit_why_e *exitwhy,
                                        apr_wait_how_e waithow);
apr_status_t apr_proc_wait_all_procs(apr_proc_t *proc,
                                                  int *exitcode,
                                                  apr_exit_why_e *exitwhy,
                                                  apr_wait_how_e waithow,
                                                  apr_pool_t *p);
apr_status_t apr_proc_detach(int daemonize);
void apr_proc_other_child_register(apr_proc_t *proc,
                                           void (*maintenance) (int reason,
                                                                void *,
                                                                int status),
                                           void *data, apr_file_t *write_fd,
                                           apr_pool_t *p);
void apr_proc_other_child_unregister(void *data);
apr_status_t apr_proc_other_child_alert(apr_proc_t *proc,
                                                     int reason,
                                                     int status);
void apr_proc_other_child_refresh(apr_other_child_rec_t *ocr,
                                               int reason);
void apr_proc_other_child_refresh_all(int reason);
apr_status_t apr_proc_kill(apr_proc_t *proc, int sig);
void apr_pool_note_subprocess(apr_pool_t *a, apr_proc_t *proc,
                                           apr_kill_conditions_e how);
apr_status_t apr_setup_signal_thread(void);
apr_status_t apr_signal_thread(int(*signal_handler)(int signum));
apr_pool_t * apr_thread_pool_get (const apr_thread_t *thethread);
enum {
  AP_REG_PCRE_COMPILED = 0,
  AP_REG_PCRE_LOADED
};
enum {
  AP_REG_ASSERT = 1,
  AP_REG_ESPACE,
  AP_REG_INVARG,
  AP_REG_NOMATCH
};
typedef struct {
    void *re_pcre;
    int re_nsub;
    apr_size_t re_erroffset;
} ap_regex_t;
typedef struct {
    int rm_so;
    int rm_eo;
} ap_regmatch_t;
const char * ap_pcre_version_string(int which);
int ap_regcomp_get_default_cflags(void);
void ap_regcomp_set_default_cflags(int cflags);
int ap_regcomp_default_cflag_by_name(const char *name);
int ap_regcomp(ap_regex_t *preg, const char *regex, int cflags);
int ap_regexec(const ap_regex_t *preg, const char *string,
                           apr_size_t nmatch, ap_regmatch_t *pmatch, int eflags);
int ap_regexec_len(const ap_regex_t *preg, const char *buff,
                               apr_size_t len, apr_size_t nmatch,
                               ap_regmatch_t *pmatch, int eflags);
apr_size_t ap_regerror(int errcode, const ap_regex_t *preg,
                                   char *errbuf, apr_size_t errbuf_size);
int ap_regname(const ap_regex_t *preg,
                           apr_array_header_t *names, const char *prefix,
                           int upper);
void ap_regfree(ap_regex_t *preg);
typedef struct {
    ap_regex_t rx;
    apr_uint32_t flags;
    const char *subs;
    const char *match;
    apr_size_t nmatch;
    ap_regmatch_t *pmatch;
} ap_rxplus_t;
ap_rxplus_t* ap_rxplus_compile(apr_pool_t *pool, const char *pattern);
int ap_rxplus_exec(apr_pool_t *pool, ap_rxplus_t *rx,
                               const char *pattern, char **newpattern);
void ap_rxplus_match(ap_rxplus_t *rx, int n, int *len,
                                 const char **match);
char* ap_rxplus_pmatch(apr_pool_t *pool, ap_rxplus_t *rx, int n);

typedef struct
  {
    int quot;
    int rem;
  } div_t;
typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;
__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ , __leaf__)) ;
extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern _Float32 strtof32 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern _Float64 strtof64 (const char *__restrict __nptr,
     char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern _Float128 strtof128 (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern _Float32x strtof32x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern _Float64x strtof64x (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int strtol (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtol") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoul") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoll (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoll") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr, char **__restrict __endptr, int __base) __asm__ ("" "__isoc23_strtoull") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1)));
extern int strfromd (char *__dest, size_t __size, const char *__format,
       double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf (char *__dest, size_t __size, const char *__format,
       float __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfroml (char *__dest, size_t __size, const char *__format,
       long double __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf32 (char *__dest, size_t __size, const char * __format,
         _Float32 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf64 (char *__dest, size_t __size, const char * __format,
         _Float64 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf128 (char *__dest, size_t __size, const char * __format,
   _Float128 __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf32x (char *__dest, size_t __size, const char * __format,
   _Float32x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int strfromf64x (char *__dest, size_t __size, const char * __format,
   _Float64x __f)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern long int strtol_l (const char *__restrict __nptr,
     char **__restrict __endptr, int __base,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr,
        char **__restrict __endptr,
        int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr,
    char **__restrict __endptr, int __base,
    locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       int __base, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 4)));
extern long int strtol_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtol_l") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1, 4)));
extern unsigned long int strtoul_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoul_l") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern long long int strtoll_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoll_l") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1, 4)));
__extension__
extern unsigned long long int strtoull_l (const char *__restrict __nptr, char **__restrict __endptr, int __base, locale_t __loc) __asm__ ("" "__isoc23_strtoull_l") __attribute__ ((__nothrow__ , __leaf__))
     __attribute__ ((__nonnull__ (1, 4)));
extern double strtod_l (const char *__restrict __nptr,
   char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern float strtof_l (const char *__restrict __nptr,
         char **__restrict __endptr, locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern long double strtold_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern _Float32 strtof32_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern _Float64 strtof64_l (const char *__restrict __nptr,
       char **__restrict __endptr,
       locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern _Float128 strtof128_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern _Float32x strtof32x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern _Float64x strtof64x_l (const char *__restrict __nptr,
         char **__restrict __endptr,
         locale_t __loc)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern char *l64a (long int __n) __attribute__ ((__nothrow__ , __leaf__)) ;
extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern long int random (void) __attribute__ ((__nothrow__ , __leaf__));
extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));
extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };
extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));
extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int rand (void) __attribute__ ((__nothrow__ , __leaf__));
extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ , __leaf__));
extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ , __leaf__));
extern double drand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int lrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int mrand48 (void) __attribute__ ((__nothrow__ , __leaf__));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ , __leaf__));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;
  };
extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ , __leaf__)) ;
extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ , __leaf__)) ;
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;
extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_size__ (1, 2))) ;
extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__)) __attribute__ ((__alloc_size__ (2)));
extern void free (void *__ptr) __attribute__ ((__nothrow__ , __leaf__));
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__warn_unused_result__))
     __attribute__ ((__alloc_size__ (2, 3)))
    __attribute__ ((__malloc__ (__builtin_free, 1)));
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__ (reallocarray, 1)));

extern void *alloca (size_t __size) __attribute__ ((__nothrow__ , __leaf__));

extern void *valloc (size_t __size) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__))
     __attribute__ ((__alloc_size__ (1))) ;
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
     __attribute__ ((__alloc_size__ (2))) ;
extern void abort (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern void quick_exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern void _Exit (int __status) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__noreturn__));
extern char *getenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern char *secure_getenv (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int putenv (char *__string) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int clearenv (void) __attribute__ ((__nothrow__ , __leaf__));
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
extern int mkstemp64 (char *__template) __attribute__ ((__nonnull__ (1))) ;
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
extern int mkstemps64 (char *__template, int __suffixlen)
     __attribute__ ((__nonnull__ (1))) ;
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int mkostemp (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
extern int mkostemp64 (char *__template, int __flags) __attribute__ ((__nonnull__ (1))) ;
extern int mkostemps (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
extern int mkostemps64 (char *__template, int __suffixlen, int __flags)
     __attribute__ ((__nonnull__ (1))) ;
extern int system (const char *__command) ;
extern char *canonicalize_file_name (const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__malloc__))
     __attribute__ ((__malloc__ (__builtin_free, 1))) ;
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ , __leaf__)) ;
typedef int (*__compar_fn_t) (const void *, const void *);
typedef __compar_fn_t comparison_fn_t;
typedef int (*__compar_d_fn_t) (const void *, const void *, void *);
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
extern void qsort_r (void *__base, size_t __nmemb, size_t __size,
       __compar_d_fn_t __compar, void *__arg)
  __attribute__ ((__nonnull__ (1, 4)));
extern int abs (int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__)) ;
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;
extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3))) ;
extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));
extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__));
extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ , __leaf__));
extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ , __leaf__))
    __attribute__ ((__access__ (__read_only__, 2)));
extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__access__ (__write_only__, 1, 3)))
  __attribute__ ((__access__ (__read_only__, 2)));
extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) ;
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3))) ;
extern int posix_openpt (int __oflag) ;
extern int grantpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern int unlockpt (int __fd) __attribute__ ((__nothrow__ , __leaf__));
extern char *ptsname (int __fd) __attribute__ ((__nothrow__ , __leaf__)) ;
extern int ptsname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2))) __attribute__ ((__access__ (__write_only__, 2, 3)));
extern int getpt (void);
extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));

typedef struct {
    int major;
    int minor;
    int patch;
    const char *add_string;
} ap_version_t;
void ap_get_server_revision(ap_version_t *version);
const char * ap_get_server_banner(void);
const char * ap_get_server_description(void);
void ap_add_version_component(apr_pool_t *pconf, const char *component);
const char * ap_get_server_built(void);
typedef struct ap_method_list_t ap_method_list_t;
struct ap_method_list_t {
    apr_int64_t method_mask;
    apr_array_header_t *method_list;
};
typedef apr_uint64_t ap_request_bnotes_t;
struct htaccess_result {
    const char *dir;
    int override;
    int override_opts;
    apr_table_t *override_list;
    struct ap_conf_vector_t *htaccess;
    const struct htaccess_result *next;
};
typedef struct process_rec process_rec;
typedef struct server_rec server_rec;
typedef struct conn_rec conn_rec;
typedef struct request_rec request_rec;
typedef struct conn_state_t conn_state_t;
typedef struct apr_uri_t apr_uri_t;
struct apr_uri_t {
    char *scheme;
    char *hostinfo;
    char *user;
    char *password;
    char *hostname;
    char *port_str;
    char *path;
    char *query;
    char *fragment;
    struct hostent *hostent;
    apr_port_t port;
    unsigned is_initialized:1;
    unsigned dns_looked_up:1;
    unsigned dns_resolved:1;
};
apr_port_t apr_uri_port_of_scheme(const char *scheme_str);
char * apr_uri_unparse(apr_pool_t *p,
                                    const apr_uri_t *uptr,
                                    unsigned flags);
apr_status_t apr_uri_parse(apr_pool_t *p, const char *uri,
                                        apr_uri_t *uptr);
apr_status_t apr_uri_parse_hostinfo(apr_pool_t *p,
                                                 const char *hostinfo,
                                                 apr_uri_t *uptr);
struct process_rec {
    apr_pool_t *pool;
    apr_pool_t *pconf;
    const char *short_name;
    const char * const *argv;
    int argc;
};
struct request_rec {
    apr_pool_t *pool;
    conn_rec *connection;
    server_rec *server;
    request_rec *next;
    request_rec *prev;
    request_rec *main;
    char *the_request;
    int assbackwards;
    int proxyreq;
    int header_only;
    int proto_num;
    char *protocol;
    const char *hostname;
    apr_time_t request_time;
    const char *status_line;
    int status;
    int method_number;
    const char *method;
    apr_int64_t allowed;
    apr_array_header_t *allowed_xmethods;
    ap_method_list_t *allowed_methods;
    apr_off_t sent_bodyct;
    apr_off_t bytes_sent;
    apr_time_t mtime;
    const char *range;
    apr_off_t clength;
    int chunked;
    int read_body;
    int read_chunked;
    unsigned expecting_100;
    apr_bucket_brigade *kept_body;
    apr_table_t *body_table;
    apr_off_t remaining;
    apr_off_t read_length;
    apr_table_t *headers_in;
    apr_table_t *headers_out;
    apr_table_t *err_headers_out;
    apr_table_t *subprocess_env;
    apr_table_t *notes;
    const char *content_type;
    const char *handler;
    const char *content_encoding;
    apr_array_header_t *content_languages;
    char *vlist_validator;
    char *user;
    char *ap_auth_type;
    char *unparsed_uri;
    char *uri;
    char *filename;
    char *canonical_filename;
    char *path_info;
    char *args;
    int used_path_info;
    int eos_sent;
    struct ap_conf_vector_t *per_dir_config;
    struct ap_conf_vector_t *request_config;
    const struct ap_logconf *log;
    const char *log_id;
    const struct htaccess_result *htaccess;
    struct ap_filter_t *output_filters;
    struct ap_filter_t *input_filters;
    struct ap_filter_t *proto_output_filters;
    struct ap_filter_t *proto_input_filters;
    int no_cache;
    int no_local_copy;
    apr_thread_mutex_t *invoke_mtx;
    apr_uri_t parsed_uri;
    apr_finfo_t finfo;
    apr_sockaddr_t *useragent_addr;
    char *useragent_ip;
    apr_table_t *trailers_in;
    apr_table_t *trailers_out;
    char *useragent_host;
    int double_reverse;
    ap_request_bnotes_t bnotes;
};
typedef enum {
    AP_CONN_UNKNOWN,
    AP_CONN_CLOSE,
    AP_CONN_KEEPALIVE
} ap_conn_keepalive_e;
struct conn_rec {
    apr_pool_t *pool;
    server_rec *base_server;
    void *vhost_lookup_data;
    apr_sockaddr_t *local_addr;
    apr_sockaddr_t *client_addr;
    char *client_ip;
    char *remote_host;
    char *remote_logname;
    char *local_ip;
    char *local_host;
    long id;
    struct ap_conf_vector_t *conn_config;
    apr_table_t *notes;
    struct ap_filter_t *input_filters;
    struct ap_filter_t *output_filters;
    void *sbh;
    struct apr_bucket_alloc_t *bucket_alloc;
    conn_state_t *cs;
    int data_in_input_filters;
    int data_in_output_filters;
    unsigned int clogging_input_filters:1;
    signed int double_reverse:2;
    unsigned aborted;
    ap_conn_keepalive_e keepalive;
    int keepalives;
    const struct ap_logconf *log;
    const char *log_id;
    apr_thread_t *current_thread;
    conn_rec *master;
    int outgoing;
};
typedef enum {
    CONN_STATE_KEEPALIVE,
    CONN_STATE_PROCESSING,
    CONN_STATE_HANDLER,
    CONN_STATE_WRITE_COMPLETION,
    CONN_STATE_SUSPENDED,
    CONN_STATE_LINGER,
    CONN_STATE_LINGER_NORMAL,
    CONN_STATE_LINGER_SHORT,
    CONN_STATE_ASYNC_WAITIO,
    CONN_STATE_NUM,
    CONN_STATE_CHECK_REQUEST_LINE_READABLE = CONN_STATE_KEEPALIVE,
    CONN_STATE_READ_REQUEST_LINE = CONN_STATE_PROCESSING,
} conn_state_e;
typedef enum {
    CONN_SENSE_DEFAULT,
    CONN_SENSE_WANT_READ,
    CONN_SENSE_WANT_WRITE
} conn_sense_e;
struct conn_state_t {
    conn_state_e state;
    conn_sense_e sense;
};
typedef struct server_addr_rec server_addr_rec;
struct server_addr_rec {
    server_addr_rec *next;
    char *virthost;
    apr_sockaddr_t *host_addr;
    apr_port_t host_port;
};
struct ap_logconf {
    signed char *module_levels;
    int level;
};
struct server_rec {
    process_rec *process;
    server_rec *next;
    char *error_fname;
    apr_file_t *error_log;
    struct ap_logconf log;
    struct ap_conf_vector_t *module_config;
    struct ap_conf_vector_t *lookup_defaults;
    const char *defn_name;
    unsigned defn_line_number;
    char is_virtual;
    apr_port_t port;
    const char *server_scheme;
    char *server_admin;
    char *server_hostname;
    server_addr_rec *addrs;
    apr_interval_time_t timeout;
    apr_interval_time_t keep_alive_timeout;
    int keep_alive_max;
    int keep_alive;
    apr_array_header_t *names;
    apr_array_header_t *wild_names;
    const char *path;
    int pathlen;
    int limit_req_line;
    int limit_req_fieldsize;
    int limit_req_fields;
    void *context;
    unsigned int keep_alive_timeout_set:1;
};
typedef struct ap_sload_t ap_sload_t;
struct ap_sload_t {
    int idle;
    int busy;
    apr_off_t bytes_served;
    unsigned long access_count;
};
typedef struct ap_loadavg_t ap_loadavg_t;
struct ap_loadavg_t {
    float loadavg;
    float loadavg5;
    float loadavg15;
};
const char * ap_context_document_root(request_rec *r);
const char * ap_context_prefix(request_rec *r);
void ap_set_context_info(request_rec *r, const char *prefix,
                                     const char *document_root);
void ap_set_document_root(request_rec *r, const char *document_root);
char * ap_field_noparam(apr_pool_t *p, const char *intype);
char * ap_ht_time(apr_pool_t *p, apr_time_t t, const char *fmt, int gmt);
char * ap_getword(apr_pool_t *p, const char **line, char stop);
char * ap_getword_nc(apr_pool_t *p, char **line, char stop);
char * ap_getword_white(apr_pool_t *p, const char **line);
char * ap_getword_white_nc(apr_pool_t *p, char **line);
char * ap_getword_nulls(apr_pool_t *p, const char **line,
                                    char stop);
char * ap_getword_nulls_nc(apr_pool_t *p, char **line, char stop);
char * ap_getword_conf(apr_pool_t *p, const char **line);
char * ap_getword_conf_nc(apr_pool_t *p, char **line);
char * ap_getword_conf2(apr_pool_t *p, const char **line);
char * ap_getword_conf2_nc(apr_pool_t *p, char **line);
const char * ap_resolve_env(apr_pool_t *p, const char * word);
const char * ap_size_list_item(const char **field, int *len);
char * ap_get_list_item(apr_pool_t *p, const char **field);
int ap_find_list_item(apr_pool_t *p, const char *line, const char *tok);
int ap_find_etag_weak(apr_pool_t *p, const char *line, const char *tok);
int ap_find_etag_strong(apr_pool_t *p, const char *line, const char *tok);
const char * ap_scan_http_field_content(const char *ptr);
const char * ap_scan_http_token(const char *ptr);
const char * ap_scan_vchar_obstext(const char *ptr);
const char * ap_parse_token_list_strict(apr_pool_t *p, const char *tok,
                                                    apr_array_header_t **tokens,
                                                    int skip_invalid);
char * ap_get_token(apr_pool_t *p, const char **accept_line, int accept_white);
int ap_find_token(apr_pool_t *p, const char *line, const char *tok);
int ap_find_last_token(apr_pool_t *p, const char *line, const char *tok);
int ap_is_url(const char *u);
int ap_unescape_all(char *url);
int ap_unescape_url(char *url);
int ap_unescape_url_keep2f(char *url, int decode_slashes);
int ap_unescape_url_ex(char *url, unsigned int flags);
int ap_unescape_urlencoded(char *query);
void ap_no2slash(char *name);
void ap_no2slash_ex(char *name, int is_fs_path);
int ap_normalize_path(char *path, unsigned int flags);
void ap_getparents(char *name);
char * ap_escape_path_segment(apr_pool_t *p, const char *s);
char * ap_escape_path_segment_buffer(char *c, const char *s);
char * ap_os_escape_path(apr_pool_t *p, const char *path, int partial);
char * ap_escape_urlencoded(apr_pool_t *p, const char *s);
char * ap_escape_urlencoded_buffer(char *c, const char *s);
char * ap_escape_html2(apr_pool_t *p, const char *s, int toasc);
char * ap_escape_logitem(apr_pool_t *p, const char *str);
apr_size_t ap_escape_errorlog_item(char *dest, const char *source,
                                               apr_size_t buflen);
char * ap_construct_server(apr_pool_t *p, const char *hostname,
                                    apr_port_t port, const request_rec *r);
char * ap_escape_shell_cmd(apr_pool_t *p, const char *s);
int ap_count_dirs(const char *path);
char * ap_make_dirstr_prefix(char *d, const char *s, int n);
char * ap_make_dirstr_parent(apr_pool_t *p, const char *s);
char * ap_make_full_path(apr_pool_t *a, const char *dir, const char *f);
int ap_os_is_path_absolute(apr_pool_t *p, const char *dir);
int ap_is_matchexp(const char *str);
int ap_strcmp_match(const char *str, const char *expected);
int ap_strcasecmp_match(const char *str, const char *expected);
char * ap_strcasestr(const char *s1, const char *s2);
const char * ap_stripprefix(const char *bigstring,
                                        const char *prefix);
char * ap_pbase64decode(apr_pool_t *p, const char *bufcoded);
char * ap_pbase64encode(apr_pool_t *p, char *string);
ap_regex_t * ap_pregcomp(apr_pool_t *p, const char *pattern,
                                     int cflags);
void ap_pregfree(apr_pool_t *p, ap_regex_t *reg);
char * ap_pregsub(apr_pool_t *p, const char *input,
                              const char *source, apr_size_t nmatch,
                              ap_regmatch_t pmatch[]);
apr_status_t ap_pregsub_ex(apr_pool_t *p, char **result,
                                       const char *input, const char *source,
                                       apr_size_t nmatch,
                                       ap_regmatch_t pmatch[],
                                       apr_size_t maxlen);
void ap_content_type_tolower(char *s);
void ap_str_tolower(char *s);
void ap_str_toupper(char *s);
int ap_ind(const char *str, char c);
int ap_rind(const char *str, char c);
int ap_memeq_timingsafe(const void *buf1, const void *buf2,
                                    apr_size_t n);
int ap_streq_timingsafe(const char *sec1, const char *str2);
int ap_strneq_timingsafe(const char *sec1, const char *str2,
                                     apr_size_t n);
char * ap_escape_quotes(apr_pool_t *p, const char *instring);
char * ap_append_pid(apr_pool_t *p, const char *string,
                                 const char *delim);
int ap_parse_strict_length(apr_off_t *len, const char *str);
apr_status_t ap_timeout_parameter_parse(
                                               const char *timeout_parameter,
                                               apr_interval_time_t *timeout,
                                               const char *default_time_unit);
int ap_request_has_body(request_rec *r);
apr_status_t ap_pstr2_alnum(apr_pool_t *p, const char *src,
                                        const char **dest);
apr_status_t ap_str2_alnum(const char *src, char *dest);
typedef struct {
    const char *name;
    apr_bucket_brigade *value;
} ap_form_pair_t;
int ap_parse_form_data(request_rec *r, struct ap_filter_t *f,
                                   apr_array_header_t **ptr,
                                   apr_size_t num, apr_size_t size);
int ap_is_rdirectory(apr_pool_t *p, const char *name);
int ap_is_directory(apr_pool_t *p, const char *name);
char *ap_get_local_host(apr_pool_t *p);
void ap_log_assert(const char *szExp, const char *szFile, int nLine)
                            __attribute__((noreturn));
const char * ap_psignature(const char *prefix, request_rec *r);
char * ap_strchr(char *s, int c);
const char * ap_strchr_c(const char *s, int c);
char * ap_strrchr(char *s, int c);
const char * ap_strrchr_c(const char *s, int c);
char * ap_strstr(char *s, const char *c);
const char * ap_strstr_c(const char *s, const char *c);
void ap_random_insecure_bytes(void *buf, apr_size_t size);
apr_uint32_t ap_random_pick(apr_uint32_t min, apr_uint32_t max);
void ap_abort_on_oom(void) __attribute__((noreturn));
void * ap_malloc(size_t size)
                    __attribute__((malloc))
                    __attribute__((alloc_size(1)));
void * ap_calloc(size_t nelem, size_t size)
                   __attribute__((malloc))
                   __attribute__((alloc_size(1,2)));
void * ap_realloc(void *ptr, size_t size)
                   __attribute__((warn_unused_result))
                   __attribute__((alloc_size(2)));
apr_status_t ap_thread_create(apr_thread_t **thread,
                                          apr_threadattr_t *attr,
                                          apr_thread_start_t func,
                                          void *data, apr_pool_t *pool);
apr_status_t ap_thread_current_create(apr_thread_t **current,
                                                  apr_threadattr_t *attr,
                                                  apr_pool_t *pool);
void ap_thread_current_after_fork(void);
apr_thread_t * ap_thread_current(void);
apr_status_t ap_thread_main_create(apr_thread_t **thread,
                                               apr_pool_t *pool);
void ap_get_sload(ap_sload_t *ld);
void ap_get_loadavg(ap_loadavg_t *ld);
void ap_bin2hex(const void *src, apr_size_t srclen, char *dest);
char * ap_get_exec_line(apr_pool_t *p,
                                    const char *cmd,
                                    const char * const *argv);
int ap_array_str_index(const apr_array_header_t *array,
                                   const char *s,
                                   int start);
int ap_array_str_contains(const apr_array_header_t *array,
                                      const char *s);
int ap_cstr_casecmp(const char *s1, const char *s2);
int ap_cstr_casecmpn(const char *s1, const char *s2, apr_size_t n);
typedef struct ap_dir_match_t ap_dir_match_t;
struct ap_dir_match_t {
    apr_pool_t *p;
    apr_pool_t *ptemp;
    const char *prefix;
    const char *(*cb)(ap_dir_match_t *w, const char *fname);
    void *ctx;
    int flags;
    unsigned int depth;
};
const char *ap_dir_nofnmatch(ap_dir_match_t *w, const char *fname)
        __attribute__((nonnull(1,2)));
const char *ap_dir_fnmatch(ap_dir_match_t *w, const char *path,
        const char *fname) __attribute__((nonnull(1,3)));
int ap_is_chunked(apr_pool_t *p, const char *line);
apr_status_t ap_filepath_merge(char **newpath,
                                             const char *rootpath,
                                             const char *addpath,
                                             apr_int32_t flags,
                                             apr_pool_t *p);
apr_status_t ap_stat_check(const char *path, apr_pool_t *pool);
typedef enum {
    APR_LOCK_FCNTL,
    APR_LOCK_FLOCK,
    APR_LOCK_SYSVSEM,
    APR_LOCK_PROC_PTHREAD,
    APR_LOCK_POSIXSEM,
    APR_LOCK_DEFAULT,
    APR_LOCK_DEFAULT_TIMED
} apr_lockmech_e;
typedef struct apr_proc_mutex_t apr_proc_mutex_t;
apr_status_t apr_proc_mutex_create(apr_proc_mutex_t **mutex,
                                                const char *fname,
                                                apr_lockmech_e mech,
                                                apr_pool_t *pool);
apr_status_t apr_proc_mutex_child_init(apr_proc_mutex_t **mutex,
                                                    const char *fname,
                                                    apr_pool_t *pool);
apr_status_t apr_proc_mutex_lock(apr_proc_mutex_t *mutex);
apr_status_t apr_proc_mutex_trylock(apr_proc_mutex_t *mutex);
apr_status_t apr_proc_mutex_timedlock(apr_proc_mutex_t *mutex,
                                               apr_interval_time_t timeout);
apr_status_t apr_proc_mutex_unlock(apr_proc_mutex_t *mutex);
apr_status_t apr_proc_mutex_destroy(apr_proc_mutex_t *mutex);
apr_status_t apr_proc_mutex_cleanup(void *mutex);
const char * apr_proc_mutex_lockfile(apr_proc_mutex_t *mutex);
apr_lockmech_e apr_proc_mutex_mech(apr_proc_mutex_t *mutex);
const char * apr_proc_mutex_name(apr_proc_mutex_t *mutex);
const char * apr_proc_mutex_defname(void);
apr_status_t apr_proc_mutex_perms_set (void *theproc_mutex, apr_fileperms_t perms, apr_uid_t uid, apr_gid_t gid);
apr_pool_t * apr_proc_mutex_pool_get (const apr_proc_mutex_t *theproc_mutex);
typedef struct apr_global_mutex_t apr_global_mutex_t;
apr_status_t apr_global_mutex_create(apr_global_mutex_t **mutex,
                                                  const char *fname,
                                                  apr_lockmech_e mech,
                                                  apr_pool_t *pool);
apr_status_t apr_global_mutex_child_init(
                              apr_global_mutex_t **mutex,
                              const char *fname,
                              apr_pool_t *pool);
apr_status_t apr_global_mutex_lock(apr_global_mutex_t *mutex);
apr_status_t apr_global_mutex_trylock(apr_global_mutex_t *mutex);
apr_status_t apr_global_mutex_timedlock(apr_global_mutex_t *mutex,
                                                 apr_interval_time_t timeout);
apr_status_t apr_global_mutex_unlock(apr_global_mutex_t *mutex);
apr_status_t apr_global_mutex_destroy(apr_global_mutex_t *mutex);
const char * apr_global_mutex_lockfile(apr_global_mutex_t *mutex);
apr_lockmech_e apr_global_mutex_mech(apr_global_mutex_t *mutex);
const char * apr_global_mutex_name(apr_global_mutex_t *mutex);
apr_status_t apr_global_mutex_perms_set (void *theglobal_mutex, apr_fileperms_t perms, apr_uid_t uid, apr_gid_t gid);
apr_pool_t * apr_global_mutex_pool_get (const apr_global_mutex_t *theglobal_mutex);
typedef struct apr_dso_handle_t apr_dso_handle_t;
typedef void * apr_dso_handle_sym_t;
apr_status_t apr_dso_load(apr_dso_handle_t **res_handle,
                                       const char *path, apr_pool_t *ctx);
apr_status_t apr_dso_unload(apr_dso_handle_t *handle);
apr_status_t apr_dso_sym(apr_dso_handle_sym_t *ressym,
                                      apr_dso_handle_t *handle,
                                      const char *symname);
const char * apr_dso_error(apr_dso_handle_t *dso, char *buf, apr_size_t bufsize);
typedef struct apr_shm_t apr_shm_t;
apr_status_t apr_shm_create(apr_shm_t **m,
                                         apr_size_t reqsize,
                                         const char *filename,
                                         apr_pool_t *pool);
apr_status_t apr_shm_create_ex(apr_shm_t **m,
                                            apr_size_t reqsize,
                                            const char *filename,
                                            apr_pool_t *pool,
                                            apr_int32_t flags);
apr_status_t apr_shm_remove(const char *filename,
                                         apr_pool_t *pool);
apr_status_t apr_shm_delete(apr_shm_t *m);
apr_status_t apr_shm_destroy(apr_shm_t *m);
apr_status_t apr_shm_attach(apr_shm_t **m,
                                         const char *filename,
                                         apr_pool_t *pool);
apr_status_t apr_shm_attach_ex(apr_shm_t **m,
                                            const char *filename,
                                            apr_pool_t *pool,
                                            apr_int32_t flags);
apr_status_t apr_shm_detach(apr_shm_t *m);
void * apr_shm_baseaddr_get(const apr_shm_t *m);
apr_size_t apr_shm_size_get(const apr_shm_t *m);
apr_status_t apr_shm_perms_set (void *theshm, apr_fileperms_t perms, apr_uid_t uid, apr_gid_t gid);
apr_pool_t * apr_shm_pool_get (const apr_shm_t *theshm);

struct dirent
  {
    __ino_t d_ino;
    __off_t d_off;
    unsigned short int d_reclen;
    unsigned char d_type;
    char d_name[256];
  };
struct dirent64
  {
    __ino64_t d_ino;
    __off64_t d_off;
    unsigned short int d_reclen;
    unsigned char d_type;
    char d_name[256];
  };
enum
  {
    DT_UNKNOWN = 0,
    DT_FIFO = 1,
    DT_CHR = 2,
    DT_DIR = 4,
    DT_BLK = 6,
    DT_REG = 8,
    DT_LNK = 10,
    DT_SOCK = 12,
    DT_WHT = 14
  };
typedef struct __dirstream DIR;
extern int closedir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
extern DIR *opendir (const char *__name) __attribute__ ((__nonnull__ (1)))
 __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (closedir, 1)));
extern DIR *fdopendir (int __fd)
 __attribute__ ((__malloc__)) __attribute__ ((__malloc__ (closedir, 1)));
extern struct dirent *readdir (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
extern struct dirent64 *readdir64 (DIR *__dirp) __attribute__ ((__nonnull__ (1)));
extern int readdir_r (DIR *__restrict __dirp,
        struct dirent *__restrict __entry,
        struct dirent **__restrict __result)
     __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__deprecated__));
extern int readdir64_r (DIR *__restrict __dirp,
   struct dirent64 *__restrict __entry,
   struct dirent64 **__restrict __result)
  __attribute__ ((__nonnull__ (1, 2, 3))) __attribute__ ((__deprecated__));
extern void rewinddir (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern void seekdir (DIR *__dirp, long int __pos) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern long int telldir (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int dirfd (DIR *__dirp) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int scandir (const char *__restrict __dir,
      struct dirent ***__restrict __namelist,
      int (*__selector) (const struct dirent *),
      int (*__cmp) (const struct dirent **,
      const struct dirent **))
     __attribute__ ((__nonnull__ (1, 2)));
extern int scandir64 (const char *__restrict __dir,
        struct dirent64 ***__restrict __namelist,
        int (*__selector) (const struct dirent64 *),
        int (*__cmp) (const struct dirent64 **,
        const struct dirent64 **))
     __attribute__ ((__nonnull__ (1, 2)));
extern int scandirat (int __dfd, const char *__restrict __dir,
        struct dirent ***__restrict __namelist,
        int (*__selector) (const struct dirent *),
        int (*__cmp) (const struct dirent **,
        const struct dirent **))
     __attribute__ ((__nonnull__ (2, 3)));
extern int scandirat64 (int __dfd, const char *__restrict __dir,
   struct dirent64 ***__restrict __namelist,
   int (*__selector) (const struct dirent64 *),
   int (*__cmp) (const struct dirent64 **,
          const struct dirent64 **))
     __attribute__ ((__nonnull__ (2, 3)));
extern int alphasort (const struct dirent **__e1,
        const struct dirent **__e2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int alphasort64 (const struct dirent64 **__e1,
   const struct dirent64 **__e2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern __ssize_t getdirentries (int __fd, char *__restrict __buf,
    size_t __nbytes,
    __off_t *__restrict __basep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));
extern __ssize_t getdirentries64 (int __fd, char *__restrict __buf,
      size_t __nbytes,
      __off64_t *__restrict __basep)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 4)));
extern int versionsort (const struct dirent **__e1,
   const struct dirent **__e2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int versionsort64 (const struct dirent64 **__e1,
     const struct dirent64 **__e2)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern __ssize_t getdents64 (int __fd, void *__buffer, size_t __length)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));


struct flock
  {
    short int l_type;
    short int l_whence;
    __off_t l_start;
    __off_t l_len;
    __pid_t l_pid;
  };
struct flock64
  {
    short int l_type;
    short int l_whence;
    __off64_t l_start;
    __off64_t l_len;
    __pid_t l_pid;
  };
enum __pid_type
  {
    F_OWNER_TID = 0,
    F_OWNER_PID,
    F_OWNER_PGRP,
    F_OWNER_GID = F_OWNER_PGRP
  };
struct f_owner_ex
  {
    enum __pid_type type;
    __pid_t pid;
  };
struct file_handle
{
  unsigned int handle_bytes;
  int handle_type;
  unsigned char f_handle[0];
};

extern __ssize_t readahead (int __fd, __off64_t __offset, size_t __count)
    __attribute__ ((__nothrow__ , __leaf__));
extern int sync_file_range (int __fd, __off64_t __offset, __off64_t __count,
       unsigned int __flags);
extern __ssize_t vmsplice (int __fdout, const struct iovec *__iov,
      size_t __count, unsigned int __flags);
extern __ssize_t splice (int __fdin, __off64_t *__offin, int __fdout,
    __off64_t *__offout, size_t __len,
    unsigned int __flags);
extern __ssize_t tee (int __fdin, int __fdout, size_t __len,
        unsigned int __flags);
extern int fallocate (int __fd, int __mode, __off_t __offset, __off_t __len);
extern int fallocate64 (int __fd, int __mode, __off64_t __offset,
   __off64_t __len);
extern int name_to_handle_at (int __dfd, const char *__name,
         struct file_handle *__handle, int *__mnt_id,
         int __flags) __attribute__ ((__nothrow__ , __leaf__));
extern int open_by_handle_at (int __mountdirfd, struct file_handle *__handle,
         int __flags);

struct stat
  {
    __dev_t st_dev;
    __ino_t st_ino;
    __nlink_t st_nlink;
    __mode_t st_mode;
    __uid_t st_uid;
    __gid_t st_gid;
    int __pad0;
    __dev_t st_rdev;
    __off_t st_size;
    __blksize_t st_blksize;
    __blkcnt_t st_blocks;
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
    __syscall_slong_t __glibc_reserved[3];
  };
struct stat64
  {
    __dev_t st_dev;
    __ino64_t st_ino;
    __nlink_t st_nlink;
    __mode_t st_mode;
    __uid_t st_uid;
    __gid_t st_gid;
    int __pad0;
    __dev_t st_rdev;
    __off_t st_size;
    __blksize_t st_blksize;
    __blkcnt64_t st_blocks;
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
    __syscall_slong_t __glibc_reserved[3];
  };
extern int fcntl (int __fd, int __cmd, ...);
extern int fcntl64 (int __fd, int __cmd, ...);
extern int open (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
extern int open64 (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
extern int openat (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));
extern int openat64 (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));
extern int creat (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
extern int creat64 (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
extern int posix_fadvise (int __fd, off_t __offset, off_t __len,
     int __advise) __attribute__ ((__nothrow__ , __leaf__));
extern int posix_fadvise64 (int __fd, off64_t __offset, off64_t __len,
       int __advise) __attribute__ ((__nothrow__ , __leaf__));
extern int posix_fallocate (int __fd, off_t __offset, off_t __len);
extern int posix_fallocate64 (int __fd, off64_t __offset, off64_t __len);

struct sched_param
{
  int sched_priority;
};

extern int clone (int (*__fn) (void *__arg), void *__child_stack,
    int __flags, void *__arg, ...) __attribute__ ((__nothrow__ , __leaf__));
extern int unshare (int __flags) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_getcpu (void) __attribute__ ((__nothrow__ , __leaf__));
extern int getcpu (unsigned int *, unsigned int *) __attribute__ ((__nothrow__ , __leaf__));
extern int setns (int __fd, int __nstype) __attribute__ ((__nothrow__ , __leaf__));

typedef unsigned long int __cpu_mask;
typedef struct
{
  __cpu_mask __bits[1024 / (8 * sizeof (__cpu_mask))];
} cpu_set_t;

extern int __sched_cpucount (size_t __setsize, const cpu_set_t *__setp)
     __attribute__ ((__nothrow__ , __leaf__));
extern cpu_set_t *__sched_cpualloc (size_t __count) __attribute__ ((__nothrow__ , __leaf__)) ;
extern void __sched_cpufree (cpu_set_t *__set) __attribute__ ((__nothrow__ , __leaf__));


extern int sched_setparam (__pid_t __pid, const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__));
extern int sched_getparam (__pid_t __pid, struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_setscheduler (__pid_t __pid, int __policy,
          const struct sched_param *__param) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_getscheduler (__pid_t __pid) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_yield (void) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_get_priority_max (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_get_priority_min (int __algorithm) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_rr_get_interval (__pid_t __pid, struct timespec *__t) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_setaffinity (__pid_t __pid, size_t __cpusetsize,
         const cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));
extern int sched_getaffinity (__pid_t __pid, size_t __cpusetsize,
         cpu_set_t *__cpuset) __attribute__ ((__nothrow__ , __leaf__));

struct timex
{
  unsigned int modes;
  __syscall_slong_t offset;
  __syscall_slong_t freq;
  __syscall_slong_t maxerror;
  __syscall_slong_t esterror;
  int status;
  __syscall_slong_t constant;
  __syscall_slong_t precision;
  __syscall_slong_t tolerance;
  struct timeval time;
  __syscall_slong_t tick;
  __syscall_slong_t ppsfreq;
  __syscall_slong_t jitter;
  int shift;
  __syscall_slong_t stabil;
  __syscall_slong_t jitcnt;
  __syscall_slong_t calcnt;
  __syscall_slong_t errcnt;
  __syscall_slong_t stbcnt;
  int tai;
  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32; int :32;
  int :32; int :32; int :32;
};

extern int clock_adjtime (__clockid_t __clock_id, struct timex *__utx) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));

struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;
  long int tm_gmtoff;
  const char *tm_zone;
};
struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };
struct sigevent;

extern clock_t clock (void) __attribute__ ((__nothrow__ , __leaf__));
extern time_t time (time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
extern double difftime (time_t __time1, time_t __time0)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
extern size_t strftime (char *__restrict __s, size_t __maxsize,
   const char *__restrict __format,
   const struct tm *__restrict __tp)
   __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3, 4)));
extern char *strptime (const char *__restrict __s,
         const char *__restrict __fmt, struct tm *__tp)
     __attribute__ ((__nothrow__ , __leaf__));
extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     const char *__restrict __format,
     const struct tm *__restrict __tp,
     locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));
extern char *strptime_l (const char *__restrict __s,
    const char *__restrict __fmt, struct tm *__tp,
    locale_t __loc) __attribute__ ((__nothrow__ , __leaf__));
extern struct tm *gmtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
extern struct tm *localtime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
extern struct tm *gmtime_r (const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));
extern struct tm *localtime_r (const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__ , __leaf__));
extern char *asctime (const struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
extern char *ctime (const time_t *__timer) __attribute__ ((__nothrow__ , __leaf__));
extern char *asctime_r (const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));
extern char *ctime_r (const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__ , __leaf__));
extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;
extern char *tzname[2];
extern void tzset (void) __attribute__ ((__nothrow__ , __leaf__));
extern int daylight;
extern long int timezone;
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__ , __leaf__));
extern int dysize (int __year) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int nanosleep (const struct timespec *__requested_time,
        struct timespec *__remaining);
extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__ , __leaf__));
extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int clock_settime (clockid_t __clock_id, const struct timespec *__tp)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       const struct timespec *__req,
       struct timespec *__rem);
extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__ , __leaf__));
extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__ , __leaf__));
extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));
extern int timer_settime (timer_t __timerid, int __flags,
     const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__ , __leaf__));
extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__ , __leaf__));
extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__ , __leaf__));
extern int timespec_get (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int timespec_getres (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ , __leaf__));
extern int getdate_err;
extern struct tm *getdate (const char *__string);
extern int getdate_r (const char *__restrict __string,
        struct tm *__restrict __resbufp);

typedef long int __jmp_buf[8];
struct __jmp_buf_tag
  {
    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };
enum
{
  PTHREAD_CREATE_JOINABLE,
  PTHREAD_CREATE_DETACHED
};
enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP
  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL
  , PTHREAD_MUTEX_FAST_NP = PTHREAD_MUTEX_TIMED_NP
};
enum
{
  PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_ROBUST,
  PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST
};
enum
{
  PTHREAD_PRIO_NONE,
  PTHREAD_PRIO_INHERIT,
  PTHREAD_PRIO_PROTECT
};
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP
};
enum
{
  PTHREAD_INHERIT_SCHED,
  PTHREAD_EXPLICIT_SCHED
};
enum
{
  PTHREAD_SCOPE_SYSTEM,
  PTHREAD_SCOPE_PROCESS
};
enum
{
  PTHREAD_PROCESS_PRIVATE,
  PTHREAD_PROCESS_SHARED
};
struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);
  void *__arg;
  int __canceltype;
  struct _pthread_cleanup_buffer *__prev;
};
enum
{
  PTHREAD_CANCEL_ENABLE,
  PTHREAD_CANCEL_DISABLE
};
enum
{
  PTHREAD_CANCEL_DEFERRED,
  PTHREAD_CANCEL_ASYNCHRONOUS
};

extern int pthread_create (pthread_t *__restrict __newthread,
      const pthread_attr_t *__restrict __attr,
      void *(*__start_routine) (void *),
      void *__restrict __arg) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
extern void pthread_exit (void *__retval) __attribute__ ((__noreturn__));
extern int pthread_join (pthread_t __th, void **__thread_return);
extern int pthread_tryjoin_np (pthread_t __th, void **__thread_return) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_timedjoin_np (pthread_t __th, void **__thread_return,
     const struct timespec *__abstime);
extern int pthread_clockjoin_np (pthread_t __th, void **__thread_return,
                                 clockid_t __clockid,
     const struct timespec *__abstime);
extern int pthread_detach (pthread_t __th) __attribute__ ((__nothrow__ , __leaf__));
extern pthread_t pthread_self (void) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int pthread_equal (pthread_t __thread1, pthread_t __thread2)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__const__));
extern int pthread_attr_init (pthread_attr_t *__attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_destroy (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getdetachstate (const pthread_attr_t *__attr,
     int *__detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setdetachstate (pthread_attr_t *__attr,
     int __detachstate)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getguardsize (const pthread_attr_t *__attr,
          size_t *__guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setguardsize (pthread_attr_t *__attr,
          size_t __guardsize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getschedparam (const pthread_attr_t *__restrict __attr,
           struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setschedparam (pthread_attr_t *__restrict __attr,
           const struct sched_param *__restrict
           __param) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_getschedpolicy (const pthread_attr_t *__restrict
     __attr, int *__restrict __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setschedpolicy (pthread_attr_t *__attr, int __policy)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getinheritsched (const pthread_attr_t *__restrict
      __attr, int *__restrict __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setinheritsched (pthread_attr_t *__attr,
      int __inherit)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getscope (const pthread_attr_t *__restrict __attr,
      int *__restrict __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setscope (pthread_attr_t *__attr, int __scope)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getstackaddr (const pthread_attr_t *__restrict
          __attr, void **__restrict __stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__deprecated__));
extern int pthread_attr_setstackaddr (pthread_attr_t *__attr,
          void *__stackaddr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__));
extern int pthread_attr_getstacksize (const pthread_attr_t *__restrict
          __attr, size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setstacksize (pthread_attr_t *__attr,
          size_t __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getstack (const pthread_attr_t *__restrict __attr,
      void **__restrict __stackaddr,
      size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int pthread_attr_setstack (pthread_attr_t *__attr, void *__stackaddr,
      size_t __stacksize) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_setaffinity_np (pthread_attr_t *__attr,
     size_t __cpusetsize,
     const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_attr_getaffinity_np (const pthread_attr_t *__attr,
     size_t __cpusetsize,
     cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_getattr_default_np (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_setsigmask_np (pthread_attr_t *__attr,
           const __sigset_t *sigmask);
extern int pthread_attr_getsigmask_np (const pthread_attr_t *__attr,
           __sigset_t *sigmask);
extern int pthread_setattr_default_np (const pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_getattr_np (pthread_t __th, pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int pthread_setschedparam (pthread_t __target_thread, int __policy,
      const struct sched_param *__param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int pthread_getschedparam (pthread_t __target_thread,
      int *__restrict __policy,
      struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2, 3)));
extern int pthread_setschedprio (pthread_t __target_thread, int __prio)
     __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_getname_np (pthread_t __target_thread, char *__buf,
          size_t __buflen)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int pthread_setname_np (pthread_t __target_thread, const char *__name)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int pthread_getconcurrency (void) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_setconcurrency (int __level) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_yield (void) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_yield (void) __asm__ ("" "sched_yield") __attribute__ ((__nothrow__ , __leaf__))
  __attribute__ ((__deprecated__ ("pthread_yield is deprecated, use sched_yield instead")));
extern int pthread_setaffinity_np (pthread_t __th, size_t __cpusetsize,
       const cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int pthread_getaffinity_np (pthread_t __th, size_t __cpusetsize,
       cpu_set_t *__cpuset)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (3)));
extern int pthread_once (pthread_once_t *__once_control,
    void (*__init_routine) (void)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_setcancelstate (int __state, int *__oldstate);
extern int pthread_setcanceltype (int __type, int *__oldtype);
extern int pthread_cancel (pthread_t __th);
extern void pthread_testcancel (void);
struct __cancel_jmp_buf_tag
{
  __jmp_buf __cancel_jmp_buf;
  int __mask_was_saved;
};
typedef struct
{
  struct __cancel_jmp_buf_tag __cancel_jmp_buf[1];
  void *__pad[4];
} __pthread_unwind_buf_t __attribute__ ((__aligned__));
struct __pthread_cleanup_frame
{
  void (*__cancel_routine) (void *);
  void *__cancel_arg;
  int __do_it;
  int __cancel_type;
};
extern void __pthread_register_cancel (__pthread_unwind_buf_t *__buf)
     ;
extern void __pthread_unregister_cancel (__pthread_unwind_buf_t *__buf)
  ;
extern void __pthread_register_cancel_defer (__pthread_unwind_buf_t *__buf)
     ;
extern void __pthread_unregister_cancel_restore (__pthread_unwind_buf_t *__buf)
  ;
extern void __pthread_unwind_next (__pthread_unwind_buf_t *__buf)
     __attribute__ ((__noreturn__))
     __attribute__ ((__weak__))
     ;
extern int __sigsetjmp_cancel (struct __cancel_jmp_buf_tag __env[1], int __savemask) __asm__ ("" "__sigsetjmp") __attribute__ ((__nothrow__)) __attribute__ ((__returns_twice__));
extern int pthread_mutex_init (pthread_mutex_t *__mutex,
          const pthread_mutexattr_t *__mutexattr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_trylock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_lock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_timedlock (pthread_mutex_t *__restrict __mutex,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutex_clocklock (pthread_mutex_t *__restrict __mutex,
        clockid_t __clockid,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_mutex_unlock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_getprioceiling (const pthread_mutex_t *
      __restrict __mutex,
      int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutex_setprioceiling (pthread_mutex_t *__restrict __mutex,
      int __prioceiling,
      int *__restrict __old_ceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_mutex_consistent (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_consistent_np (pthread_mutex_t *) __asm__ ("" "pthread_mutex_consistent") __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutex_consistent_np is deprecated, use pthread_mutex_consistent")));
extern int pthread_mutexattr_init (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getpshared (const pthread_mutexattr_t *
      __restrict __attr,
      int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
      int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_gettype (const pthread_mutexattr_t *__restrict
          __attr, int *__restrict __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getprotocol (const pthread_mutexattr_t *
       __restrict __attr,
       int *__restrict __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setprotocol (pthread_mutexattr_t *__attr,
       int __protocol)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getprioceiling (const pthread_mutexattr_t *
          __restrict __attr,
          int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setprioceiling (pthread_mutexattr_t *__attr,
          int __prioceiling)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getrobust (const pthread_mutexattr_t *__attr,
     int *__robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_getrobust_np (pthread_mutexattr_t *, int *) __asm__ ("" "pthread_mutexattr_getrobust") __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_getrobust_np is deprecated, use pthread_mutexattr_getrobust")));
extern int pthread_mutexattr_setrobust (pthread_mutexattr_t *__attr,
     int __robustness)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_setrobust_np (pthread_mutexattr_t *, int) __asm__ ("" "pthread_mutexattr_setrobust") __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)))
  __attribute__ ((__deprecated__ ("pthread_mutexattr_setrobust_np is deprecated, use pthread_mutexattr_setrobust")));
extern int pthread_rwlock_init (pthread_rwlock_t *__restrict __rwlock,
    const pthread_rwlockattr_t *__restrict
    __attr) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_destroy (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_rdlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_tryrdlock (pthread_rwlock_t *__rwlock)
  __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_timedrdlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlock_clockrdlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_rwlock_wrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_trywrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_timedwrlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlock_clockwrlock (pthread_rwlock_t *__restrict __rwlock,
           clockid_t __clockid,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_rwlock_unlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_init (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_destroy (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_getpshared (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlockattr_setpshared (pthread_rwlockattr_t *__attr,
       int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_getkind_np (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pref)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlockattr_setkind_np (pthread_rwlockattr_t *__attr,
       int __pref) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_init (pthread_cond_t *__restrict __cond,
         const pthread_condattr_t *__restrict __cond_attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_destroy (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_signal (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_broadcast (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_wait (pthread_cond_t *__restrict __cond,
         pthread_mutex_t *__restrict __mutex)
     __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_cond_timedwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 3)));
extern int pthread_cond_clockwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       __clockid_t __clock_id,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 4)));
extern int pthread_condattr_init (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_destroy (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_getpshared (const pthread_condattr_t *
     __restrict __attr,
     int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_condattr_setpshared (pthread_condattr_t *__attr,
     int __pshared) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_getclock (const pthread_condattr_t *
          __restrict __attr,
          __clockid_t *__restrict __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_condattr_setclock (pthread_condattr_t *__attr,
          __clockid_t __clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_init (pthread_spinlock_t *__lock, int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_destroy (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_lock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_trylock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_unlock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_init (pthread_barrier_t *__restrict __barrier,
     const pthread_barrierattr_t *__restrict
     __attr, unsigned int __count)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_destroy (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_wait (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_init (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_destroy (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_getpshared (const pthread_barrierattr_t *
        __restrict __attr,
        int *__restrict __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_barrierattr_setpshared (pthread_barrierattr_t *__attr,
        int __pshared)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_key_create (pthread_key_t *__key,
          void (*__destr_function) (void *))
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_key_delete (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));
extern void *pthread_getspecific (pthread_key_t __key) __attribute__ ((__nothrow__ , __leaf__));
extern int pthread_setspecific (pthread_key_t __key,
    const void *__pointer)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__access__ (__none__, 2)));
extern int pthread_getcpuclockid (pthread_t __thread_id,
      __clockid_t *__clock_id)
     __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (2)));
extern int pthread_atfork (void (*__prepare) (void),
      void (*__parent) (void),
      void (*__child) (void)) __attribute__ ((__nothrow__ , __leaf__));

typedef union
{
  char __size[32];
  long int __align;
} sem_t;

extern int sem_init (sem_t *__sem, int __pshared, unsigned int __value)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sem_destroy (sem_t *__sem) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern sem_t *sem_open (const char *__name, int __oflag, ...)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sem_close (sem_t *__sem) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sem_unlink (const char *__name) __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1)));
extern int sem_wait (sem_t *__sem) __attribute__ ((__nonnull__ (1)));
extern int sem_timedwait (sem_t *__restrict __sem,
     const struct timespec *__restrict __abstime)
  __attribute__ ((__nonnull__ (1, 2)));
extern int sem_clockwait (sem_t *__restrict __sem,
     clockid_t clock,
     const struct timespec *__restrict __abstime)
  __attribute__ ((__nonnull__ (1, 3)));
extern int sem_trywait (sem_t *__sem) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int sem_post (sem_t *__sem) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int sem_getvalue (sem_t *__restrict __sem, int *__restrict __sval)
  __attribute__ ((__nothrow__ , __leaf__)) __attribute__ ((__nonnull__ (1, 2)));

struct apr_os_proc_mutex_t {
    int crossproc;
    pthread_mutex_t *pthread_interproc;
    pthread_mutex_t *intraproc;
    sem_t *psem_interproc;
};
typedef int apr_os_file_t;
typedef DIR apr_os_dir_t;
typedef int apr_os_sock_t;
typedef struct apr_os_proc_mutex_t apr_os_proc_mutex_t;
typedef pthread_t apr_os_thread_t;
typedef pthread_key_t apr_os_threadkey_t;
typedef pid_t apr_os_proc_t;
typedef struct timeval apr_os_imp_time_t;
typedef struct tm apr_os_exp_time_t;
typedef void * apr_os_dso_handle_t;
typedef void* apr_os_shm_t;
struct apr_os_sock_info_t {
    apr_os_sock_t *os_sock;
    struct sockaddr *local;
    struct sockaddr *remote;
    int family;
    int type;
    int protocol;
};
typedef struct apr_os_sock_info_t apr_os_sock_info_t;
    struct apr_os_global_mutex_t {
        apr_pool_t *pool;
        apr_proc_mutex_t *proc_mutex;
        apr_thread_mutex_t *thread_mutex;
    };
    typedef struct apr_os_global_mutex_t apr_os_global_mutex_t;
apr_status_t apr_os_global_mutex_get(apr_os_global_mutex_t *ospmutex,
                                                apr_global_mutex_t *pmutex);
apr_status_t apr_os_file_get(apr_os_file_t *thefile,
                                          apr_file_t *file);
apr_status_t apr_os_dir_get(apr_os_dir_t **thedir,
                                         apr_dir_t *dir);
apr_status_t apr_os_sock_get(apr_os_sock_t *thesock,
                                          apr_socket_t *sock);
apr_status_t apr_os_proc_mutex_get(apr_os_proc_mutex_t *ospmutex,
                                                apr_proc_mutex_t *pmutex);
apr_status_t apr_os_proc_mutex_get_ex(apr_os_proc_mutex_t *ospmutex,
                                                   apr_proc_mutex_t *pmutex,
                                                   apr_lockmech_e *mech);
apr_status_t apr_os_exp_time_get(apr_os_exp_time_t **ostime,
                                 apr_time_exp_t *aprtime);
apr_status_t apr_os_imp_time_get(apr_os_imp_time_t **ostime,
                                              apr_time_t *aprtime);
apr_status_t apr_os_shm_get(apr_os_shm_t *osshm,
                                         apr_shm_t *shm);
apr_status_t apr_os_thread_get(apr_os_thread_t **thethd,
                                            apr_thread_t *thd);
apr_status_t apr_os_threadkey_get(apr_os_threadkey_t *thekey,
                                               apr_threadkey_t *key);
apr_status_t apr_os_thread_put(apr_thread_t **thd,
                                            apr_os_thread_t *thethd,
                                            apr_pool_t *cont);
apr_status_t apr_os_threadkey_put(apr_threadkey_t **key,
                                               apr_os_threadkey_t *thekey,
                                               apr_pool_t *cont);
apr_os_thread_t apr_os_thread_current(void);
int apr_os_thread_equal(apr_os_thread_t tid1,
                                     apr_os_thread_t tid2);
apr_status_t apr_os_file_put(apr_file_t **file,
                                          apr_os_file_t *thefile,
                                          apr_int32_t flags, apr_pool_t *cont);
apr_status_t apr_os_pipe_put(apr_file_t **file,
                                          apr_os_file_t *thefile,
                                          apr_pool_t *cont);
apr_status_t apr_os_pipe_put_ex(apr_file_t **file,
                                             apr_os_file_t *thefile,
                                             int register_cleanup,
                                             apr_pool_t *cont);
apr_status_t apr_os_dir_put(apr_dir_t **dir,
                                         apr_os_dir_t *thedir,
                                         apr_pool_t *cont);
apr_status_t apr_os_sock_put(apr_socket_t **sock,
                                          apr_os_sock_t *thesock,
                                          apr_pool_t *cont);
apr_status_t apr_os_sock_make(apr_socket_t **apr_sock,
                                           apr_os_sock_info_t *os_sock_info,
                                           apr_pool_t *cont);
apr_status_t apr_os_proc_mutex_put(apr_proc_mutex_t **pmutex,
                                                apr_os_proc_mutex_t *ospmutex,
                                                apr_pool_t *cont);
apr_status_t apr_os_proc_mutex_put_ex(apr_proc_mutex_t **pmutex,
                                                apr_os_proc_mutex_t *ospmutex,
                                                apr_lockmech_e mech,
                                                int register_cleanup,
                                                apr_pool_t *cont);
apr_status_t apr_os_imp_time_put(apr_time_t *aprtime,
                                              apr_os_imp_time_t **ostime,
                                              apr_pool_t *cont);
apr_status_t apr_os_exp_time_put(apr_time_exp_t *aprtime,
                                              apr_os_exp_time_t **ostime,
                                              apr_pool_t *cont);
apr_status_t apr_os_shm_put(apr_shm_t **shm,
                                         apr_os_shm_t *osshm,
                                         apr_pool_t *cont);
apr_status_t apr_os_dso_handle_put(apr_dso_handle_t **dso,
                                                apr_os_dso_handle_t thedso,
                                                apr_pool_t *pool);
apr_status_t apr_os_dso_handle_get(apr_os_dso_handle_t *dso,
                                                apr_dso_handle_t *aprdso);
apr_status_t apr_os_uuid_get(unsigned char *uuid_data);
const char* apr_os_default_encoding(apr_pool_t *pool);
const char* apr_os_locale_encoding(apr_pool_t *pool);
typedef enum {
    AP_MODE_READBYTES,
    AP_MODE_GETLINE,
    AP_MODE_EATCRLF,
    AP_MODE_SPECULATIVE,
    AP_MODE_EXHAUSTIVE,
    AP_MODE_INIT
} ap_input_mode_t;
typedef struct ap_filter_t ap_filter_t;
typedef apr_status_t (*ap_out_filter_func)(ap_filter_t *f,
                                           apr_bucket_brigade *b);
typedef apr_status_t (*ap_in_filter_func)(ap_filter_t *f,
                                          apr_bucket_brigade *b,
                                          ap_input_mode_t mode,
                                          apr_read_type_e block,
                                          apr_off_t readbytes);
typedef int (*ap_init_filter_func)(ap_filter_t *f);
typedef union ap_filter_func {
    ap_out_filter_func out_func;
    ap_in_filter_func in_func;
} ap_filter_func;
typedef enum {
    AP_FTYPE_RESOURCE = 10,
    AP_FTYPE_CONTENT_SET = 20,
    AP_FTYPE_PROTOCOL = 30,
    AP_FTYPE_TRANSCODE = 40,
    AP_FTYPE_CONNECTION = 50,
    AP_FTYPE_NETWORK = 60
} ap_filter_type;
typedef struct ap_filter_rec_t ap_filter_rec_t;
typedef struct ap_filter_provider_t ap_filter_provider_t;
struct ap_filter_rec_t {
    const char *name;
    ap_filter_func filter_func;
    ap_init_filter_func filter_init_func;
    struct ap_filter_rec_t *next;
    ap_filter_provider_t *providers;
    ap_filter_type ftype;
    int debug;
    unsigned int proto_flags;
};
struct ap_filter_t {
    ap_filter_rec_t *frec;
    void *ctx;
    ap_filter_t *next;
    request_rec *r;
    conn_rec *c;
};
apr_status_t ap_get_brigade(ap_filter_t *filter,
                                        apr_bucket_brigade *bucket,
                                        ap_input_mode_t mode,
                                        apr_read_type_e block,
                                        apr_off_t readbytes);
apr_status_t ap_pass_brigade(ap_filter_t *filter,
                                         apr_bucket_brigade *bucket);
apr_status_t ap_pass_brigade_fchk(request_rec *r,
                                              apr_bucket_brigade *bucket,
                                              const char *fmt,
                                              ...)
                                              __attribute__((format(printf,3,4)));
ap_filter_rec_t * ap_register_input_filter(const char *name,
                                          ap_in_filter_func filter_func,
                                          ap_init_filter_func filter_init,
                                          ap_filter_type ftype);
ap_filter_rec_t * ap_register_output_filter(const char *name,
                                            ap_out_filter_func filter_func,
                                            ap_init_filter_func filter_init,
                                            ap_filter_type ftype);
ap_filter_rec_t * ap_register_output_filter_protocol(
                                            const char *name,
                                            ap_out_filter_func filter_func,
                                            ap_init_filter_func filter_init,
                                            ap_filter_type ftype,
                                            unsigned int proto_flags);
ap_filter_t * ap_add_input_filter(const char *name, void *ctx,
                                              request_rec *r, conn_rec *c);
ap_filter_t * ap_add_input_filter_handle(ap_filter_rec_t *f,
                                                     void *ctx,
                                                     request_rec *r,
                                                     conn_rec *c);
ap_filter_rec_t * ap_get_input_filter_handle(const char *name);
ap_filter_t * ap_add_output_filter(const char *name, void *ctx,
                                               request_rec *r, conn_rec *c);
ap_filter_t * ap_add_output_filter_handle(ap_filter_rec_t *f,
                                                      void *ctx,
                                                      request_rec *r,
                                                      conn_rec *c);
ap_filter_rec_t * ap_get_output_filter_handle(const char *name);
void ap_remove_input_filter(ap_filter_t *f);
void ap_remove_output_filter(ap_filter_t *f);
apr_status_t ap_remove_input_filter_byhandle(ap_filter_t *next,
                                                         const char *handle);
apr_status_t ap_remove_output_filter_byhandle(ap_filter_t *next,
                                                          const char *handle);
apr_status_t ap_save_brigade(ap_filter_t *f,
                                         apr_bucket_brigade **save_to,
                                         apr_bucket_brigade **b, apr_pool_t *p);
apr_status_t ap_filter_flush(apr_bucket_brigade *bb,
                                                void *ctx);
apr_status_t ap_fflush(ap_filter_t *f, apr_bucket_brigade *bb);
apr_status_t ap_fputstrs(ap_filter_t *f,
                                            apr_bucket_brigade *bb,
                                            ...)
                                __attribute__((sentinel));
apr_status_t ap_fprintf(ap_filter_t *f,
                                           apr_bucket_brigade *bb,
                                           const char *fmt,
                                           ...)
        __attribute__((format(printf,3,4)));
void ap_filter_protocol(ap_filter_t* f, unsigned int proto_flags);
typedef void ap_HOOK_insert_error_filter_t (request_rec *r); void ap_hook_insert_error_filter(ap_HOOK_insert_error_filter_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_insert_error_filter (request_rec *r); apr_array_header_t * ap_hook_get_insert_error_filter(void); typedef struct ap_LINK_insert_error_filter_t { ap_HOOK_insert_error_filter_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_insert_error_filter_t;
 extern ap_filter_rec_t *ap_old_write_func;
request_rec * ap_create_request(conn_rec *c);
request_rec *ap_read_request(conn_rec *c);
int ap_parse_request_line(request_rec *r);
int ap_check_request_header(request_rec *r);
void ap_get_mime_headers(request_rec *r);
void ap_get_mime_headers_core(request_rec *r,
                                          apr_bucket_brigade *bb);
int ap_post_read_request(request_rec *r);
void ap_finalize_request_protocol(request_rec *r);
void ap_send_error_response(request_rec *r, int recursive_error);
void ap_set_content_length(request_rec *r, apr_off_t length);
int ap_set_keepalive(request_rec *r);
apr_time_t ap_rationalize_mtime(request_rec *r, apr_time_t mtime);
const char * ap_make_content_type(request_rec *r,
                                              const char *type);
void ap_setup_make_content_type(apr_pool_t *pool);
typedef struct etag_rec etag_rec;
struct etag_rec {
    const char *vlist_validator;
    apr_time_t request_time;
    apr_finfo_t *finfo;
    const char *pathname;
    apr_file_t *fd;
    int force_weak;
};
char * ap_make_etag(request_rec *r, int force_weak);
char * ap_make_etag_ex(request_rec *r, etag_rec *er);
void ap_set_etag(request_rec *r);
void ap_set_etag_fd(request_rec *r, apr_file_t *fd);
void ap_set_last_modified(request_rec *r);
typedef enum {
    AP_CONDITION_NONE,
    AP_CONDITION_NOMATCH,
    AP_CONDITION_WEAK,
    AP_CONDITION_STRONG
} ap_condition_e;
ap_condition_e ap_condition_if_match(request_rec *r,
        apr_table_t *headers);
ap_condition_e ap_condition_if_unmodified_since(request_rec *r,
        apr_table_t *headers);
ap_condition_e ap_condition_if_none_match(request_rec *r,
        apr_table_t *headers);
ap_condition_e ap_condition_if_modified_since(request_rec *r,
        apr_table_t *headers);
ap_condition_e ap_condition_if_range(request_rec *r,
        apr_table_t *headers);
int ap_meets_conditions(request_rec *r);
apr_status_t ap_send_fd(apr_file_t *fd, request_rec *r, apr_off_t offset,
                                   apr_size_t length, apr_size_t *nbytes);
apr_size_t ap_send_mmap(apr_mmap_t *mm,
                                    request_rec *r,
                                    apr_size_t offset,
                                    apr_size_t length);
int ap_method_register(apr_pool_t *p, const char *methname);
void ap_method_registry_init(apr_pool_t *p);
ap_method_list_t * ap_make_method_list(apr_pool_t *p, int nelts);
void ap_copy_method_list(ap_method_list_t *dest,
                                     ap_method_list_t *src);
int ap_method_in_list(ap_method_list_t *l, const char *method);
void ap_method_list_add(ap_method_list_t *l, const char *method);
void ap_method_list_remove(ap_method_list_t *l,
                                       const char *method);
void ap_clear_method_list(ap_method_list_t *l);
void ap_set_content_type(request_rec *r, const char *ct);
void ap_set_content_type_ex(request_rec *r, const char *ct, int trusted);
void ap_set_accept_ranges(request_rec *r);
int ap_rputc(int c, request_rec *r);
int ap_rwrite(const void *buf, int nbyte, request_rec *r);
static __inline__ int ap_rputs(const char *str, request_rec *r)
{
    apr_size_t len;
    len = strlen(str);
    for (;;) {
        if (len <= 0x7fffffff) {
            return ap_rwrite(str, (int)len, r);
        }
        else {
            int rc;
            rc = ap_rwrite(str, 0x7fffffff, r);
            if (rc < 0) {
                return rc;
            }
            else {
                str += 0x7fffffff;
                len -= 0x7fffffff;
            }
        }
    }
}
int ap_rvputs(request_rec *r,...)
                       __attribute__((sentinel));
int ap_vrprintf(request_rec *r, const char *fmt, va_list vlist);
int ap_rprintf(request_rec *r, const char *fmt,...)
                                __attribute__((format(printf,2,3)));
int ap_rflush(request_rec *r);
int ap_index_of_response(int status);
const char * ap_get_status_line(int status);
const char * ap_get_status_line_ex(apr_pool_t *p, int status);
int ap_setup_client_block(request_rec *r, int read_policy);
int ap_should_client_block(request_rec *r);
long ap_get_client_block(request_rec *r, char *buffer, apr_size_t bufsiz);
int ap_map_http_request_error(apr_status_t rv, int status);
int ap_discard_request_body(request_rec *r);
void ap_note_auth_failure(request_rec *r);
void ap_note_basic_auth_failure(request_rec *r);
void ap_note_digest_auth_failure(request_rec *r);
typedef int ap_HOOK_note_auth_failure_t (request_rec *r, const char *auth_type); void ap_hook_note_auth_failure(ap_HOOK_note_auth_failure_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_note_auth_failure (request_rec *r, const char *auth_type); apr_array_header_t * ap_hook_get_note_auth_failure(void); typedef struct ap_LINK_note_auth_failure_t { ap_HOOK_note_auth_failure_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_note_auth_failure_t;
int ap_get_basic_auth_pw(request_rec *r, const char **pw);
apr_status_t ap_get_basic_auth_components(const request_rec *r,
                                                      const char **username,
                                                      const char **password);
void ap_parse_uri(request_rec *r, const char *uri);
int ap_getline(char *s, int n, request_rec *r, int flags);
apr_status_t ap_rgetline_core(char **s, apr_size_t n,
                                          apr_size_t *read,
                                          request_rec *r, int flags,
                                          apr_bucket_brigade *bb);
int ap_method_number_of(const char *method);
const char * ap_method_name_of(apr_pool_t *p, int methnum);
typedef void ap_HOOK_pre_read_request_t (request_rec *r, conn_rec *c); void ap_hook_pre_read_request(ap_HOOK_pre_read_request_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_pre_read_request (request_rec *r, conn_rec *c); apr_array_header_t * ap_hook_get_pre_read_request(void); typedef struct ap_LINK_pre_read_request_t { ap_HOOK_pre_read_request_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_pre_read_request_t;
typedef int ap_HOOK_post_read_request_t (request_rec *r); void ap_hook_post_read_request(ap_HOOK_post_read_request_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_post_read_request (request_rec *r); apr_array_header_t * ap_hook_get_post_read_request(void); typedef struct ap_LINK_post_read_request_t { ap_HOOK_post_read_request_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_post_read_request_t;
typedef int ap_HOOK_log_transaction_t (request_rec *r); void ap_hook_log_transaction(ap_HOOK_log_transaction_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_log_transaction (request_rec *r); apr_array_header_t * ap_hook_get_log_transaction(void); typedef struct ap_LINK_log_transaction_t { ap_HOOK_log_transaction_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_log_transaction_t;
typedef const char * ap_HOOK_http_scheme_t (const request_rec *r); void ap_hook_http_scheme(ap_HOOK_http_scheme_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); const char * ap_run_http_scheme (const request_rec *r); apr_array_header_t * ap_hook_get_http_scheme(void); typedef struct ap_LINK_http_scheme_t { ap_HOOK_http_scheme_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_http_scheme_t;
typedef apr_port_t ap_HOOK_default_port_t (const request_rec *r); void ap_hook_default_port(ap_HOOK_default_port_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_port_t ap_run_default_port (const request_rec *r); apr_array_header_t * ap_hook_get_default_port(void); typedef struct ap_LINK_default_port_t { ap_HOOK_default_port_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_default_port_t;
typedef int ap_HOOK_protocol_propose_t (conn_rec *c, request_rec *r, server_rec *s, const apr_array_header_t *offers, apr_array_header_t *proposals); void ap_hook_protocol_propose(ap_HOOK_protocol_propose_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_protocol_propose (conn_rec *c, request_rec *r, server_rec *s, const apr_array_header_t *offers, apr_array_header_t *proposals); apr_array_header_t * ap_hook_get_protocol_propose(void); typedef struct ap_LINK_protocol_propose_t { ap_HOOK_protocol_propose_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_protocol_propose_t;
typedef int ap_HOOK_protocol_switch_t (conn_rec *c, request_rec *r, server_rec *s, const char *protocol); void ap_hook_protocol_switch(ap_HOOK_protocol_switch_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_protocol_switch (conn_rec *c, request_rec *r, server_rec *s, const char *protocol); apr_array_header_t * ap_hook_get_protocol_switch(void); typedef struct ap_LINK_protocol_switch_t { ap_HOOK_protocol_switch_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_protocol_switch_t;
typedef const char * ap_HOOK_protocol_get_t (const conn_rec *c); void ap_hook_protocol_get(ap_HOOK_protocol_get_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); const char * ap_run_protocol_get (const conn_rec *c); apr_array_header_t * ap_hook_get_protocol_get(void); typedef struct ap_LINK_protocol_get_t { ap_HOOK_protocol_get_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_protocol_get_t;
apr_status_t ap_get_protocol_upgrades(conn_rec *c, request_rec *r,
                                                  server_rec *s, int report_all,
                                                  const apr_array_header_t **pupgrades);
const char * ap_select_protocol(conn_rec *c, request_rec *r,
                                            server_rec *s,
                                            const apr_array_header_t *choices);
apr_status_t ap_switch_protocol(conn_rec *c, request_rec *r,
                                            server_rec *s,
                                            const char *protocol);
const char * ap_get_protocol(conn_rec *c);
int ap_is_allowed_protocol(conn_rec *c, request_rec *r,
                                       server_rec *s, const char *protocol);
typedef struct ap_bucket_error ap_bucket_error;
struct ap_bucket_error {
    apr_bucket_refcount refcount;
    int status;
    const char *data;
};
 extern const apr_bucket_type_t ap_bucket_type_error;
apr_bucket * ap_bucket_error_make(apr_bucket *b, int error,
                const char *buf, apr_pool_t *p);
apr_bucket * ap_bucket_error_create(int error, const char *buf,
                                                apr_pool_t *p,
                                                apr_bucket_alloc_t *list);
apr_status_t ap_byterange_filter(ap_filter_t *f, apr_bucket_brigade *b);
apr_status_t ap_http_header_filter(ap_filter_t *f, apr_bucket_brigade *b);
apr_status_t ap_content_length_filter(ap_filter_t *,
                                                              apr_bucket_brigade *);
apr_status_t ap_old_write_filter(ap_filter_t *f, apr_bucket_brigade *b);
void ap_set_sub_req_protocol(request_rec *rnew, const request_rec *r);
void ap_finalize_sub_req_protocol(request_rec *sub_r);
void ap_send_interim_response(request_rec *r, int send_headers);
int ap_process_request_internal(request_rec *r);
request_rec * ap_sub_req_lookup_uri(const char *new_uri,
                                                const request_rec *r,
                                                ap_filter_t *next_filter);
request_rec * ap_sub_req_lookup_file(const char *new_file,
                                              const request_rec *r,
                                              ap_filter_t *next_filter);
request_rec * ap_sub_req_lookup_dirent(const apr_finfo_t *finfo,
                                                   const request_rec *r,
                                                   int subtype,
                                                   ap_filter_t *next_filter);
request_rec * ap_sub_req_method_uri(const char *method,
                                                const char *new_uri,
                                                const request_rec *r,
                                                ap_filter_t *next_filter);
apr_status_t ap_sub_req_output_filter(ap_filter_t *f,
                                                        apr_bucket_brigade *bb);
int ap_run_sub_req(request_rec *r);
void ap_destroy_sub_req(request_rec *r);
void ap_internal_redirect(const char *new_uri, request_rec *r);
void ap_internal_redirect_handler(const char *new_uri, request_rec *r);
void ap_internal_fast_redirect(request_rec *sub_req, request_rec *r);
int ap_some_auth_required(request_rec *r);
void ap_clear_auth_internal(void);
void ap_setup_auth_internal(apr_pool_t *ptemp);
apr_status_t ap_register_auth_provider(apr_pool_t *pool,
                                                   const char *provider_group,
                                                   const char *provider_name,
                                                   const char *provider_version,
                                                   const void *provider,
                                                   int type);
typedef apr_array_header_t * (apr_OFN_authn_ap_list_provider_names_t) (apr_pool_t *ptemp);
typedef apr_array_header_t * (apr_OFN_authz_ap_list_provider_names_t) (apr_pool_t *ptemp);
int ap_is_initial_req(request_rec *r);
void ap_update_mtime(request_rec *r, apr_time_t dependency_mtime);
void ap_allow_methods(request_rec *r, int reset, ...)
                 __attribute__((sentinel));
void ap_allow_standard_methods(request_rec *r, int reset, ...);
void ap_process_request(request_rec *r);
void ap_process_request_after_handler(request_rec *r);
void ap_process_async_request(request_rec *r);
void ap_die(int type, request_rec *r);
apr_status_t ap_check_pipeline(conn_rec *c, apr_bucket_brigade *bb,
                                           unsigned int max_blank_lines);
typedef int ap_HOOK_create_request_t (request_rec *r); void ap_hook_create_request(ap_HOOK_create_request_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_create_request (request_rec *r); apr_array_header_t * ap_hook_get_create_request(void); typedef struct ap_LINK_create_request_t { ap_HOOK_create_request_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_create_request_t;
typedef int ap_HOOK_pre_translate_name_t (request_rec *r); void ap_hook_pre_translate_name(ap_HOOK_pre_translate_name_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_pre_translate_name (request_rec *r); apr_array_header_t * ap_hook_get_pre_translate_name(void); typedef struct ap_LINK_pre_translate_name_t { ap_HOOK_pre_translate_name_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_pre_translate_name_t;
typedef int ap_HOOK_translate_name_t (request_rec *r); void ap_hook_translate_name(ap_HOOK_translate_name_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_translate_name (request_rec *r); apr_array_header_t * ap_hook_get_translate_name(void); typedef struct ap_LINK_translate_name_t { ap_HOOK_translate_name_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_translate_name_t;
typedef int ap_HOOK_map_to_storage_t (request_rec *r); void ap_hook_map_to_storage(ap_HOOK_map_to_storage_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_map_to_storage (request_rec *r); apr_array_header_t * ap_hook_get_map_to_storage(void); typedef struct ap_LINK_map_to_storage_t { ap_HOOK_map_to_storage_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_map_to_storage_t;
typedef int ap_HOOK_check_user_id_t (request_rec *r); void ap_hook_check_user_id(ap_HOOK_check_user_id_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_check_user_id (request_rec *r); apr_array_header_t * ap_hook_get_check_user_id(void); typedef struct ap_LINK_check_user_id_t { ap_HOOK_check_user_id_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_check_user_id_t;
typedef int ap_HOOK_fixups_t (request_rec *r); void ap_hook_fixups(ap_HOOK_fixups_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_fixups (request_rec *r); apr_array_header_t * ap_hook_get_fixups(void); typedef struct ap_LINK_fixups_t { ap_HOOK_fixups_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_fixups_t;
typedef int ap_HOOK_type_checker_t (request_rec *r); void ap_hook_type_checker(ap_HOOK_type_checker_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_type_checker (request_rec *r); apr_array_header_t * ap_hook_get_type_checker(void); typedef struct ap_LINK_type_checker_t { ap_HOOK_type_checker_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_type_checker_t;
typedef int ap_HOOK_access_checker_t (request_rec *r); void ap_hook_access_checker(ap_HOOK_access_checker_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_access_checker (request_rec *r); apr_array_header_t * ap_hook_get_access_checker(void); typedef struct ap_LINK_access_checker_t { ap_HOOK_access_checker_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_access_checker_t;
typedef int ap_HOOK_access_checker_ex_t (request_rec *r); void ap_hook_access_checker_ex(ap_HOOK_access_checker_ex_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_access_checker_ex (request_rec *r); apr_array_header_t * ap_hook_get_access_checker_ex(void); typedef struct ap_LINK_access_checker_ex_t { ap_HOOK_access_checker_ex_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_access_checker_ex_t;
typedef int ap_HOOK_auth_checker_t (request_rec *r); void ap_hook_auth_checker(ap_HOOK_auth_checker_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_auth_checker (request_rec *r); apr_array_header_t * ap_hook_get_auth_checker(void); typedef struct ap_LINK_auth_checker_t { ap_HOOK_auth_checker_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_auth_checker_t;
void ap_hook_check_access(ap_HOOK_access_checker_t *pf,
                                      const char * const *aszPre,
                                      const char * const *aszSucc,
                                      int nOrder, int type);
void ap_hook_check_access_ex(ap_HOOK_access_checker_ex_t *pf,
                                         const char * const *aszPre,
                                         const char * const *aszSucc,
                                         int nOrder, int type);
void ap_hook_check_authn(ap_HOOK_check_user_id_t *pf,
                                     const char * const *aszPre,
                                     const char * const *aszSucc,
                                     int nOrder, int type);
void ap_hook_check_authz(ap_HOOK_auth_checker_t *pf,
                                     const char * const *aszPre,
                                     const char * const *aszSucc,
                                     int nOrder, int type);
typedef void ap_HOOK_insert_filter_t (request_rec *r); void ap_hook_insert_filter(ap_HOOK_insert_filter_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_insert_filter (request_rec *r); apr_array_header_t * ap_hook_get_insert_filter(void); typedef struct ap_LINK_insert_filter_t { ap_HOOK_insert_filter_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_insert_filter_t;
typedef int ap_HOOK_post_perdir_config_t (request_rec *r); void ap_hook_post_perdir_config(ap_HOOK_post_perdir_config_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_post_perdir_config (request_rec *r); apr_array_header_t * ap_hook_get_post_perdir_config(void); typedef struct ap_LINK_post_perdir_config_t { ap_HOOK_post_perdir_config_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_post_perdir_config_t;
typedef int ap_HOOK_force_authn_t (request_rec *r); void ap_hook_force_authn(ap_HOOK_force_authn_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_force_authn (request_rec *r); apr_array_header_t * ap_hook_get_force_authn(void); typedef struct ap_LINK_force_authn_t { ap_HOOK_force_authn_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_force_authn_t;
typedef apr_status_t ap_HOOK_dirwalk_stat_t (apr_finfo_t *finfo, request_rec *r, apr_int32_t wanted); void ap_hook_dirwalk_stat(ap_HOOK_dirwalk_stat_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_status_t ap_run_dirwalk_stat (apr_finfo_t *finfo, request_rec *r, apr_int32_t wanted); apr_array_header_t * ap_hook_get_dirwalk_stat(void); typedef struct ap_LINK_dirwalk_stat_t { ap_HOOK_dirwalk_stat_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_dirwalk_stat_t;
int ap_location_walk(request_rec *r);
int ap_directory_walk(request_rec *r);
int ap_file_walk(request_rec *r);
int ap_if_walk(request_rec *r);
 extern const apr_bucket_type_t ap_bucket_type_eor;
apr_bucket * ap_bucket_eor_make(apr_bucket *b, request_rec *r);
apr_bucket * ap_bucket_eor_create(apr_bucket_alloc_t *list,
                                              request_rec *r);
int ap_some_authn_required(request_rec *r);
typedef struct ap_directive_t ap_directive_t;
struct ap_directive_t {
    const char *directive;
    const char *args;
    struct ap_directive_t *next;
    struct ap_directive_t *first_child;
    struct ap_directive_t *parent;
    void *data;
    const char *filename;
    int line_num;
    struct ap_directive_t *last;
};
 extern ap_directive_t *ap_conftree;
ap_directive_t *ap_add_node(ap_directive_t **parent, ap_directive_t *current,
                            ap_directive_t *toadd, int child);
enum cmd_how {
    RAW_ARGS,
    TAKE1,
    TAKE2,
    ITERATE,
    ITERATE2,
    FLAG,
    NO_ARGS,
    TAKE12,
    TAKE3,
    TAKE23,
    TAKE123,
    TAKE13,
    TAKE_ARGV
};
typedef struct cmd_parms_struct cmd_parms;
typedef union {
    const char *(*no_args) (cmd_parms *parms, void *mconfig);
    const char *(*raw_args) (cmd_parms *parms, void *mconfig,
                             const char *args);
    const char *(*take_argv) (cmd_parms *parms, void *mconfig,
                             int argc, char *const argv[]);
    const char *(*take1) (cmd_parms *parms, void *mconfig, const char *w);
    const char *(*take2) (cmd_parms *parms, void *mconfig, const char *w,
                          const char *w2);
    const char *(*take3) (cmd_parms *parms, void *mconfig, const char *w,
                          const char *w2, const char *w3);
    const char *(*flag) (cmd_parms *parms, void *mconfig, int on);
} cmd_func;
typedef struct command_struct command_rec;
struct command_struct {
    const char *name;
    cmd_func func;
    void *cmd_data;
    int req_override;
    enum cmd_how args_how;
    const char *errmsg;
};
typedef struct ap_configfile_t ap_configfile_t;
struct ap_configfile_t {
    apr_status_t (*getch) (char *ch, void *param);
    apr_status_t (*getstr) (void *buf, apr_size_t bufsiz, void *param);
    apr_status_t (*close) (void *param);
    void *param;
    const char *name;
    unsigned line_number;
};
struct cmd_parms_struct {
    void *info;
    int override;
    int override_opts;
    apr_table_t *override_list;
    apr_int64_t limited;
    apr_array_header_t *limited_xmethods;
    ap_method_list_t *xlimited;
    ap_configfile_t *config_file;
    ap_directive_t *directive;
    apr_pool_t *pool;
    apr_pool_t *temp_pool;
    server_rec *server;
    char *path;
    const command_rec *cmd;
    struct ap_conf_vector_t *context;
    const ap_directive_t *err_directive;
};
typedef struct module_struct module;
struct module_struct {
    int version;
    int minor_version;
    int module_index;
    const char *name;
    void *dynamic_load_handle;
    struct module_struct *next;
    unsigned long magic;
    void (*rewrite_args) (process_rec *process);
    void *(*create_dir_config) (apr_pool_t *p, char *dir);
    void *(*merge_dir_config) (apr_pool_t *p, void *base_conf, void *new_conf);
    void *(*create_server_config) (apr_pool_t *p, server_rec *s);
    void *(*merge_server_config) (apr_pool_t *p, void *base_conf,
                                  void *new_conf);
    const command_rec *cmds;
    void (*register_hooks) (apr_pool_t *p);
    int flags;
};
typedef struct ap_conf_vector_t ap_conf_vector_t;
void * ap_get_module_config(const ap_conf_vector_t *cv,
                                        const module *m);
void ap_set_module_config(ap_conf_vector_t *cv, const module *m,
                                      void *val);
int ap_get_module_flags(const module *m);
int ap_get_server_module_loglevel(const server_rec *s, int index);
int ap_get_conn_module_loglevel(const conn_rec *c, int index);
int ap_get_conn_server_module_loglevel(const conn_rec *c,
                                                   const server_rec *s,
                                                   int index);
int ap_get_request_module_loglevel(const request_rec *r, int index);
void ap_set_module_loglevel(apr_pool_t *p, struct ap_logconf *l,
                                        int index, int level);
void ap_reset_module_loglevels(struct ap_logconf *l, int val);
const char * ap_set_string_slot(cmd_parms *cmd,
                                                   void *struct_ptr,
                                                   const char *arg);
const char * ap_set_int_slot(cmd_parms *cmd,
                                                void *struct_ptr,
                                                const char *arg);
const char * ap_parse_log_level(const char *str, int *val);
int ap_method_is_limited(cmd_parms *cmd, const char *method);
const char * ap_set_string_slot_lower(cmd_parms *cmd,
                                                         void *struct_ptr,
                                                         const char *arg);
const char * ap_set_flag_slot(cmd_parms *cmd,
                                                 void *struct_ptr,
                                                 int arg);
const char * ap_set_flag_slot_char(cmd_parms *cmd,
                                                      void *struct_ptr,
                                                      int arg);
const char * ap_set_file_slot(cmd_parms *cmd,
                                                 void *struct_ptr,
                                                 const char *arg);
const char * ap_set_deprecated(cmd_parms *cmd,
                                                  void *struct_ptr,
                                                  const char *arg);
char * ap_server_root_relative(apr_pool_t *p, const char *fname);
char * ap_runtime_dir_relative(apr_pool_t *p, const char *fname);
const char * ap_add_module(module *m, apr_pool_t *p,
                                       const char *s);
void ap_remove_module(module *m);
const char * ap_add_loaded_module(module *mod, apr_pool_t *p,
                                              const char *s);
void ap_remove_loaded_module(module *mod);
const char * ap_find_module_name(module *m);
const char * ap_find_module_short_name(int module_index);
module * ap_find_linked_module(const char *name);
apr_status_t ap_pcfg_openfile(ap_configfile_t **ret_cfg,
                                          apr_pool_t *p, const char *name);
ap_configfile_t * ap_pcfg_open_custom(apr_pool_t *p,
    const char *descr,
    void *param,
    apr_status_t (*getc_func) (char *ch, void *param),
    apr_status_t (*gets_func) (void *buf, apr_size_t bufsiz, void *param),
    apr_status_t (*close_func) (void *param));
apr_status_t ap_cfg_getline(char *buf, apr_size_t bufsize, ap_configfile_t *cfp);
apr_status_t ap_cfg_getc(char *ch, ap_configfile_t *cfp);
int ap_cfg_closefile(ap_configfile_t *cfp);
const char * ap_pcfg_strerror(apr_pool_t *p, ap_configfile_t *cfp,
                                          apr_status_t rc);
const char * ap_soak_end_container(cmd_parms *cmd, char *directive);
const char * ap_build_cont_config(apr_pool_t *p,
                                              apr_pool_t *temp_pool,
                                              cmd_parms *parms,
                                              ap_directive_t **current,
                                              ap_directive_t **curr_parent,
                                              char *orig_directive);
const char * ap_build_config(cmd_parms *parms,
                                         apr_pool_t *conf_pool,
                                         apr_pool_t *temp_pool,
                                         ap_directive_t **conftree);
const char * ap_walk_config(ap_directive_t *conftree,
                                        cmd_parms *parms,
                                        ap_conf_vector_t *section_vector);
ap_dir_match_t *ap_dir_cfgmatch(cmd_parms *cmd, int flags,
        const char *(*cb)(ap_dir_match_t *w, const char *fname), void *ctx)
        __attribute__((nonnull(1,3)));
const char * ap_check_cmd_context(cmd_parms *cmd,
                                              unsigned forbidden);
typedef struct {
    const char *name;
    module *modp;
} ap_module_symbol_t;
 extern module *ap_top_module;
 extern module *ap_prelinked_modules[];
 extern ap_module_symbol_t ap_prelinked_module_symbols[];
 extern module *ap_preloaded_modules[];
 extern module **ap_loaded_modules;
void ap_single_module_configure(apr_pool_t *p, server_rec *s,
                                            module *m);
const char * ap_setup_prelinked_modules(process_rec *process);
void ap_show_directives(void);
int ap_exists_directive(apr_pool_t *p, const char *name);
void ap_show_modules(void);
const char * ap_show_mpm(void);
server_rec * ap_read_config(process_rec *process,
                                        apr_pool_t *temp_pool,
                                        const char *config_name,
                                        ap_directive_t **conftree);
void ap_run_rewrite_args(process_rec *process);
void ap_register_hooks(module *m, apr_pool_t *p);
void ap_fixup_virtual_hosts(apr_pool_t *p,
                                        server_rec *main_server);
void ap_reserve_module_slots(int count);
void ap_reserve_module_slots_directive(const char *directive);
ap_conf_vector_t* ap_create_request_config(apr_pool_t *p);
ap_conf_vector_t * ap_create_per_dir_config(apr_pool_t *p);
ap_conf_vector_t* ap_merge_per_dir_configs(apr_pool_t *p,
                                           ap_conf_vector_t *base,
                                           ap_conf_vector_t *new_conf);
struct ap_logconf * ap_new_log_config(apr_pool_t *p,
                                                  const struct ap_logconf *old);
void ap_merge_log_config(const struct ap_logconf *old_conf,
                                     struct ap_logconf *new_conf);
ap_conf_vector_t* ap_create_conn_config(apr_pool_t *p);
int ap_parse_htaccess(ap_conf_vector_t **result,
                                       request_rec *r,
                                       int override,
                                       int override_opts,
                                       apr_table_t *override_list,
                                       const char *path,
                                       const char *access_name);
const char * ap_init_virtual_host(apr_pool_t *p,
                                                   const char *hostname,
                                                   server_rec *main_server,
                                                   server_rec **ps);
const char * ap_process_resource_config(server_rec *s,
                                                    const char *fname,
                                                    ap_directive_t **conftree,
                                                    apr_pool_t *p,
                                                    apr_pool_t *ptemp);
const char * ap_process_fnmatch_configs(server_rec *s,
                                                    const char *fname,
                                                    ap_directive_t **conftree,
                                                    apr_pool_t *p,
                                                    apr_pool_t *ptemp,
                                                    int optional);
int ap_process_config_tree(server_rec *s,
                                       ap_directive_t *conftree,
                                       apr_pool_t *p,
                                       apr_pool_t *ptemp);
void * ap_retained_data_create(const char *key, apr_size_t size);
void * ap_retained_data_get(const char *key);
int ap_invoke_handler(request_rec *r);
const command_rec * ap_find_command(const char *name,
                                                     const command_rec *cmds);
const command_rec * ap_find_command_in_modules(const char *cmd_name,
                                                                module **mod);
void * ap_set_config_vectors(server_rec *server,
                                              ap_conf_vector_t *section_vector,
                                              const char *section,
                                              module *mod, apr_pool_t *pconf);
typedef int ap_HOOK_header_parser_t (request_rec *r); void ap_hook_header_parser(ap_HOOK_header_parser_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_header_parser (request_rec *r); apr_array_header_t * ap_hook_get_header_parser(void); typedef struct ap_LINK_header_parser_t { ap_HOOK_header_parser_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_header_parser_t;
typedef int ap_HOOK_pre_config_t (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp); void ap_hook_pre_config(ap_HOOK_pre_config_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_pre_config (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp); apr_array_header_t * ap_hook_get_pre_config(void); typedef struct ap_LINK_pre_config_t { ap_HOOK_pre_config_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_pre_config_t;
typedef int ap_HOOK_check_config_t (apr_pool_t *pconf, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s); void ap_hook_check_config(ap_HOOK_check_config_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_check_config (apr_pool_t *pconf, apr_pool_t *plog, apr_pool_t *ptemp, server_rec *s); apr_array_header_t * ap_hook_get_check_config(void); typedef struct ap_LINK_check_config_t { ap_HOOK_check_config_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_check_config_t;
typedef void ap_HOOK_test_config_t (apr_pool_t *pconf, server_rec *s); void ap_hook_test_config(ap_HOOK_test_config_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_test_config (apr_pool_t *pconf, server_rec *s); apr_array_header_t * ap_hook_get_test_config(void); typedef struct ap_LINK_test_config_t { ap_HOOK_test_config_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_test_config_t;
typedef int ap_HOOK_post_config_t (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp,server_rec *s); void ap_hook_post_config(ap_HOOK_post_config_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_post_config (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp,server_rec *s); apr_array_header_t * ap_hook_get_post_config(void); typedef struct ap_LINK_post_config_t { ap_HOOK_post_config_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_post_config_t;
typedef int ap_HOOK_open_logs_t (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp,server_rec *s); void ap_hook_open_logs(ap_HOOK_open_logs_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_open_logs (apr_pool_t *pconf,apr_pool_t *plog, apr_pool_t *ptemp,server_rec *s); apr_array_header_t * ap_hook_get_open_logs(void); typedef struct ap_LINK_open_logs_t { ap_HOOK_open_logs_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_open_logs_t;
typedef void ap_HOOK_child_init_t (apr_pool_t *pchild, server_rec *s); void ap_hook_child_init(ap_HOOK_child_init_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_child_init (apr_pool_t *pchild, server_rec *s); apr_array_header_t * ap_hook_get_child_init(void); typedef struct ap_LINK_child_init_t { ap_HOOK_child_init_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_child_init_t;
typedef int ap_HOOK_handler_t (request_rec *r); void ap_hook_handler(ap_HOOK_handler_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_handler (request_rec *r); apr_array_header_t * ap_hook_get_handler(void); typedef struct ap_LINK_handler_t { ap_HOOK_handler_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_handler_t;
typedef int ap_HOOK_quick_handler_t (request_rec *r, int lookup_uri); void ap_hook_quick_handler(ap_HOOK_quick_handler_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_quick_handler (request_rec *r, int lookup_uri); apr_array_header_t * ap_hook_get_quick_handler(void); typedef struct ap_LINK_quick_handler_t { ap_HOOK_quick_handler_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_quick_handler_t;
typedef void ap_HOOK_optional_fn_retrieve_t (void); void ap_hook_optional_fn_retrieve(ap_HOOK_optional_fn_retrieve_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_optional_fn_retrieve (void); apr_array_header_t * ap_hook_get_optional_fn_retrieve(void); typedef struct ap_LINK_optional_fn_retrieve_t { ap_HOOK_optional_fn_retrieve_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_optional_fn_retrieve_t;
typedef apr_status_t ap_HOOK_open_htaccess_t (request_rec *r, const char *dir_name, const char *access_name, ap_configfile_t **conffile, const char **full_name); void ap_hook_open_htaccess(ap_HOOK_open_htaccess_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_status_t ap_run_open_htaccess (request_rec *r, const char *dir_name, const char *access_name, ap_configfile_t **conffile, const char **full_name); apr_array_header_t * ap_hook_get_open_htaccess(void); typedef struct ap_LINK_open_htaccess_t { ap_HOOK_open_htaccess_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_open_htaccess_t;
apr_status_t ap_open_htaccess(request_rec *r, const char *dir_name,
        const char *access_name, ap_configfile_t **conffile,
        const char **full_name);
apr_status_t ap_pool_cleanup_set_null(void *data);

extern void closelog (void);
extern void openlog (const char *__ident, int __option, int __facility);
extern int setlogmask (int __mask) __attribute__ ((__nothrow__ , __leaf__));
extern void syslog (int __pri, const char *__fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));
extern void vsyslog (int __pri, const char *__fmt, __gnuc_va_list __ap)
     __attribute__ ((__format__ (__printf__, 2, 0)));

static int * const aplog_module_index;
 extern int ap_default_loglevel;
void ap_open_stderr_log(apr_pool_t *p);
apr_status_t ap_replace_stderr_log(apr_pool_t *p,
                                               const char *file);
int ap_open_logs(apr_pool_t *pconf, apr_pool_t *plog,
                 apr_pool_t *ptemp, server_rec *s_main);
void ap_logs_child_init(apr_pool_t *p, server_rec *s);
void ap_log_error_(const char *file, int line, int module_index,
                               int level, apr_status_t status,
                               const server_rec *s, const char *fmt, ...)
                              __attribute__((format(printf,7,8)));
void ap_log_perror_(const char *file, int line, int module_index,
                                int level, apr_status_t status, apr_pool_t *p,
                                const char *fmt, ...)
                               __attribute__((format(printf,7,8)));
void ap_log_rerror_(const char *file, int line, int module_index,
                                int level, apr_status_t status,
                                const request_rec *r, const char *fmt, ...)
                                __attribute__((format(printf,7,8)));
void ap_log_cerror_(const char *file, int line, int module_index,
                                int level, apr_status_t status,
                                const conn_rec *c, const char *fmt, ...)
                                __attribute__((format(printf,7,8)));
void ap_log_cserror_(const char *file, int line, int module_index,
                                 int level, apr_status_t status,
                                 const conn_rec *c, const server_rec *s,
                                 const char *fmt, ...)
                             __attribute__((format(printf,8,9)));
void ap_log_data_(const char *file, int line, int module_index,
                              int level, const server_rec *s, const char *label,
                              const void *data, apr_size_t len, unsigned int flags);
void ap_log_rdata_(const char *file, int line, int module_index,
                               int level, const request_rec *r, const char *label,
                               const void *data, apr_size_t len, unsigned int flags);
void ap_log_cdata_(const char *file, int line, int module_index,
                               int level, const conn_rec *c, const char *label,
                               const void *data, apr_size_t len, unsigned int flags);
void ap_log_csdata_(const char *file, int line, int module_index,
                                int level, const conn_rec *c, const server_rec *s,
                                const char *label, const void *data,
                                apr_size_t len, unsigned int flags);
void ap_error_log2stderr(server_rec *s);
void ap_log_command_line(apr_pool_t *p, server_rec *s);
void ap_log_mpm_common(server_rec *s);
void ap_log_pid(apr_pool_t *p, const char *fname);
void ap_remove_pid(apr_pool_t *p, const char *fname);
apr_status_t ap_read_pid(apr_pool_t *p, const char *filename, pid_t *mypid);
typedef struct piped_log piped_log;
piped_log * ap_open_piped_log(apr_pool_t *p, const char *program);
piped_log * ap_open_piped_log_ex(apr_pool_t *p,
                                             const char *program,
                                             apr_cmdtype_e cmdtype);
void ap_close_piped_log(piped_log *pl);
apr_file_t * ap_piped_log_read_fd(piped_log *pl);
apr_file_t * ap_piped_log_write_fd(piped_log *pl);
typedef int ap_HOOK_generate_log_id_t (const conn_rec *c, const request_rec *r, const char **id); void ap_hook_generate_log_id(ap_HOOK_generate_log_id_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_generate_log_id (const conn_rec *c, const request_rec *r, const char **id); apr_array_header_t * ap_hook_get_generate_log_id(void); typedef struct ap_LINK_generate_log_id_t { ap_HOOK_generate_log_id_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_generate_log_id_t;

struct tms
  {
    clock_t tms_utime;
    clock_t tms_stime;
    clock_t tms_cutime;
    clock_t tms_cstime;
  };
extern clock_t times (struct tms *__buffer) __attribute__ ((__nothrow__ , __leaf__));

typedef int ap_generation_t;
typedef enum {
    SB_NOT_SHARED = 1,
    SB_SHARED = 2
} ap_scoreboard_e;
typedef struct worker_score worker_score;
struct worker_score {
    apr_os_thread_t tid;
    int thread_num;
    pid_t pid;
    ap_generation_t generation;
    unsigned char status;
    unsigned short conn_count;
    apr_off_t conn_bytes;
    unsigned long access_count;
    apr_off_t bytes_served;
    unsigned long my_access_count;
    apr_off_t my_bytes_served;
    apr_time_t start_time;
    apr_time_t stop_time;
    apr_time_t last_used;
    struct tms times;
    char client[32];
    char request[64];
    char vhost[32];
    char protocol[16];
    apr_time_t duration;
    char client64[64];
};
typedef struct {
    int server_limit;
    int thread_limit;
    ap_generation_t running_generation;
    apr_time_t restart_time;
    struct tms times;
} global_score;
typedef struct process_score process_score;
struct process_score {
    pid_t pid;
    ap_generation_t generation;
    char quiescing;
    char not_accepting;
    apr_uint32_t connections;
    apr_uint32_t write_completion;
    apr_uint32_t lingering_close;
    apr_uint32_t keep_alive;
    apr_uint32_t suspended;
    int bucket;
    apr_uint32_t wait_io;
};
typedef struct {
    global_score *global;
    process_score *parent;
    worker_score **servers;
} scoreboard;
typedef struct ap_sb_handle_t ap_sb_handle_t;
int ap_create_scoreboard(apr_pool_t *p, ap_scoreboard_e t);
apr_status_t ap_cleanup_scoreboard(void *d);
int ap_exists_scoreboard_image(void);
void ap_increment_counts(ap_sb_handle_t *sbh, request_rec *r);
void ap_set_conn_count(ap_sb_handle_t *sb, request_rec *r, unsigned short conn_count);
apr_status_t ap_reopen_scoreboard(apr_pool_t *p, apr_shm_t **shm, int detached);
void ap_init_scoreboard(void *shared_score);
int ap_calc_scoreboard_size(void);
void ap_create_sb_handle(ap_sb_handle_t **new_sbh, apr_pool_t *p,
                                     int child_num, int thread_num);
void ap_update_sb_handle(ap_sb_handle_t *sbh,
                                     int child_num, int thread_num);
int ap_find_child_by_pid(apr_proc_t *pid);
int ap_update_child_status(ap_sb_handle_t *sbh, int status, request_rec *r);
int ap_update_child_status_from_indexes(int child_num, int thread_num,
                                                    int status, request_rec *r);
int ap_update_child_status_from_conn(ap_sb_handle_t *sbh, int status, conn_rec *c);
int ap_update_child_status_from_server(ap_sb_handle_t *sbh, int status,
                                                   conn_rec *c, server_rec *s);
int ap_update_child_status_descr(ap_sb_handle_t *sbh, int status, const char *descr);
void ap_time_process_request(ap_sb_handle_t *sbh, int status);
void ap_set_time_process_request(ap_sb_handle_t* const sbh,
  const apr_time_t timebeg,const apr_time_t timeend);
int ap_update_global_status(void);
worker_score * ap_get_scoreboard_worker(ap_sb_handle_t *sbh);
worker_score * ap_get_scoreboard_worker_from_indexes(int child_num,
                                                                int thread_num);
void ap_copy_scoreboard_worker(worker_score *dest,
                                           int child_num, int thread_num);
process_score * ap_get_scoreboard_process(int x);
global_score * ap_get_scoreboard_global(void);
 extern scoreboard *ap_scoreboard_image;
 extern const char *ap_scoreboard_fname;
 extern int ap_extended_status;
 extern int ap_mod_status_reqtail;
const char *ap_set_scoreboard(cmd_parms *cmd, void *dummy, const char *arg);
const char *ap_set_extended_status(cmd_parms *cmd, void *dummy, int arg);
const char *ap_set_reqtail(cmd_parms *cmd, void *dummy, int arg);
typedef int ap_HOOK_pre_mpm_t (apr_pool_t *p, ap_scoreboard_e sb_type); void ap_hook_pre_mpm(ap_HOOK_pre_mpm_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_pre_mpm (apr_pool_t *p, ap_scoreboard_e sb_type); apr_array_header_t * ap_hook_get_pre_mpm(void); typedef struct ap_LINK_pre_mpm_t { ap_HOOK_pre_mpm_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_pre_mpm_t;
typedef int ap_HOOK_mpm_t (apr_pool_t *pconf, apr_pool_t *plog, server_rec *server_conf); void ap_hook_mpm(ap_HOOK_mpm_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_mpm (apr_pool_t *pconf, apr_pool_t *plog, server_rec *server_conf); apr_array_header_t * ap_hook_get_mpm(void); typedef struct ap_LINK_mpm_t { ap_HOOK_mpm_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_mpm_t;
apr_status_t ap_os_create_privileged_process(
    const request_rec *r,
    apr_proc_t *newproc,
    const char *progname,
    const char * const *args,
    const char * const *env,
    apr_procattr_t *attr,
    apr_pool_t *p);
apr_status_t ap_mpm_query(int query_code, int *result);
typedef void (ap_mpm_callback_fn_t)(void *baton);
apr_status_t ap_mpm_register_timed_callback(apr_time_t t,
                                                       ap_mpm_callback_fn_t *cbfn,
                                                       void *baton);
typedef enum mpm_child_status {
    MPM_CHILD_STARTED,
    MPM_CHILD_EXITED,
    MPM_CHILD_LOST_SLOT
} mpm_child_status;
typedef void ap_HOOK_child_status_t (server_rec *s, pid_t pid, ap_generation_t gen, int slot, mpm_child_status state); void ap_hook_child_status(ap_HOOK_child_status_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_child_status (server_rec *s, pid_t pid, ap_generation_t gen, int slot, mpm_child_status state); apr_array_header_t * ap_hook_get_child_status(void); typedef struct ap_LINK_child_status_t { ap_HOOK_child_status_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_child_status_t;
typedef void ap_HOOK_end_generation_t (server_rec *s, ap_generation_t gen); void ap_hook_end_generation(ap_HOOK_end_generation_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_end_generation (server_rec *s, ap_generation_t gen); apr_array_header_t * ap_hook_get_end_generation(void); typedef struct ap_LINK_end_generation_t { ap_HOOK_end_generation_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_end_generation_t;
typedef uint32_t tcp_seq;
struct tcphdr
  {
    __extension__ union
    {
      struct
      {
 uint16_t th_sport;
 uint16_t th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;
 uint8_t th_x2:4;
 uint8_t th_off:4;
 uint8_t th_flags;
 uint16_t th_win;
 uint16_t th_sum;
 uint16_t th_urp;
      };
      struct
      {
 uint16_t source;
 uint16_t dest;
 uint32_t seq;
 uint32_t ack_seq;
 uint16_t res1:4;
 uint16_t doff:4;
 uint16_t fin:1;
 uint16_t syn:1;
 uint16_t rst:1;
 uint16_t psh:1;
 uint16_t ack:1;
 uint16_t urg:1;
 uint16_t res2:2;
 uint16_t window;
 uint16_t check;
 uint16_t urg_ptr;
      };
    };
};
enum
{
  TCP_ESTABLISHED = 1,
  TCP_SYN_SENT,
  TCP_SYN_RECV,
  TCP_FIN_WAIT1,
  TCP_FIN_WAIT2,
  TCP_TIME_WAIT,
  TCP_CLOSE,
  TCP_CLOSE_WAIT,
  TCP_LAST_ACK,
  TCP_LISTEN,
  TCP_CLOSING
};
enum tcp_ca_state
{
  TCP_CA_Open = 0,
  TCP_CA_Disorder = 1,
  TCP_CA_CWR = 2,
  TCP_CA_Recovery = 3,
  TCP_CA_Loss = 4
};
struct tcp_info
{
  uint8_t tcpi_state;
  uint8_t tcpi_ca_state;
  uint8_t tcpi_retransmits;
  uint8_t tcpi_probes;
  uint8_t tcpi_backoff;
  uint8_t tcpi_options;
  uint8_t tcpi_snd_wscale : 4, tcpi_rcv_wscale : 4;
  uint32_t tcpi_rto;
  uint32_t tcpi_ato;
  uint32_t tcpi_snd_mss;
  uint32_t tcpi_rcv_mss;
  uint32_t tcpi_unacked;
  uint32_t tcpi_sacked;
  uint32_t tcpi_lost;
  uint32_t tcpi_retrans;
  uint32_t tcpi_fackets;
  uint32_t tcpi_last_data_sent;
  uint32_t tcpi_last_ack_sent;
  uint32_t tcpi_last_data_recv;
  uint32_t tcpi_last_ack_recv;
  uint32_t tcpi_pmtu;
  uint32_t tcpi_rcv_ssthresh;
  uint32_t tcpi_rtt;
  uint32_t tcpi_rttvar;
  uint32_t tcpi_snd_ssthresh;
  uint32_t tcpi_snd_cwnd;
  uint32_t tcpi_advmss;
  uint32_t tcpi_reordering;
  uint32_t tcpi_rcv_rtt;
  uint32_t tcpi_rcv_space;
  uint32_t tcpi_total_retrans;
};
struct tcp_md5sig
{
  struct sockaddr_storage tcpm_addr;
  uint8_t tcpm_flags;
  uint8_t tcpm_prefixlen;
  uint16_t tcpm_keylen;
  int tcpm_ifindex;
  uint8_t tcpm_key[80];
};
struct tcp_repair_opt
{
  uint32_t opt_code;
  uint32_t opt_val;
};
enum
{
  TCP_NO_QUEUE,
  TCP_RECV_QUEUE,
  TCP_SEND_QUEUE,
  TCP_QUEUES_NR,
};
struct tcp_cookie_transactions
{
  uint16_t tcpct_flags;
  uint8_t __tcpct_pad1;
  uint8_t tcpct_cookie_desired;
  uint16_t tcpct_s_data_desired;
  uint16_t tcpct_used;
  uint8_t tcpct_value[536U];
};
struct tcp_repair_window
{
  uint32_t snd_wl1;
  uint32_t snd_wnd;
  uint32_t max_window;
  uint32_t rcv_wnd;
  uint32_t rcv_wup;
};
struct tcp_zerocopy_receive
{
  uint64_t address;
  uint32_t length;
  uint32_t recv_skip_hint;
};
typedef void ap_reclaim_callback_fn_t(int childnum, pid_t pid,
                                      ap_generation_t gen);
void ap_reclaim_child_processes(int terminate,
                                            ap_reclaim_callback_fn_t *mpm_callback);
void ap_relieve_child_processes(ap_reclaim_callback_fn_t *mpm_callback);
void ap_register_extra_mpm_process(pid_t pid, ap_generation_t gen);
int ap_unregister_extra_mpm_process(pid_t pid, ap_generation_t *old_gen);
apr_status_t ap_mpm_safe_kill(pid_t pid, int sig);
int ap_process_child_status(apr_proc_t *pid, apr_exit_why_e why, int status);
apr_status_t ap_fatal_signal_setup(server_rec *s, apr_pool_t *in_pconf);
apr_status_t ap_fatal_signal_child_setup(server_rec *s);
apr_status_t ap_mpm_end_gen_helper(void *unused);
void ap_wait_or_timeout(apr_exit_why_e *status, int *exitcode,
                                    apr_proc_t *ret, apr_pool_t *p,
                                    server_rec *s);
void ap_sock_disable_nagle(apr_socket_t *s);
uid_t ap_uname2id(const char *name);
gid_t ap_gname2id(const char *name);
typedef struct ap_pod_t ap_pod_t;
struct ap_pod_t {
    apr_file_t *pod_in;
    apr_file_t *pod_out;
    apr_pool_t *p;
};
apr_status_t ap_mpm_pod_open(apr_pool_t *p, ap_pod_t **pod);
apr_status_t ap_mpm_pod_check(ap_pod_t *pod);
apr_status_t ap_mpm_pod_close(ap_pod_t *pod);
apr_status_t ap_mpm_pod_signal(ap_pod_t *pod);
void ap_mpm_pod_killpg(ap_pod_t *pod, int num);
typedef enum { AP_MPM_PODX_NORESTART, AP_MPM_PODX_RESTART, AP_MPM_PODX_GRACEFUL } ap_podx_restart_t;
apr_status_t ap_mpm_podx_open(apr_pool_t *p, ap_pod_t **pod);
int ap_mpm_podx_check(ap_pod_t *pod);
apr_status_t ap_mpm_podx_close(ap_pod_t *pod);
apr_status_t ap_mpm_podx_signal(ap_pod_t *pod,
                                            ap_podx_restart_t graceful);
void ap_mpm_podx_killpg(ap_pod_t *pod, int num,
                                    ap_podx_restart_t graceful);
const char * ap_check_mpm(void);
 extern int ap_max_requests_per_child;
const char *ap_mpm_set_max_requests(cmd_parms *cmd, void *dummy,
                                    const char *arg);
 extern const char *ap_pid_fname;
const char *ap_mpm_set_pidfile(cmd_parms *cmd, void *dummy,
                               const char *arg);
void ap_mpm_dump_pidfile(apr_pool_t *p, apr_file_t *out);
 extern char ap_coredump_dir[8192];
 extern int ap_coredumpdir_configured;
const char *ap_mpm_set_coredumpdir(cmd_parms *cmd, void *dummy,
                                   const char *arg);
 extern int ap_graceful_shutdown_timeout;
const char *ap_mpm_set_graceful_shutdown(cmd_parms *cmd, void *dummy,
                                         const char *arg);
int ap_signal_server(int *, apr_pool_t *);
void ap_mpm_rewrite_args(process_rec *);
 extern apr_uint32_t ap_max_mem_free;
extern const char *ap_mpm_set_max_mem_free(cmd_parms *cmd, void *dummy,
                                           const char *arg);
 extern apr_size_t ap_thread_stacksize;
extern const char *ap_mpm_set_thread_stacksize(cmd_parms *cmd, void *dummy,
                                               const char *arg);
extern void ap_core_child_status(server_rec *s, pid_t pid, ap_generation_t gen,
                                 int slot, mpm_child_status status);
typedef int ap_HOOK_monitor_t (apr_pool_t *p, server_rec *s); void ap_hook_monitor(ap_HOOK_monitor_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_monitor (apr_pool_t *p, server_rec *s); apr_array_header_t * ap_hook_get_monitor(void); typedef struct ap_LINK_monitor_t { ap_HOOK_monitor_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_monitor_t;
int ap_sys_privileges_handlers(int inc);
typedef int ap_HOOK_drop_privileges_t (apr_pool_t * pchild, server_rec * s); void ap_hook_drop_privileges(ap_HOOK_drop_privileges_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_drop_privileges (apr_pool_t * pchild, server_rec * s); apr_array_header_t * ap_hook_get_drop_privileges(void); typedef struct ap_LINK_drop_privileges_t { ap_HOOK_drop_privileges_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_drop_privileges_t;
typedef int ap_HOOK_mpm_query_t (int query_code, int *result, apr_status_t *rv); void ap_hook_mpm_query(ap_HOOK_mpm_query_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_mpm_query (int query_code, int *result, apr_status_t *rv); apr_array_header_t * ap_hook_get_mpm_query(void); typedef struct ap_LINK_mpm_query_t { ap_HOOK_mpm_query_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_mpm_query_t;
typedef apr_status_t ap_HOOK_mpm_register_timed_callback_t (apr_time_t t, ap_mpm_callback_fn_t *cbfn, void *baton); void ap_hook_mpm_register_timed_callback(ap_HOOK_mpm_register_timed_callback_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_status_t ap_run_mpm_register_timed_callback (apr_time_t t, ap_mpm_callback_fn_t *cbfn, void *baton); apr_array_header_t * ap_hook_get_mpm_register_timed_callback(void); typedef struct ap_LINK_mpm_register_timed_callback_t { ap_HOOK_mpm_register_timed_callback_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_mpm_register_timed_callback_t;
typedef const char * ap_HOOK_mpm_get_name_t (void); void ap_hook_mpm_get_name(ap_HOOK_mpm_get_name_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); const char * ap_run_mpm_get_name (void); apr_array_header_t * ap_hook_get_mpm_get_name(void); typedef struct ap_LINK_mpm_get_name_t { ap_HOOK_mpm_get_name_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_mpm_get_name_t;
typedef void ap_HOOK_suspend_connection_t (conn_rec *c, request_rec *r); void ap_hook_suspend_connection(ap_HOOK_suspend_connection_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_suspend_connection (conn_rec *c, request_rec *r); apr_array_header_t * ap_hook_get_suspend_connection(void); typedef struct ap_LINK_suspend_connection_t { ap_HOOK_suspend_connection_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_suspend_connection_t;
typedef void ap_HOOK_resume_connection_t (conn_rec *c, request_rec *r); void ap_hook_resume_connection(ap_HOOK_resume_connection_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_resume_connection (conn_rec *c, request_rec *r); apr_array_header_t * ap_hook_get_resume_connection(void); typedef struct ap_LINK_resume_connection_t { ap_HOOK_resume_connection_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_resume_connection_t;
typedef void ap_HOOK_child_stopping_t (apr_pool_t *pchild, int graceful); void ap_hook_child_stopping(ap_HOOK_child_stopping_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_child_stopping (apr_pool_t *pchild, int graceful); apr_array_header_t * ap_hook_get_child_stopping(void); typedef struct ap_LINK_child_stopping_t { ap_HOOK_child_stopping_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_child_stopping_t;
void mpm_common_pre_config(apr_pool_t *pconf);
typedef char * (apr_OFN_http2_var_lookup_t) (apr_pool_t *, server_rec *, conn_rec *, request_rec *, char *);
typedef int (apr_OFN_http2_is_h2_t) (conn_rec *);
typedef void (apr_OFN_http2_get_num_workers_t) (server_rec *s, int *minw, int *max);
typedef apr_status_t (apr_OFN_http2_get_pollfd_from_conn_t) (conn_rec *c, struct apr_pollfd_t *pfd, apr_interval_time_t *ptimeout);
struct apr_thread_cond_t;
typedef struct h2_req_engine h2_req_engine;
typedef void http2_output_consumed(void *ctx, conn_rec *c, apr_off_t consumed);
typedef apr_status_t http2_req_engine_init(h2_req_engine *engine,
                                           const char *id,
                                           const char *type,
                                           apr_pool_t *pool,
                                           apr_size_t req_buffer_size,
                                           request_rec *r,
                                           http2_output_consumed **pconsumed,
                                           void **pbaton);
typedef apr_status_t (apr_OFN_http2_req_engine_push_t) (const char *engine_type, request_rec *r, http2_req_engine_init *einit);
typedef apr_status_t (apr_OFN_http2_req_engine_pull_t) (h2_req_engine *engine, apr_read_type_e block, int capacity, request_rec **pr);
typedef void (apr_OFN_http2_req_engine_done_t) (h2_req_engine *engine, conn_rec *rconn, apr_status_t status);
struct nghttp2_session;
typedef struct nghttp2_session nghttp2_session;
typedef struct {
  int age;
  int version_num;
  const char *version_str;
  const char *proto_str;
} nghttp2_info;
typedef enum {
  NGHTTP2_ERR_INVALID_ARGUMENT = -501,
  NGHTTP2_ERR_BUFFER_ERROR = -502,
  NGHTTP2_ERR_UNSUPPORTED_VERSION = -503,
  NGHTTP2_ERR_WOULDBLOCK = -504,
  NGHTTP2_ERR_PROTO = -505,
  NGHTTP2_ERR_INVALID_FRAME = -506,
  NGHTTP2_ERR_EOF = -507,
  NGHTTP2_ERR_DEFERRED = -508,
  NGHTTP2_ERR_STREAM_ID_NOT_AVAILABLE = -509,
  NGHTTP2_ERR_STREAM_CLOSED = -510,
  NGHTTP2_ERR_STREAM_CLOSING = -511,
  NGHTTP2_ERR_STREAM_SHUT_WR = -512,
  NGHTTP2_ERR_INVALID_STREAM_ID = -513,
  NGHTTP2_ERR_INVALID_STREAM_STATE = -514,
  NGHTTP2_ERR_DEFERRED_DATA_EXIST = -515,
  NGHTTP2_ERR_START_STREAM_NOT_ALLOWED = -516,
  NGHTTP2_ERR_GOAWAY_ALREADY_SENT = -517,
  NGHTTP2_ERR_INVALID_HEADER_BLOCK = -518,
  NGHTTP2_ERR_INVALID_STATE = -519,
  NGHTTP2_ERR_TEMPORAL_CALLBACK_FAILURE = -521,
  NGHTTP2_ERR_FRAME_SIZE_ERROR = -522,
  NGHTTP2_ERR_HEADER_COMP = -523,
  NGHTTP2_ERR_FLOW_CONTROL = -524,
  NGHTTP2_ERR_INSUFF_BUFSIZE = -525,
  NGHTTP2_ERR_PAUSE = -526,
  NGHTTP2_ERR_TOO_MANY_INFLIGHT_SETTINGS = -527,
  NGHTTP2_ERR_PUSH_DISABLED = -528,
  NGHTTP2_ERR_DATA_EXIST = -529,
  NGHTTP2_ERR_SESSION_CLOSING = -530,
  NGHTTP2_ERR_HTTP_HEADER = -531,
  NGHTTP2_ERR_HTTP_MESSAGING = -532,
  NGHTTP2_ERR_REFUSED_STREAM = -533,
  NGHTTP2_ERR_INTERNAL = -534,
  NGHTTP2_ERR_CANCEL = -535,
  NGHTTP2_ERR_SETTINGS_EXPECTED = -536,
  NGHTTP2_ERR_TOO_MANY_SETTINGS = -537,
  NGHTTP2_ERR_FATAL = -900,
  NGHTTP2_ERR_NOMEM = -901,
  NGHTTP2_ERR_CALLBACK_FAILURE = -902,
  NGHTTP2_ERR_BAD_CLIENT_MAGIC = -903,
  NGHTTP2_ERR_FLOODED = -904,
  NGHTTP2_ERR_TOO_MANY_CONTINUATIONS = -905,
} nghttp2_error;
typedef struct {
  uint8_t *base;
  size_t len;
} nghttp2_vec;
struct nghttp2_rcbuf;
typedef struct nghttp2_rcbuf nghttp2_rcbuf;
 void nghttp2_rcbuf_incref(nghttp2_rcbuf *rcbuf);
 void nghttp2_rcbuf_decref(nghttp2_rcbuf *rcbuf);
 nghttp2_vec nghttp2_rcbuf_get_buf(nghttp2_rcbuf *rcbuf);
 int nghttp2_rcbuf_is_static(const nghttp2_rcbuf *rcbuf);
typedef enum {
  NGHTTP2_NV_FLAG_NONE = 0,
  NGHTTP2_NV_FLAG_NO_INDEX = 0x01,
  NGHTTP2_NV_FLAG_NO_COPY_NAME = 0x02,
  NGHTTP2_NV_FLAG_NO_COPY_VALUE = 0x04
} nghttp2_nv_flag;
typedef struct {
  uint8_t *name;
  uint8_t *value;
  size_t namelen;
  size_t valuelen;
  uint8_t flags;
} nghttp2_nv;
typedef enum {
  NGHTTP2_DATA = 0,
  NGHTTP2_HEADERS = 0x01,
  NGHTTP2_PRIORITY = 0x02,
  NGHTTP2_RST_STREAM = 0x03,
  NGHTTP2_SETTINGS = 0x04,
  NGHTTP2_PUSH_PROMISE = 0x05,
  NGHTTP2_PING = 0x06,
  NGHTTP2_GOAWAY = 0x07,
  NGHTTP2_WINDOW_UPDATE = 0x08,
  NGHTTP2_CONTINUATION = 0x09,
  NGHTTP2_ALTSVC = 0x0a,
  NGHTTP2_ORIGIN = 0x0c,
  NGHTTP2_PRIORITY_UPDATE = 0x10
} nghttp2_frame_type;
typedef enum {
  NGHTTP2_FLAG_NONE = 0,
  NGHTTP2_FLAG_END_STREAM = 0x01,
  NGHTTP2_FLAG_END_HEADERS = 0x04,
  NGHTTP2_FLAG_ACK = 0x01,
  NGHTTP2_FLAG_PADDED = 0x08,
  NGHTTP2_FLAG_PRIORITY = 0x20
} nghttp2_flag;
typedef enum {
  NGHTTP2_SETTINGS_HEADER_TABLE_SIZE = 0x01,
  NGHTTP2_SETTINGS_ENABLE_PUSH = 0x02,
  NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS = 0x03,
  NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE = 0x04,
  NGHTTP2_SETTINGS_MAX_FRAME_SIZE = 0x05,
  NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE = 0x06,
  NGHTTP2_SETTINGS_ENABLE_CONNECT_PROTOCOL = 0x08,
  NGHTTP2_SETTINGS_NO_RFC7540_PRIORITIES = 0x09
} nghttp2_settings_id;
typedef enum {
  NGHTTP2_NO_ERROR = 0x00,
  NGHTTP2_PROTOCOL_ERROR = 0x01,
  NGHTTP2_INTERNAL_ERROR = 0x02,
  NGHTTP2_FLOW_CONTROL_ERROR = 0x03,
  NGHTTP2_SETTINGS_TIMEOUT = 0x04,
  NGHTTP2_STREAM_CLOSED = 0x05,
  NGHTTP2_FRAME_SIZE_ERROR = 0x06,
  NGHTTP2_REFUSED_STREAM = 0x07,
  NGHTTP2_CANCEL = 0x08,
  NGHTTP2_COMPRESSION_ERROR = 0x09,
  NGHTTP2_CONNECT_ERROR = 0x0a,
  NGHTTP2_ENHANCE_YOUR_CALM = 0x0b,
  NGHTTP2_INADEQUATE_SECURITY = 0x0c,
  NGHTTP2_HTTP_1_1_REQUIRED = 0x0d
} nghttp2_error_code;
typedef struct {
  size_t length;
  int32_t stream_id;
  uint8_t type;
  uint8_t flags;
  uint8_t reserved;
} nghttp2_frame_hd;
typedef union {
  int fd;
  void *ptr;
} nghttp2_data_source;
typedef enum {
  NGHTTP2_DATA_FLAG_NONE = 0,
  NGHTTP2_DATA_FLAG_EOF = 0x01,
  NGHTTP2_DATA_FLAG_NO_END_STREAM = 0x02,
  NGHTTP2_DATA_FLAG_NO_COPY = 0x04
} nghttp2_data_flag;
typedef ssize_t (*nghttp2_data_source_read_callback)(
    nghttp2_session *session, int32_t stream_id, uint8_t *buf, size_t length,
    uint32_t *data_flags, nghttp2_data_source *source, void *user_data);
typedef struct {
  nghttp2_data_source source;
  nghttp2_data_source_read_callback read_callback;
} nghttp2_data_provider;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
} nghttp2_data;
typedef enum {
  NGHTTP2_HCAT_REQUEST = 0,
  NGHTTP2_HCAT_RESPONSE = 1,
  NGHTTP2_HCAT_PUSH_RESPONSE = 2,
  NGHTTP2_HCAT_HEADERS = 3
} nghttp2_headers_category;
typedef struct {
  int32_t stream_id;
  int32_t weight;
  uint8_t exclusive;
} nghttp2_priority_spec;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
  nghttp2_priority_spec pri_spec;
  nghttp2_nv *nva;
  size_t nvlen;
  nghttp2_headers_category cat;
} nghttp2_headers;
typedef struct {
  nghttp2_frame_hd hd;
  nghttp2_priority_spec pri_spec;
} nghttp2_priority;
typedef struct {
  nghttp2_frame_hd hd;
  uint32_t error_code;
} nghttp2_rst_stream;
typedef struct {
  int32_t settings_id;
  uint32_t value;
} nghttp2_settings_entry;
typedef struct {
  nghttp2_frame_hd hd;
  size_t niv;
  nghttp2_settings_entry *iv;
} nghttp2_settings;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
  nghttp2_nv *nva;
  size_t nvlen;
  int32_t promised_stream_id;
  uint8_t reserved;
} nghttp2_push_promise;
typedef struct {
  nghttp2_frame_hd hd;
  uint8_t opaque_data[8];
} nghttp2_ping;
typedef struct {
  nghttp2_frame_hd hd;
  int32_t last_stream_id;
  uint32_t error_code;
  uint8_t *opaque_data;
  size_t opaque_data_len;
  uint8_t reserved;
} nghttp2_goaway;
typedef struct {
  nghttp2_frame_hd hd;
  int32_t window_size_increment;
  uint8_t reserved;
} nghttp2_window_update;
typedef struct {
  nghttp2_frame_hd hd;
  void *payload;
} nghttp2_extension;
typedef union {
  nghttp2_frame_hd hd;
  nghttp2_data data;
  nghttp2_headers headers;
  nghttp2_priority priority;
  nghttp2_rst_stream rst_stream;
  nghttp2_settings settings;
  nghttp2_push_promise push_promise;
  nghttp2_ping ping;
  nghttp2_goaway goaway;
  nghttp2_window_update window_update;
  nghttp2_extension ext;
} nghttp2_frame;
typedef ssize_t (*nghttp2_send_callback)(nghttp2_session *session,
                                         const uint8_t *data, size_t length,
                                         int flags, void *user_data);
typedef int (*nghttp2_send_data_callback)(nghttp2_session *session,
                                          nghttp2_frame *frame,
                                          const uint8_t *framehd, size_t length,
                                          nghttp2_data_source *source,
                                          void *user_data);
typedef ssize_t (*nghttp2_recv_callback)(nghttp2_session *session, uint8_t *buf,
                                         size_t length, int flags,
                                         void *user_data);
typedef int (*nghttp2_on_frame_recv_callback)(nghttp2_session *session,
                                              const nghttp2_frame *frame,
                                              void *user_data);
typedef int (*nghttp2_on_invalid_frame_recv_callback)(
    nghttp2_session *session, const nghttp2_frame *frame, int lib_error_code,
    void *user_data);
typedef int (*nghttp2_on_data_chunk_recv_callback)(nghttp2_session *session,
                                                   uint8_t flags,
                                                   int32_t stream_id,
                                                   const uint8_t *data,
                                                   size_t len, void *user_data);
typedef int (*nghttp2_before_frame_send_callback)(nghttp2_session *session,
                                                  const nghttp2_frame *frame,
                                                  void *user_data);
typedef int (*nghttp2_on_frame_send_callback)(nghttp2_session *session,
                                              const nghttp2_frame *frame,
                                              void *user_data);
typedef int (*nghttp2_on_frame_not_send_callback)(nghttp2_session *session,
                                                  const nghttp2_frame *frame,
                                                  int lib_error_code,
                                                  void *user_data);
typedef int (*nghttp2_on_stream_close_callback)(nghttp2_session *session,
                                                int32_t stream_id,
                                                uint32_t error_code,
                                                void *user_data);
typedef int (*nghttp2_on_begin_headers_callback)(nghttp2_session *session,
                                                 const nghttp2_frame *frame,
                                                 void *user_data);
typedef int (*nghttp2_on_header_callback)(nghttp2_session *session,
                                          const nghttp2_frame *frame,
                                          const uint8_t *name, size_t namelen,
                                          const uint8_t *value, size_t valuelen,
                                          uint8_t flags, void *user_data);
typedef int (*nghttp2_on_header_callback2)(nghttp2_session *session,
                                           const nghttp2_frame *frame,
                                           nghttp2_rcbuf *name,
                                           nghttp2_rcbuf *value, uint8_t flags,
                                           void *user_data);
typedef int (*nghttp2_on_invalid_header_callback)(
    nghttp2_session *session, const nghttp2_frame *frame, const uint8_t *name,
    size_t namelen, const uint8_t *value, size_t valuelen, uint8_t flags,
    void *user_data);
typedef int (*nghttp2_on_invalid_header_callback2)(
    nghttp2_session *session, const nghttp2_frame *frame, nghttp2_rcbuf *name,
    nghttp2_rcbuf *value, uint8_t flags, void *user_data);
typedef ssize_t (*nghttp2_select_padding_callback)(nghttp2_session *session,
                                                   const nghttp2_frame *frame,
                                                   size_t max_payloadlen,
                                                   void *user_data);
typedef ssize_t (*nghttp2_data_source_read_length_callback)(
    nghttp2_session *session, uint8_t frame_type, int32_t stream_id,
    int32_t session_remote_window_size, int32_t stream_remote_window_size,
    uint32_t remote_max_frame_size, void *user_data);
typedef int (*nghttp2_on_begin_frame_callback)(nghttp2_session *session,
                                               const nghttp2_frame_hd *hd,
                                               void *user_data);
typedef int (*nghttp2_on_extension_chunk_recv_callback)(
    nghttp2_session *session, const nghttp2_frame_hd *hd, const uint8_t *data,
    size_t len, void *user_data);
typedef int (*nghttp2_unpack_extension_callback)(nghttp2_session *session,
                                                 void **payload,
                                                 const nghttp2_frame_hd *hd,
                                                 void *user_data);
typedef ssize_t (*nghttp2_pack_extension_callback)(nghttp2_session *session,
                                                   uint8_t *buf, size_t len,
                                                   const nghttp2_frame *frame,
                                                   void *user_data);
typedef int (*nghttp2_error_callback)(nghttp2_session *session, const char *msg,
                                      size_t len, void *user_data);
typedef int (*nghttp2_error_callback2)(nghttp2_session *session,
                                       int lib_error_code, const char *msg,
                                       size_t len, void *user_data);
struct nghttp2_session_callbacks;
typedef struct nghttp2_session_callbacks nghttp2_session_callbacks;
 int
nghttp2_session_callbacks_new(nghttp2_session_callbacks **callbacks_ptr);
 void
nghttp2_session_callbacks_del(nghttp2_session_callbacks *callbacks);
 void nghttp2_session_callbacks_set_send_callback(
    nghttp2_session_callbacks *cbs, nghttp2_send_callback send_callback);
 void nghttp2_session_callbacks_set_recv_callback(
    nghttp2_session_callbacks *cbs, nghttp2_recv_callback recv_callback);
 void nghttp2_session_callbacks_set_on_frame_recv_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_frame_recv_callback on_frame_recv_callback);
 void
nghttp2_session_callbacks_set_on_invalid_frame_recv_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_invalid_frame_recv_callback on_invalid_frame_recv_callback);
 void nghttp2_session_callbacks_set_on_data_chunk_recv_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_data_chunk_recv_callback on_data_chunk_recv_callback);
 void nghttp2_session_callbacks_set_before_frame_send_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_before_frame_send_callback before_frame_send_callback);
 void nghttp2_session_callbacks_set_on_frame_send_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_frame_send_callback on_frame_send_callback);
 void nghttp2_session_callbacks_set_on_frame_not_send_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_frame_not_send_callback on_frame_not_send_callback);
 void nghttp2_session_callbacks_set_on_stream_close_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_stream_close_callback on_stream_close_callback);
 void nghttp2_session_callbacks_set_on_begin_headers_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_begin_headers_callback on_begin_headers_callback);
 void nghttp2_session_callbacks_set_on_header_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_header_callback on_header_callback);
 void nghttp2_session_callbacks_set_on_header_callback2(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_header_callback2 on_header_callback2);
 void nghttp2_session_callbacks_set_on_invalid_header_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_invalid_header_callback on_invalid_header_callback);
 void nghttp2_session_callbacks_set_on_invalid_header_callback2(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_invalid_header_callback2 on_invalid_header_callback2);
 void nghttp2_session_callbacks_set_select_padding_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_select_padding_callback select_padding_callback);
 void
nghttp2_session_callbacks_set_data_source_read_length_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_data_source_read_length_callback data_source_read_length_callback);
 void nghttp2_session_callbacks_set_on_begin_frame_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_begin_frame_callback on_begin_frame_callback);
 void nghttp2_session_callbacks_set_send_data_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_send_data_callback send_data_callback);
 void nghttp2_session_callbacks_set_pack_extension_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_pack_extension_callback pack_extension_callback);
 void nghttp2_session_callbacks_set_unpack_extension_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_unpack_extension_callback unpack_extension_callback);
 void
nghttp2_session_callbacks_set_on_extension_chunk_recv_callback(
    nghttp2_session_callbacks *cbs,
    nghttp2_on_extension_chunk_recv_callback on_extension_chunk_recv_callback);
 void nghttp2_session_callbacks_set_error_callback(
    nghttp2_session_callbacks *cbs, nghttp2_error_callback error_callback);
 void nghttp2_session_callbacks_set_error_callback2(
    nghttp2_session_callbacks *cbs, nghttp2_error_callback2 error_callback2);
typedef void *(*nghttp2_malloc)(size_t size, void *mem_user_data);
typedef void (*nghttp2_free)(void *ptr, void *mem_user_data);
typedef void *(*nghttp2_calloc)(size_t nmemb, size_t size, void *mem_user_data);
typedef void *(*nghttp2_realloc)(void *ptr, size_t size, void *mem_user_data);
typedef struct {
  void *mem_user_data;
  nghttp2_malloc malloc;
  nghttp2_free free;
  nghttp2_calloc calloc;
  nghttp2_realloc realloc;
} nghttp2_mem;
struct nghttp2_option;
typedef struct nghttp2_option nghttp2_option;
 int nghttp2_option_new(nghttp2_option **option_ptr);
 void nghttp2_option_del(nghttp2_option *option);
 void
nghttp2_option_set_no_auto_window_update(nghttp2_option *option, int val);
 void
nghttp2_option_set_peer_max_concurrent_streams(nghttp2_option *option,
                                               uint32_t val);
 void
nghttp2_option_set_no_recv_client_magic(nghttp2_option *option, int val);
 void nghttp2_option_set_no_http_messaging(nghttp2_option *option,
                                                         int val);
 void
nghttp2_option_set_max_reserved_remote_streams(nghttp2_option *option,
                                               uint32_t val);
 void
nghttp2_option_set_user_recv_extension_type(nghttp2_option *option,
                                            uint8_t type);
 void
nghttp2_option_set_builtin_recv_extension_type(nghttp2_option *option,
                                               uint8_t type);
 void nghttp2_option_set_no_auto_ping_ack(nghttp2_option *option,
                                                        int val);
 void
nghttp2_option_set_max_send_header_block_length(nghttp2_option *option,
                                                size_t val);
 void
nghttp2_option_set_max_deflate_dynamic_table_size(nghttp2_option *option,
                                                  size_t val);
 void nghttp2_option_set_no_closed_streams(nghttp2_option *option,
                                                         int val);
 void nghttp2_option_set_max_outbound_ack(nghttp2_option *option,
                                                        size_t val);
 void nghttp2_option_set_max_settings(nghttp2_option *option,
                                                    size_t val);
 void
nghttp2_option_set_server_fallback_rfc7540_priorities(nghttp2_option *option,
                                                      int val);
 void
nghttp2_option_set_no_rfc9113_leading_and_trailing_ws_validation(
    nghttp2_option *option, int val);
 void
nghttp2_option_set_stream_reset_rate_limit(nghttp2_option *option,
                                           uint64_t burst, uint64_t rate);
 void nghttp2_option_set_max_continuations(nghttp2_option *option,
                                                         size_t val);
 int
nghttp2_session_client_new(nghttp2_session **session_ptr,
                           const nghttp2_session_callbacks *callbacks,
                           void *user_data);
 int
nghttp2_session_server_new(nghttp2_session **session_ptr,
                           const nghttp2_session_callbacks *callbacks,
                           void *user_data);
 int
nghttp2_session_client_new2(nghttp2_session **session_ptr,
                            const nghttp2_session_callbacks *callbacks,
                            void *user_data, const nghttp2_option *option);
 int
nghttp2_session_server_new2(nghttp2_session **session_ptr,
                            const nghttp2_session_callbacks *callbacks,
                            void *user_data, const nghttp2_option *option);
 int nghttp2_session_client_new3(
    nghttp2_session **session_ptr, const nghttp2_session_callbacks *callbacks,
    void *user_data, const nghttp2_option *option, nghttp2_mem *mem);
 int nghttp2_session_server_new3(
    nghttp2_session **session_ptr, const nghttp2_session_callbacks *callbacks,
    void *user_data, const nghttp2_option *option, nghttp2_mem *mem);
 void nghttp2_session_del(nghttp2_session *session);
 int nghttp2_session_send(nghttp2_session *session);
 ssize_t nghttp2_session_mem_send(nghttp2_session *session,
                                                const uint8_t **data_ptr);
 int nghttp2_session_recv(nghttp2_session *session);
 ssize_t nghttp2_session_mem_recv(nghttp2_session *session,
                                                const uint8_t *in,
                                                size_t inlen);
 int nghttp2_session_resume_data(nghttp2_session *session,
                                               int32_t stream_id);
 int nghttp2_session_want_read(nghttp2_session *session);
 int nghttp2_session_want_write(nghttp2_session *session);
 void *
nghttp2_session_get_stream_user_data(nghttp2_session *session,
                                     int32_t stream_id);
 int
nghttp2_session_set_stream_user_data(nghttp2_session *session,
                                     int32_t stream_id, void *stream_user_data);
 void nghttp2_session_set_user_data(nghttp2_session *session,
                                                  void *user_data);
 size_t
nghttp2_session_get_outbound_queue_size(nghttp2_session *session);
 int32_t nghttp2_session_get_stream_effective_recv_data_length(
    nghttp2_session *session, int32_t stream_id);
 int32_t nghttp2_session_get_stream_effective_local_window_size(
    nghttp2_session *session, int32_t stream_id);
 int32_t nghttp2_session_get_stream_local_window_size(
    nghttp2_session *session, int32_t stream_id);
 int32_t
nghttp2_session_get_effective_recv_data_length(nghttp2_session *session);
 int32_t
nghttp2_session_get_effective_local_window_size(nghttp2_session *session);
 int32_t
nghttp2_session_get_local_window_size(nghttp2_session *session);
 int32_t nghttp2_session_get_stream_remote_window_size(
    nghttp2_session *session, int32_t stream_id);
 int32_t
nghttp2_session_get_remote_window_size(nghttp2_session *session);
 int
nghttp2_session_get_stream_local_close(nghttp2_session *session,
                                       int32_t stream_id);
 int
nghttp2_session_get_stream_remote_close(nghttp2_session *session,
                                        int32_t stream_id);
 size_t
nghttp2_session_get_hd_inflate_dynamic_table_size(nghttp2_session *session);
 size_t
nghttp2_session_get_hd_deflate_dynamic_table_size(nghttp2_session *session);
 int nghttp2_session_terminate_session(nghttp2_session *session,
                                                     uint32_t error_code);
 int nghttp2_session_terminate_session2(nghttp2_session *session,
                                                      int32_t last_stream_id,
                                                      uint32_t error_code);
 int nghttp2_submit_shutdown_notice(nghttp2_session *session);
 uint32_t nghttp2_session_get_remote_settings(
    nghttp2_session *session, nghttp2_settings_id id);
 uint32_t nghttp2_session_get_local_settings(
    nghttp2_session *session, nghttp2_settings_id id);
 int nghttp2_session_set_next_stream_id(nghttp2_session *session,
                                                      int32_t next_stream_id);
 uint32_t
nghttp2_session_get_next_stream_id(nghttp2_session *session);
 int nghttp2_session_consume(nghttp2_session *session,
                                           int32_t stream_id, size_t size);
 int nghttp2_session_consume_connection(nghttp2_session *session,
                                                      size_t size);
 int nghttp2_session_consume_stream(nghttp2_session *session,
                                                  int32_t stream_id,
                                                  size_t size);
 int
nghttp2_session_change_stream_priority(nghttp2_session *session,
                                       int32_t stream_id,
                                       const nghttp2_priority_spec *pri_spec);
 int
nghttp2_session_create_idle_stream(nghttp2_session *session, int32_t stream_id,
                                   const nghttp2_priority_spec *pri_spec);
 int nghttp2_session_upgrade(nghttp2_session *session,
                                           const uint8_t *settings_payload,
                                           size_t settings_payloadlen,
                                           void *stream_user_data);
 int nghttp2_session_upgrade2(nghttp2_session *session,
                                            const uint8_t *settings_payload,
                                            size_t settings_payloadlen,
                                            int head_request,
                                            void *stream_user_data);
 ssize_t nghttp2_pack_settings_payload(
    uint8_t *buf, size_t buflen, const nghttp2_settings_entry *iv, size_t niv);
 const char *nghttp2_strerror(int lib_error_code);
 const char *nghttp2_http2_strerror(uint32_t error_code);
 void nghttp2_priority_spec_init(nghttp2_priority_spec *pri_spec,
                                               int32_t stream_id,
                                               int32_t weight, int exclusive);
 void
nghttp2_priority_spec_default_init(nghttp2_priority_spec *pri_spec);
 int
nghttp2_priority_spec_check_default(const nghttp2_priority_spec *pri_spec);
 int32_t nghttp2_submit_request(
    nghttp2_session *session, const nghttp2_priority_spec *pri_spec,
    const nghttp2_nv *nva, size_t nvlen, const nghttp2_data_provider *data_prd,
    void *stream_user_data);
 int
nghttp2_submit_response(nghttp2_session *session, int32_t stream_id,
                        const nghttp2_nv *nva, size_t nvlen,
                        const nghttp2_data_provider *data_prd);
 int nghttp2_submit_trailer(nghttp2_session *session,
                                          int32_t stream_id,
                                          const nghttp2_nv *nva, size_t nvlen);
 int32_t nghttp2_submit_headers(
    nghttp2_session *session, uint8_t flags, int32_t stream_id,
    const nghttp2_priority_spec *pri_spec, const nghttp2_nv *nva, size_t nvlen,
    void *stream_user_data);
 int nghttp2_submit_data(nghttp2_session *session, uint8_t flags,
                                       int32_t stream_id,
                                       const nghttp2_data_provider *data_prd);
 int
nghttp2_submit_priority(nghttp2_session *session, uint8_t flags,
                        int32_t stream_id,
                        const nghttp2_priority_spec *pri_spec);
typedef struct nghttp2_extpri {
  uint32_t urgency;
  int inc;
} nghttp2_extpri;
 int nghttp2_submit_rst_stream(nghttp2_session *session,
                                             uint8_t flags, int32_t stream_id,
                                             uint32_t error_code);
 int nghttp2_submit_settings(nghttp2_session *session,
                                           uint8_t flags,
                                           const nghttp2_settings_entry *iv,
                                           size_t niv);
 int32_t nghttp2_submit_push_promise(
    nghttp2_session *session, uint8_t flags, int32_t stream_id,
    const nghttp2_nv *nva, size_t nvlen, void *promised_stream_user_data);
 int nghttp2_submit_ping(nghttp2_session *session, uint8_t flags,
                                       const uint8_t *opaque_data);
 int nghttp2_submit_goaway(nghttp2_session *session,
                                         uint8_t flags, int32_t last_stream_id,
                                         uint32_t error_code,
                                         const uint8_t *opaque_data,
                                         size_t opaque_data_len);
 int32_t
nghttp2_session_get_last_proc_stream_id(nghttp2_session *session);
 int
nghttp2_session_check_request_allowed(nghttp2_session *session);
 int
nghttp2_session_check_server_session(nghttp2_session *session);
 int nghttp2_submit_window_update(nghttp2_session *session,
                                                uint8_t flags,
                                                int32_t stream_id,
                                                int32_t window_size_increment);
 int
nghttp2_session_set_local_window_size(nghttp2_session *session, uint8_t flags,
                                      int32_t stream_id, int32_t window_size);
 int nghttp2_submit_extension(nghttp2_session *session,
                                            uint8_t type, uint8_t flags,
                                            int32_t stream_id, void *payload);
typedef struct {
  uint8_t *origin;
  size_t origin_len;
  uint8_t *field_value;
  size_t field_value_len;
} nghttp2_ext_altsvc;
 int nghttp2_submit_altsvc(nghttp2_session *session,
                                         uint8_t flags, int32_t stream_id,
                                         const uint8_t *origin,
                                         size_t origin_len,
                                         const uint8_t *field_value,
                                         size_t field_value_len);
typedef struct {
  uint8_t *origin;
  size_t origin_len;
} nghttp2_origin_entry;
typedef struct {
  size_t nov;
  nghttp2_origin_entry *ov;
} nghttp2_ext_origin;
 int nghttp2_submit_origin(nghttp2_session *session,
                                         uint8_t flags,
                                         const nghttp2_origin_entry *ov,
                                         size_t nov);
typedef struct {
  int32_t stream_id;
  uint8_t *field_value;
  size_t field_value_len;
} nghttp2_ext_priority_update;
 int nghttp2_submit_priority_update(nghttp2_session *session,
                                                  uint8_t flags,
                                                  int32_t stream_id,
                                                  const uint8_t *field_value,
                                                  size_t field_value_len);
 int nghttp2_session_change_extpri_stream_priority(
    nghttp2_session *session, int32_t stream_id, const nghttp2_extpri *extpri,
    int ignore_client_signal);
 int nghttp2_session_get_extpri_stream_priority(
    nghttp2_session *session, nghttp2_extpri *extpri, int32_t stream_id);
 int nghttp2_extpri_parse_priority(nghttp2_extpri *extpri,
                                                 const uint8_t *value,
                                                 size_t len);
 int nghttp2_nv_compare_name(const nghttp2_nv *lhs,
                                           const nghttp2_nv *rhs);
 int nghttp2_select_next_protocol(unsigned char **out,
                                                unsigned char *outlen,
                                                const unsigned char *in,
                                                unsigned int inlen);
 int nghttp2_select_alpn(const unsigned char **out,
                                       unsigned char *outlen,
                                       const unsigned char *in,
                                       unsigned int inlen);
 nghttp2_info *nghttp2_version(int least_version);
 int nghttp2_is_fatal(int lib_error_code);
 int nghttp2_check_header_name(const uint8_t *name, size_t len);
 int nghttp2_check_header_value(const uint8_t *value, size_t len);
 int nghttp2_check_header_value_rfc9113(const uint8_t *value,
                                                      size_t len);
 int nghttp2_check_method(const uint8_t *value, size_t len);
 int nghttp2_check_path(const uint8_t *value, size_t len);
 int nghttp2_check_authority(const uint8_t *value, size_t len);
struct nghttp2_hd_deflater;
typedef struct nghttp2_hd_deflater nghttp2_hd_deflater;
 int
nghttp2_hd_deflate_new(nghttp2_hd_deflater **deflater_ptr,
                       size_t max_deflate_dynamic_table_size);
 int
nghttp2_hd_deflate_new2(nghttp2_hd_deflater **deflater_ptr,
                        size_t max_deflate_dynamic_table_size,
                        nghttp2_mem *mem);
 void nghttp2_hd_deflate_del(nghttp2_hd_deflater *deflater);
 int
nghttp2_hd_deflate_change_table_size(nghttp2_hd_deflater *deflater,
                                     size_t settings_max_dynamic_table_size);
 ssize_t nghttp2_hd_deflate_hd(nghttp2_hd_deflater *deflater,
                                             uint8_t *buf, size_t buflen,
                                             const nghttp2_nv *nva,
                                             size_t nvlen);
 ssize_t nghttp2_hd_deflate_hd_vec(nghttp2_hd_deflater *deflater,
                                                 const nghttp2_vec *vec,
                                                 size_t veclen,
                                                 const nghttp2_nv *nva,
                                                 size_t nvlen);
 size_t nghttp2_hd_deflate_bound(nghttp2_hd_deflater *deflater,
                                               const nghttp2_nv *nva,
                                               size_t nvlen);

size_t nghttp2_hd_deflate_get_num_table_entries(nghttp2_hd_deflater *deflater);

const nghttp2_nv *
nghttp2_hd_deflate_get_table_entry(nghttp2_hd_deflater *deflater, size_t idx);

size_t nghttp2_hd_deflate_get_dynamic_table_size(nghttp2_hd_deflater *deflater);

size_t
nghttp2_hd_deflate_get_max_dynamic_table_size(nghttp2_hd_deflater *deflater);
struct nghttp2_hd_inflater;
typedef struct nghttp2_hd_inflater nghttp2_hd_inflater;
 int nghttp2_hd_inflate_new(nghttp2_hd_inflater **inflater_ptr);
 int nghttp2_hd_inflate_new2(nghttp2_hd_inflater **inflater_ptr,
                                           nghttp2_mem *mem);
 void nghttp2_hd_inflate_del(nghttp2_hd_inflater *inflater);
 int
nghttp2_hd_inflate_change_table_size(nghttp2_hd_inflater *inflater,
                                     size_t settings_max_dynamic_table_size);
typedef enum {
  NGHTTP2_HD_INFLATE_NONE = 0,
  NGHTTP2_HD_INFLATE_FINAL = 0x01,
  NGHTTP2_HD_INFLATE_EMIT = 0x02
} nghttp2_hd_inflate_flag;
 ssize_t nghttp2_hd_inflate_hd(nghttp2_hd_inflater *inflater,
                                             nghttp2_nv *nv_out,
                                             int *inflate_flags, uint8_t *in,
                                             size_t inlen, int in_final);
 ssize_t nghttp2_hd_inflate_hd2(nghttp2_hd_inflater *inflater,
                                              nghttp2_nv *nv_out,
                                              int *inflate_flags,
                                              const uint8_t *in, size_t inlen,
                                              int in_final);
 int
nghttp2_hd_inflate_end_headers(nghttp2_hd_inflater *inflater);

size_t nghttp2_hd_inflate_get_num_table_entries(nghttp2_hd_inflater *inflater);

const nghttp2_nv *
nghttp2_hd_inflate_get_table_entry(nghttp2_hd_inflater *inflater, size_t idx);

size_t nghttp2_hd_inflate_get_dynamic_table_size(nghttp2_hd_inflater *inflater);

size_t
nghttp2_hd_inflate_get_max_dynamic_table_size(nghttp2_hd_inflater *inflater);
struct nghttp2_stream;
typedef struct nghttp2_stream nghttp2_stream;
 nghttp2_stream *
nghttp2_session_find_stream(nghttp2_session *session, int32_t stream_id);
typedef enum {
  NGHTTP2_STREAM_STATE_IDLE = 1,
  NGHTTP2_STREAM_STATE_OPEN,
  NGHTTP2_STREAM_STATE_RESERVED_LOCAL,
  NGHTTP2_STREAM_STATE_RESERVED_REMOTE,
  NGHTTP2_STREAM_STATE_HALF_CLOSED_LOCAL,
  NGHTTP2_STREAM_STATE_HALF_CLOSED_REMOTE,
  NGHTTP2_STREAM_STATE_CLOSED
} nghttp2_stream_proto_state;
 nghttp2_stream_proto_state
nghttp2_stream_get_state(nghttp2_stream *stream);
 nghttp2_stream *
nghttp2_session_get_root_stream(nghttp2_session *session);
 nghttp2_stream *
nghttp2_stream_get_parent(nghttp2_stream *stream);
 int32_t nghttp2_stream_get_stream_id(nghttp2_stream *stream);
 nghttp2_stream *
nghttp2_stream_get_next_sibling(nghttp2_stream *stream);
 nghttp2_stream *
nghttp2_stream_get_previous_sibling(nghttp2_stream *stream);
 nghttp2_stream *
nghttp2_stream_get_first_child(nghttp2_stream *stream);
 int32_t nghttp2_stream_get_weight(nghttp2_stream *stream);
 int32_t
nghttp2_stream_get_sum_dependency_weight(nghttp2_stream *stream);
typedef void (*nghttp2_debug_vprintf_callback)(const char *format,
                                               va_list args);
 void nghttp2_set_debug_vprintf_callback(
    nghttp2_debug_vprintf_callback debug_vprintf_callback);
struct h2_session;
struct h2_stream;
extern const char *H2_MAGIC_TOKEN;
typedef enum {
    H2_DEPENDANT_AFTER,
    H2_DEPENDANT_INTERLEAVED,
    H2_DEPENDANT_BEFORE,
} h2_dependency;
typedef struct h2_priority {
    h2_dependency dependency;
    int weight;
} h2_priority;
typedef enum {
    H2_PUSH_NONE,
    H2_PUSH_DEFAULT,
    H2_PUSH_HEAD,
    H2_PUSH_FAST_LOAD,
} h2_push_policy;
typedef enum {
    H2_SESSION_ST_INIT,
    H2_SESSION_ST_DONE,
    H2_SESSION_ST_IDLE,
    H2_SESSION_ST_BUSY,
    H2_SESSION_ST_WAIT,
    H2_SESSION_ST_CLEANUP,
} h2_session_state;
typedef struct h2_session_props {
    int accepted_max;
    int completed_max;
    int emitted_count;
    int emitted_max;
    int error;
    const char *error_msg;
    unsigned int accepting : 1;
    unsigned int shutdown : 1;
} h2_session_props;
typedef enum h2_stream_state_t {
    H2_SS_IDLE,
    H2_SS_RSVD_R,
    H2_SS_RSVD_L,
    H2_SS_OPEN,
    H2_SS_CLOSED_R,
    H2_SS_CLOSED_L,
    H2_SS_CLOSED,
    H2_SS_CLEANUP,
    H2_SS_MAX
} h2_stream_state_t;
typedef enum {
    H2_SEV_CLOSED_L,
    H2_SEV_CLOSED_R,
    H2_SEV_CANCELLED,
    H2_SEV_EOS_SENT,
    H2_SEV_IN_ERROR,
    H2_SEV_IN_DATA_PENDING,
    H2_SEV_OUT_C1_BLOCK,
} h2_stream_event_t;
typedef struct h2_request h2_request;
struct h2_request {
    const char *method;
    const char *scheme;
    const char *authority;
    const char *path;
    const char *protocol;
    apr_table_t *headers;
    apr_time_t request_time;
    apr_off_t raw_bytes;
    int http_status;
};
typedef apr_status_t h2_io_data_cb(void *ctx, const char *data, apr_off_t len);
typedef int h2_stream_pri_cmp_fn(int stream_id1, int stream_id2, void *session);
typedef struct h2_stream *h2_stream_get_fn(struct h2_session *session, int stream_id);
struct h2_bucket_beam;
typedef struct h2_headers h2_headers;
struct h2_headers {
    int status;
    apr_table_t *headers;
    apr_table_t *notes;
    apr_off_t raw_bytes;
};
extern const apr_bucket_type_t h2_bucket_type_headers;
apr_bucket * h2_bucket_headers_make(apr_bucket *b, h2_headers *r);
apr_bucket * h2_bucket_headers_create(apr_bucket_alloc_t *list,
                                       h2_headers *r);
h2_headers *h2_bucket_headers_get(apr_bucket *b);
h2_headers *h2_headers_create(int status, const apr_table_t *header,
                              const apr_table_t *notes, apr_off_t raw_bytes,
                              apr_pool_t *pool);
h2_headers *h2_headers_rcreate(request_rec *r, int status,
                               const apr_table_t *header, apr_pool_t *pool);
h2_headers *h2_headers_copy(apr_pool_t *pool, h2_headers *h);
h2_headers *h2_headers_clone(apr_pool_t *pool, h2_headers *h);
h2_headers *h2_headers_die(apr_status_t type,
                           const struct h2_request *req, apr_pool_t *pool);
int h2_headers_are_final_response(h2_headers *headers);
apr_size_t h2_headers_length(h2_headers *headers);
apr_size_t h2_bucket_headers_headers_length(apr_bucket *b);
apr_bucket *h2_bucket_headers_clone(apr_bucket *b, apr_pool_t *pool,
                                    apr_bucket_alloc_t *list);
struct h2_mplx;
struct h2_priority;
struct h2_request;
struct h2_session;
struct h2_bucket_beam;
typedef struct h2_stream h2_stream;
typedef void h2_stream_state_cb(void *ctx, h2_stream *stream);
typedef void h2_stream_event_cb(void *ctx, h2_stream *stream,
                                h2_stream_event_t ev);
typedef struct h2_stream_monitor {
    void *ctx;
    h2_stream_state_cb *on_state_enter;
    h2_stream_state_cb *on_state_invalid;
    h2_stream_event_cb *on_state_event;
    h2_stream_event_cb *on_event;
} h2_stream_monitor;
struct h2_stream {
    int id;
    int initiated_on;
    apr_pool_t *pool;
    struct h2_session *session;
    h2_stream_state_t state;
    apr_time_t created;
    const struct h2_request *request;
    struct h2_request *rtmp;
    apr_table_t *trailers_in;
    int request_headers_added;
    int request_headers_failed;
    struct h2_headers *response;
    struct h2_bucket_beam *input;
    apr_bucket_brigade *in_buffer;
    int in_window_size;
    apr_time_t in_last_write;
    struct h2_bucket_beam *output;
    apr_bucket_brigade *out_buffer;
    int rst_error;
    unsigned int aborted : 1;
    unsigned int scheduled : 1;
    unsigned int input_closed : 1;
    unsigned int mplx_cleanup_done : 1;
    unsigned int push_policy;
    unsigned int sent_trailers : 1;
    unsigned int output_eos : 1;
    conn_rec *c2;
    const h2_priority *pref_priority;
    apr_off_t out_frames;
    apr_off_t out_frame_octets;
    apr_off_t out_data_frames;
    apr_off_t out_data_octets;
    apr_off_t in_data_frames;
    apr_off_t in_data_octets;
    apr_off_t in_trailer_octets;
    h2_stream_monitor *monitor;
};
h2_stream *h2_stream_create(int id, apr_pool_t *pool,
                            struct h2_session *session,
                            h2_stream_monitor *monitor,
                            int initiated_on);
void h2_stream_destroy(h2_stream *stream);
apr_status_t h2_stream_prepare_processing(h2_stream *stream);
void h2_stream_set_monitor(h2_stream *stream, h2_stream_monitor *monitor);
void h2_stream_dispatch(h2_stream *stream, h2_stream_event_t ev);
int h2_stream_is_at(const h2_stream *stream, h2_stream_state_t state);
int h2_stream_is_at_or_past(const h2_stream *stream, h2_stream_state_t state);
void h2_stream_cleanup(h2_stream *stream);
apr_status_t h2_stream_in_consumed(h2_stream *stream, apr_off_t amount);
void h2_stream_set_request(h2_stream *stream, const h2_request *r);
apr_status_t h2_stream_set_request_rec(h2_stream *stream,
                                       request_rec *r, int eos);
apr_status_t h2_stream_add_header(h2_stream *stream,
                                  const char *name, size_t nlen,
                                  const char *value, size_t vlen);
apr_status_t h2_stream_end_headers(h2_stream *stream, int eos, size_t raw_bytes);
apr_status_t h2_stream_send_frame(h2_stream *stream, int frame_type, int flags, size_t frame_len);
apr_status_t h2_stream_recv_frame(h2_stream *stream, int frame_type, int flags, size_t frame_len);
apr_status_t h2_stream_recv_DATA(h2_stream *stream, uint8_t flags,
                                 const uint8_t *data, size_t len);
void h2_stream_rst(h2_stream *stream, int error_code);
void h2_stream_on_input_change(h2_stream *stream);
void h2_stream_on_output_change(h2_stream *stream);
apr_status_t h2_stream_read_to(h2_stream *stream, apr_bucket_brigade *bb,
                               apr_off_t *plen, int *peos);
apr_table_t *h2_stream_get_trailers(h2_stream *stream);
apr_status_t h2_stream_submit_pushes(h2_stream *stream,
                                     struct h2_headers *response);
const struct h2_priority *h2_stream_get_priority(h2_stream *stream,
                                                 struct h2_headers *response);
const char *h2_stream_state_str(const h2_stream *stream);
int h2_stream_is_ready(h2_stream *stream);
int h2_stream_wants_send_data(h2_stream *stream);
typedef struct apr_hash_t apr_hash_t;
typedef struct apr_hash_index_t apr_hash_index_t;
typedef unsigned int (*apr_hashfunc_t)(const char *key, apr_ssize_t *klen);
unsigned int apr_hashfunc_default(const char *key,
                                                      apr_ssize_t *klen);
apr_hash_t * apr_hash_make(apr_pool_t *pool);
apr_hash_t * apr_hash_make_custom(apr_pool_t *pool,
                                               apr_hashfunc_t hash_func);
apr_hash_t * apr_hash_copy(apr_pool_t *pool,
                                        const apr_hash_t *h);
void apr_hash_set(apr_hash_t *ht, const void *key,
                               apr_ssize_t klen, const void *val);
void * apr_hash_get(apr_hash_t *ht, const void *key,
                                 apr_ssize_t klen);
apr_hash_index_t * apr_hash_first(apr_pool_t *p, apr_hash_t *ht);
apr_hash_index_t * apr_hash_next(apr_hash_index_t *hi);
void apr_hash_this(apr_hash_index_t *hi, const void **key,
                                apr_ssize_t *klen, void **val);
const void* apr_hash_this_key(apr_hash_index_t *hi);
apr_ssize_t apr_hash_this_key_len(apr_hash_index_t *hi);
void* apr_hash_this_val(apr_hash_index_t *hi);
unsigned int apr_hash_count(apr_hash_t *ht);
void apr_hash_clear(apr_hash_t *ht);
apr_hash_t * apr_hash_overlay(apr_pool_t *p,
                                           const apr_hash_t *overlay,
                                           const apr_hash_t *base);
apr_hash_t * apr_hash_merge(apr_pool_t *p,
                                         const apr_hash_t *h1,
                                         const apr_hash_t *h2,
                                         void * (*merger)(apr_pool_t *p,
                                                     const void *key,
                                                     apr_ssize_t klen,
                                                     const void *h1_val,
                                                     const void *h2_val,
                                                     const void *data),
                                         const void *data);
typedef int (apr_hash_do_callback_fn_t)(void *rec, const void *key,
                                                   apr_ssize_t klen,
                                                   const void *value);
int apr_hash_do(apr_hash_do_callback_fn_t *comp,
                             void *rec, const apr_hash_t *ht);
apr_pool_t * apr_hash_pool_get (const apr_hash_t *thehash);
typedef struct ap_expr_node ap_expr_t;
typedef struct {
    ap_expr_t *root_node;
    const char *filename;
    unsigned int line_number;
    unsigned int flags;
    int module_index;
} ap_expr_info_t;
int ap_expr_exec(request_rec *r, const ap_expr_info_t *expr,
                             const char **err);
int ap_expr_exec_re(request_rec *r, const ap_expr_info_t *expr,
                                apr_size_t nmatch, ap_regmatch_t *pmatch,
                                const char **source, const char **err);
typedef struct {
    request_rec *r;
    conn_rec *c;
    server_rec *s;
    apr_pool_t *p;
    const char **err;
    const ap_expr_info_t *info;
    ap_regmatch_t *re_pmatch;
    apr_size_t re_nmatch;
    const char **re_source;
    const char **vary_this;
    const char **result_string;
    void *data;
    int reclvl;
} ap_expr_eval_ctx_t;
int ap_expr_exec_ctx(ap_expr_eval_ctx_t *ctx);
const char * ap_expr_str_exec(request_rec *r,
                                          const ap_expr_info_t *expr,
                                          const char **err);
const char * ap_expr_str_exec_re(request_rec *r,
                                             const ap_expr_info_t *expr,
                                             apr_size_t nmatch,
                                             ap_regmatch_t *pmatch,
                                             const char **source,
                                             const char **err);
typedef int ap_expr_op_unary_t(ap_expr_eval_ctx_t *ctx, const void *data,
                               const char *arg);
typedef int ap_expr_op_binary_t(ap_expr_eval_ctx_t *ctx, const void *data,
                                const char *arg1, const char *arg2);
typedef const char *(ap_expr_string_func_t)(ap_expr_eval_ctx_t *ctx,
                                            const void *data,
                                            const char *arg);
typedef apr_array_header_t *(ap_expr_list_func_t)(ap_expr_eval_ctx_t *ctx,
                                                  const void *data,
                                                  const char *arg);
typedef const char *(ap_expr_var_func_t)(ap_expr_eval_ctx_t *ctx,
                                         const void *data);
typedef struct {
    int type;
    const char *name;
    int flags;
    apr_pool_t *pool;
    apr_pool_t *ptemp;
    const void **func;
    const void **data;
    const char **err;
    const char *arg;
} ap_expr_lookup_parms;
typedef int (ap_expr_lookup_fn_t)(ap_expr_lookup_parms *parms);
int ap_expr_lookup_default(ap_expr_lookup_parms *parms);
typedef int ap_HOOK_expr_lookup_t (ap_expr_lookup_parms *parms); void ap_hook_expr_lookup(ap_HOOK_expr_lookup_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_expr_lookup (ap_expr_lookup_parms *parms); apr_array_header_t * ap_hook_get_expr_lookup(void); typedef struct ap_LINK_expr_lookup_t { ap_HOOK_expr_lookup_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_expr_lookup_t;
const char * ap_expr_parse(apr_pool_t *pool, apr_pool_t *ptemp,
                                       ap_expr_info_t *info, const char *expr,
                                       ap_expr_lookup_fn_t *lookup_fn);
ap_expr_info_t * ap_expr_parse_cmd_mi(const cmd_parms *cmd,
                                                  const char *expr,
                                                  unsigned int flags,
                                                  const char **err,
                                                  ap_expr_lookup_fn_t *lookup_fn,
                                                  int module_index);
void ap_expr_init(apr_pool_t *pool);
int ap_allow_options(request_rec *r);
int ap_allow_overrides(request_rec *r);
const char * ap_document_root(request_rec *r);
const char * ap_get_useragent_host(request_rec *req, int type,
                                               int *str_is_ip);
const char * ap_get_remote_host(conn_rec *conn, void *dir_config, int type, int *str_is_ip);
const char * ap_get_remote_logname(request_rec *r);
char * ap_construct_url(apr_pool_t *p, const char *uri, request_rec *r);
const char * ap_get_server_name(request_rec *r);
const char * ap_get_server_name_for_url(request_rec *r);
apr_port_t ap_get_server_port(const request_rec *r);
apr_size_t ap_get_read_buf_size(const request_rec *r);
apr_off_t ap_get_limit_req_body(const request_rec *r);
apr_size_t ap_get_limit_xml_body(const request_rec *r);
void ap_custom_response(request_rec *r, int status, const char *string);
int ap_is_recursion_limit_exceeded(const request_rec *r);
int ap_exists_config_define(const char *name);
int ap_core_translate(request_rec *r);
typedef struct require_line require_line;
struct require_line {
    apr_int64_t method_mask;
    char *requirement;
};
const char * ap_auth_type(request_rec *r);
const char * ap_auth_name(request_rec *r);
int ap_satisfies(request_rec *r);
 extern module core_module;
void * ap_get_core_module_config(const ap_conf_vector_t *cv);
void ap_set_core_module_config(ap_conf_vector_t *cv, void *val);
apr_socket_t * ap_get_conn_socket(conn_rec *c);
typedef struct {
    struct apr_bucket_brigade *bb;
    void **notes;
    char **response_code_strings;
    const char *document_root;
    const char *context_document_root;
    const char *context_prefix;
    int deliver_script;
    int suppress_charset;
} core_request_config;
apr_size_t ap_register_request_note(void);
void ** ap_get_request_note(request_rec *r, apr_size_t note_num);
typedef unsigned char allow_options_t;
typedef unsigned int overrides_t;
typedef unsigned long etag_components_t;
typedef enum {
    srv_sig_unset,
    srv_sig_off,
    srv_sig_on,
    srv_sig_withmail
} server_signature_e;
typedef struct {
    char *d;
    unsigned d_components;
    allow_options_t opts;
    allow_options_t opts_add;
    allow_options_t opts_remove;
    overrides_t override;
    allow_options_t override_opts;
    char **response_code_strings;
    unsigned int hostname_lookups : 4;
    unsigned int content_md5 : 2;
    unsigned use_canonical_name : 2;
    unsigned d_is_fnmatch : 1;
    unsigned add_default_charset : 2;
    const char *add_default_charset_name;
    struct rlimit *limit_cpu;
    struct rlimit *limit_mem;
    struct rlimit *limit_nproc;
    apr_off_t limit_req_body;
    long limit_xml_body;
    server_signature_e server_signature;
    apr_array_header_t *sec_file;
    apr_array_header_t *sec_if;
    ap_regex_t *r;
    const char *mime_type;
    const char *handler;
    const char *output_filters;
    const char *input_filters;
    int accept_path_info;
    etag_components_t etag_bits;
    etag_components_t etag_add;
    etag_components_t etag_remove;
    unsigned int enable_mmap : 2;
    unsigned int enable_sendfile : 2;
    unsigned int use_canonical_phys_port : 2;
    unsigned int allow_encoded_slashes : 1;
    unsigned int decode_encoded_slashes : 1;
    unsigned int condition_ifelse : 2;
    ap_expr_info_t *condition;
    struct ap_logconf *log;
    apr_table_t *override_list;
    int max_ranges;
    int max_overlaps;
    int max_reversals;
    apr_array_header_t *refs;
    apr_hash_t *response_code_exprs;
    unsigned int cgi_pass_auth : 2;
    unsigned int qualify_redirect_url :2;
    ap_expr_info_t *expr_handler;
    apr_hash_t *cgi_var_rules;
    apr_size_t read_buf_size;
} core_dir_config;
typedef struct {
    char *gprof_dir;
    const char *ap_document_root;
    char *access_name;
    apr_array_header_t *sec_dir;
    apr_array_header_t *sec_url;
    int redirect_limit;
    int subreq_limit;
    const char *protocol;
    apr_table_t *accf_map;
    apr_array_header_t *error_log_format;
    apr_array_header_t *error_log_conn;
    apr_array_header_t *error_log_req;
    int trace_enable;
    int merge_trailers;
    apr_array_header_t *protocols;
    int protocols_honor_order;
    char http09_enable;
    char http_conformance;
    char http_methods;
    unsigned int merge_slashes;
    apr_size_t flush_max_threshold;
    apr_int32_t flush_max_pipelined;
    unsigned int strict_host_check;
} core_server_config;
void ap_add_output_filters_by_type(request_rec *r);
void ap_core_reorder_directories(apr_pool_t *, server_rec *);
void ap_add_per_dir_conf(server_rec *s, void *dir_config);
void ap_add_per_url_conf(server_rec *s, void *url_config);
void ap_add_file_conf(apr_pool_t *p, core_dir_config *conf, void *url_config);
const char * ap_add_if_conf(apr_pool_t *p, core_dir_config *conf, void *url_config);
const char * ap_limit_section(cmd_parms *cmd, void *dummy, const char *arg);
apr_status_t ap_core_input_filter(ap_filter_t *f, apr_bucket_brigade *b,
                                  ap_input_mode_t mode, apr_read_type_e block,
                                  apr_off_t readbytes);
apr_status_t ap_core_output_filter(ap_filter_t *f, apr_bucket_brigade *b);
const char* ap_get_server_protocol(server_rec* s);
void ap_set_server_protocol(server_rec* s, const char* proto);
typedef struct core_output_filter_ctx core_output_filter_ctx_t;
typedef struct core_filter_ctx core_ctx_t;
struct core_filter_ctx {
    apr_bucket_brigade *b;
    apr_bucket_brigade *tmpbb;
};
typedef struct core_net_rec {
    apr_socket_t *client_socket;
    conn_rec *c;
    core_output_filter_ctx_t *out_ctx;
    core_ctx_t *in_ctx;
} core_net_rec;
typedef apr_status_t ap_HOOK_insert_network_bucket_t (conn_rec *c, apr_bucket_brigade *bb, apr_socket_t *socket); void ap_hook_insert_network_bucket(ap_HOOK_insert_network_bucket_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_status_t ap_run_insert_network_bucket (conn_rec *c, apr_bucket_brigade *bb, apr_socket_t *socket); apr_array_header_t * ap_hook_get_insert_network_bucket(void); typedef struct ap_LINK_insert_network_bucket_t { ap_HOOK_insert_network_bucket_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_insert_network_bucket_t;
typedef enum {
    ap_mgmt_type_string,
    ap_mgmt_type_long,
    ap_mgmt_type_hash
} ap_mgmt_type_e;
typedef union {
    const char *s_value;
    long i_value;
    apr_hash_t *h_value;
} ap_mgmt_value;
typedef struct {
    const char *description;
    const char *name;
    ap_mgmt_type_e vtype;
    ap_mgmt_value v;
} ap_mgmt_item_t;
 extern ap_filter_rec_t *ap_subreq_core_filter_handle;
 extern ap_filter_rec_t *ap_core_output_filter_handle;
 extern ap_filter_rec_t *ap_content_length_filter_handle;
 extern ap_filter_rec_t *ap_core_input_filter_handle;
typedef int ap_HOOK_get_mgmt_items_t (apr_pool_t *p, const char * val, apr_hash_t *ht); void ap_hook_get_mgmt_items(ap_HOOK_get_mgmt_items_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); int ap_run_get_mgmt_items (apr_pool_t *p, const char * val, apr_hash_t *ht); apr_array_header_t * ap_hook_get_get_mgmt_items(void); typedef struct ap_LINK_get_mgmt_items_t { ap_HOOK_get_mgmt_items_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_get_mgmt_items_t;
typedef void (apr_OFN_ap_logio_add_bytes_out_t) (conn_rec *c, apr_off_t bytes);
typedef void (apr_OFN_ap_logio_add_bytes_in_t) (conn_rec *c, apr_off_t bytes);
typedef apr_off_t (apr_OFN_ap_logio_get_last_bytes_t) (conn_rec *c);
typedef struct ap_errorlog_info {
    const server_rec *s;
    const conn_rec *c;
    const request_rec *r;
    const request_rec *rmain;
    apr_pool_t *pool;
    const char *file;
    int line;
    int module_index;
    int level;
    apr_status_t status;
    int using_syslog;
    int startup;
    const char *format;
} ap_errorlog_info;
typedef int ap_errorlog_handler_fn_t(const ap_errorlog_info *info,
                                     const char *arg, char *buf, int buflen);
void ap_register_errorlog_handler(apr_pool_t *p, char *tag,
                                              ap_errorlog_handler_fn_t *handler,
                                              int flags);
typedef struct ap_errorlog_handler {
    ap_errorlog_handler_fn_t *func;
    int flags;
} ap_errorlog_handler;
typedef struct {
    ap_errorlog_handler_fn_t *func;
    const char *arg;
    unsigned int flags;
    unsigned int min_loglevel;
} ap_errorlog_format_item;
typedef void ap_HOOK_error_log_t (const ap_errorlog_info *info, const char *errstr); void ap_hook_error_log(ap_HOOK_error_log_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); void ap_run_error_log (const ap_errorlog_info *info, const char *errstr); apr_array_header_t * ap_hook_get_error_log(void); typedef struct ap_LINK_error_log_t { ap_HOOK_error_log_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_error_log_t;
void ap_register_log_hooks(apr_pool_t *p);
void ap_register_config_hooks(apr_pool_t *p);
typedef const char * (apr_OFN_ap_ident_lookup_t) (request_rec *r);
typedef int (apr_OFN_authz_some_auth_required_t) (request_rec *r);
typedef const char * (apr_OFN_authn_ap_auth_type_t) (request_rec *r);
typedef const char * (apr_OFN_authn_ap_auth_name_t) (request_rec *r);
typedef int (apr_OFN_access_compat_ap_satisfies_t) (request_rec *r);
int ap_state_query(int query_code);
typedef apr_status_t ap_HOOK_get_pollfd_from_conn_t (conn_rec *c, struct apr_pollfd_t *pfd, apr_interval_time_t *ptimeout); void ap_hook_get_pollfd_from_conn(ap_HOOK_get_pollfd_from_conn_t *pf, const char * const *aszPre, const char * const *aszSucc, int nOrder); apr_status_t ap_run_get_pollfd_from_conn (conn_rec *c, struct apr_pollfd_t *pfd, apr_interval_time_t *ptimeout); apr_array_header_t * ap_hook_get_get_pollfd_from_conn(void); typedef struct ap_LINK_get_pollfd_from_conn_t { ap_HOOK_get_pollfd_from_conn_t *pFunc; const char *szName; const char * const *aszPredecessors; const char * const *aszSuccessors; int nOrder; } ap_LINK_get_pollfd_from_conn_t;
apr_status_t ap_get_pollfd_from_conn(conn_rec *c,
                                      struct apr_pollfd_t *pfd,
                                      apr_interval_time_t *ptimeout);
struct h2_conn_ctx_t;
extern apr_OFN_ap_logio_add_bytes_in_t *h2_c_logio_add_bytes_in;
extern apr_OFN_ap_logio_add_bytes_out_t *h2_c_logio_add_bytes_out;
apr_status_t h2_c1_child_init(apr_pool_t *pool, server_rec *s);
apr_status_t h2_c1_setup(conn_rec *c, request_rec *r, server_rec *s);
apr_status_t h2_c1_run(conn_rec *c);
apr_status_t h2_c1_pre_close(struct h2_conn_ctx_t *ctx, conn_rec *c);
int h2_c1_allows_direct(conn_rec *c);
int h2_c1_can_upgrade(request_rec *r);
void h2_c1_register_hooks(void);
void h2_c1_child_stopping(apr_pool_t *pool, int graceful);
const char *h2_conn_mpm_name(void);
int h2_mpm_supported(void);
apr_status_t h2_c2_child_init(apr_pool_t *pool, server_rec *s);
conn_rec *h2_c2_create(conn_rec *c1, apr_pool_t *parent,
                       apr_bucket_alloc_t *buckt_alloc);
apr_status_t h2_c2_process(conn_rec *c, apr_thread_t *thread, int worker_id);
void h2_c2_destroy(conn_rec *c2);
void h2_c2_abort(conn_rec *c2, conn_rec *from);
void h2_c2_register_hooks(void);
struct h2_config;
struct h2_session;
typedef struct {
    struct h2_session *session;
    apr_bucket_brigade *output;
    int unflushed;
    apr_time_t cooldown_usecs;
    apr_int64_t warmup_size;
    apr_size_t write_size;
    apr_time_t last_write;
    apr_int64_t bytes_read;
    apr_int64_t bytes_written;
    apr_off_t buffered_len;
    apr_off_t flush_threshold;
    unsigned int is_flushed : 1;
    unsigned int is_passing : 1;
    char *scratch;
    apr_size_t ssize;
    apr_size_t slen;
} h2_c1_io;
apr_status_t h2_c1_io_init(h2_c1_io *io, struct h2_session *session);
apr_status_t h2_c1_io_add_data(h2_c1_io *io,
                         const char *buf,
                         size_t length);
apr_status_t h2_c1_io_add(h2_c1_io *io, apr_bucket *b);
apr_status_t h2_c1_io_append(h2_c1_io *io, apr_bucket_brigade *bb);
apr_status_t h2_c1_io_pass(h2_c1_io *io);
apr_status_t h2_c1_io_assure_flushed(h2_c1_io *io);
int h2_c1_io_needs_flush(h2_c1_io *io);
int h2_c1_io_pending(h2_c1_io *io);
struct h2_session;
apr_status_t h2_c1_read(struct h2_session *session);
struct h2_request;
struct nghttp2_frame;
size_t h2_util_hex_dump(char *buffer, size_t maxlen,
                        const char *data, size_t datalen);
void h2_util_camel_case_header(char *s, size_t len);
int h2_util_frame_print(const nghttp2_frame *frame, char *buffer, size_t maxlen);
typedef struct h2_ihash_t h2_ihash_t;
typedef int h2_ihash_iter_t(void *ctx, void *val);
h2_ihash_t *h2_ihash_create(apr_pool_t *pool, size_t offset_of_int);
unsigned int h2_ihash_count(h2_ihash_t *ih);
int h2_ihash_empty(h2_ihash_t *ih);
void *h2_ihash_get(h2_ihash_t *ih, int id);
int h2_ihash_iter(h2_ihash_t *ih, h2_ihash_iter_t *fn, void *ctx);
void h2_ihash_add(h2_ihash_t *ih, void *val);
void h2_ihash_remove(h2_ihash_t *ih, int id);
void h2_ihash_remove_val(h2_ihash_t *ih, void *val);
void h2_ihash_clear(h2_ihash_t *ih);
size_t h2_ihash_shift(h2_ihash_t *ih, void **buffer, size_t max);
typedef struct h2_iqueue {
    int *elts;
    int head;
    int nelts;
    int nalloc;
    apr_pool_t *pool;
} h2_iqueue;
typedef int h2_iq_cmp(int i1, int i2, void *ctx);
h2_iqueue *h2_iq_create(apr_pool_t *pool, int capacity);
int h2_iq_empty(h2_iqueue *q);
int h2_iq_count(h2_iqueue *q);
int h2_iq_add(h2_iqueue *q, int sid, h2_iq_cmp *cmp, void *ctx);
int h2_iq_append(h2_iqueue *q, int sid);
int h2_iq_remove(h2_iqueue *q, int sid);
void h2_iq_clear(h2_iqueue *q);
void h2_iq_sort(h2_iqueue *q, h2_iq_cmp *cmp, void *ctx);
int h2_iq_shift(h2_iqueue *q);
size_t h2_iq_mshift(h2_iqueue *q, int *pint, size_t max);
int h2_iq_contains(h2_iqueue *q, int sid);
typedef struct h2_fifo h2_fifo;
apr_status_t h2_fifo_create(h2_fifo **pfifo, apr_pool_t *pool, int capacity);
apr_status_t h2_fifo_set_create(h2_fifo **pfifo, apr_pool_t *pool, int capacity);
apr_status_t h2_fifo_term(h2_fifo *fifo);
int h2_fifo_count(h2_fifo *fifo);
apr_status_t h2_fifo_push(h2_fifo *fifo, void *elem);
apr_status_t h2_fifo_try_push(h2_fifo *fifo, void *elem);
apr_status_t h2_fifo_pull(h2_fifo *fifo, void **pelem);
apr_status_t h2_fifo_try_pull(h2_fifo *fifo, void **pelem);
typedef enum {
    H2_FIFO_OP_PULL,
    H2_FIFO_OP_REPUSH,
} h2_fifo_op_t;
typedef h2_fifo_op_t h2_fifo_peek_fn(void *head, void *ctx);
apr_status_t h2_fifo_peek(h2_fifo *fifo, h2_fifo_peek_fn *fn, void *ctx);
apr_status_t h2_fifo_try_peek(h2_fifo *fifo, h2_fifo_peek_fn *fn, void *ctx);
apr_status_t h2_fifo_remove(h2_fifo *fifo, void *elem);
typedef struct h2_ififo h2_ififo;
apr_status_t h2_ififo_create(h2_ififo **pfifo, apr_pool_t *pool, int capacity);
apr_status_t h2_ififo_set_create(h2_ififo **pfifo, apr_pool_t *pool, int capacity);
apr_status_t h2_ififo_term(h2_ififo *fifo);
int h2_ififo_count(h2_ififo *fifo);
apr_status_t h2_ififo_push(h2_ififo *fifo, int id);
apr_status_t h2_ififo_try_push(h2_ififo *fifo, int id);
apr_status_t h2_ififo_pull(h2_ififo *fifo, int *pi);
apr_status_t h2_ififo_try_pull(h2_ififo *fifo, int *pi);
typedef h2_fifo_op_t h2_ififo_peek_fn(int head, void *ctx);
apr_status_t h2_ififo_peek(h2_ififo *fifo, h2_ififo_peek_fn *fn, void *ctx);
apr_status_t h2_ififo_try_peek(h2_ififo *fifo, h2_ififo_peek_fn *fn, void *ctx);
apr_status_t h2_ififo_remove(h2_ififo *fifo, int id);
unsigned char h2_log2(unsigned int n);
apr_size_t h2_util_table_bytes(apr_table_t *t, apr_size_t pair_extra);
int h2_ignore_req_trailer(const char *name, size_t len);
int h2_ignore_resp_trailer(const char *name, size_t len);
int h2_push_policy_determine(apr_table_t *headers, apr_pool_t *p, int push_enabled);
apr_size_t h2_util_base64url_decode(const char **decoded,
                                    const char *encoded,
                                    apr_pool_t *pool);
const char *h2_util_base64url_encode(const char *data,
                                     apr_size_t len, apr_pool_t *pool);
int h2_util_ignore_resp_header(const char *name);
typedef struct h2_ngheader {
    nghttp2_nv *nv;
    apr_size_t nvlen;
} h2_ngheader;
apr_status_t h2_res_create_ngtrailer(h2_ngheader **ph, apr_pool_t *p,
                                     struct h2_headers *headers);
apr_status_t h2_res_create_ngheader(h2_ngheader **ph, apr_pool_t *p,
                                    struct h2_headers *headers);
apr_status_t h2_req_create_ngheader(h2_ngheader **ph, apr_pool_t *p,
                                    const struct h2_request *req);
typedef struct h2_hd_scratch {
    size_t max_len;
    char *name;
    char *value;
} h2_hd_scratch;
apr_status_t h2_req_add_header(apr_table_t *headers, apr_pool_t *pool,
                               const char *name, size_t nlen,
                               const char *value, size_t vlen,
                               h2_hd_scratch *scratch, int *pwas_added);
apr_status_t h2_brigade_concat_length(apr_bucket_brigade *dest,
                                      apr_bucket_brigade *src,
                                      apr_off_t length);
apr_status_t h2_brigade_copy_length(apr_bucket_brigade *dest,
                                    apr_bucket_brigade *src,
                                    apr_off_t length);
typedef apr_status_t h2_util_pass_cb(void *ctx,
                                     const char *data, apr_off_t len);
apr_size_t h2_util_bucket_print(char *buffer, apr_size_t bmax,
                                apr_bucket *b, const char *sep);
apr_size_t h2_util_bb_print(char *buffer, apr_size_t bmax,
                            const char *tag, const char *sep,
                            apr_bucket_brigade *bb);
typedef int h2_bucket_gate(apr_bucket *b);
apr_status_t h2_append_brigade(apr_bucket_brigade *to,
                               apr_bucket_brigade *from,
                               apr_off_t *plen,
                               int *peos,
                               h2_bucket_gate *should_append);
apr_off_t h2_brigade_mem_size(apr_bucket_brigade *bb);
void h2_util_drain_pipe(apr_file_t *pipe);
apr_status_t h2_util_wait_on_pipe(apr_file_t *pipe);
struct apr_thread_mutext_t;
struct apr_thread_cond_t;
struct h2_ctx;
struct h2_config;
struct h2_ihash_t;
struct h2_mplx;
struct h2_priority;
struct h2_push;
struct h2_push_diary;
struct h2_session;
struct h2_stream;
struct h2_stream_monitor;
struct h2_workers;
struct nghttp2_session;
typedef enum {
    H2_SESSION_EV_INIT,
    H2_SESSION_EV_INPUT_PENDING,
    H2_SESSION_EV_INPUT_EXHAUSTED,
    H2_SESSION_EV_LOCAL_GOAWAY,
    H2_SESSION_EV_REMOTE_GOAWAY,
    H2_SESSION_EV_CONN_ERROR,
    H2_SESSION_EV_PROTO_ERROR,
    H2_SESSION_EV_CONN_TIMEOUT,
    H2_SESSION_EV_NGH2_DONE,
    H2_SESSION_EV_MPM_STOPPING,
    H2_SESSION_EV_PRE_CLOSE,
    H2_SESSION_EV_NO_MORE_STREAMS,
    H2_SESSION_EV_BAD_CLIENT,
} h2_session_event_t;
typedef struct h2_session {
    int child_num;
    apr_uint32_t id;
    conn_rec *c1;
    request_rec *r;
    server_rec *s;
    apr_pool_t *pool;
    struct h2_mplx *mplx;
    struct h2_workers *workers;
    struct h2_c1_io_in_ctx_t *cin;
    h2_c1_io io;
    unsigned int padding_max;
    int padding_always;
    struct nghttp2_session *ngh2;
    h2_session_state state;
    h2_session_props local;
    h2_session_props remote;
    unsigned int reprioritize : 1;
    unsigned int flush : 1;
    apr_interval_time_t wait_us;
    struct h2_push_diary *push_diary;
    struct h2_stream_monitor *monitor;
    unsigned int open_streams;
    unsigned int streams_done;
    unsigned int responses_submitted;
    unsigned int streams_reset;
    unsigned int pushes_promised;
    unsigned int pushes_submitted;
    unsigned int pushes_reset;
    unsigned int max_stream_errors;
    unsigned int stream_errors;
    apr_size_t frames_received;
    apr_size_t frames_sent;
    apr_size_t max_stream_count;
    apr_size_t max_stream_mem;
    apr_size_t max_data_frame_len;
    apr_size_t idle_frames;
    apr_interval_time_t idle_delay;
    apr_bucket_brigade *bbtmp;
    char status[64];
    int last_status_code;
    const char *last_status_msg;
    int input_flushed;
    struct h2_iqueue *out_c1_blocked;
    struct h2_iqueue *ready_to_process;
    h2_hd_scratch hd_scratch;
} h2_session;
const char *h2_session_state_str(h2_session_state state);
apr_status_t h2_session_create(h2_session **psession,
                               conn_rec *c, request_rec *r, server_rec *,
                               struct h2_workers *workers);
void h2_session_event(h2_session *session, h2_session_event_t ev,
                      int err, const char *msg);
apr_status_t h2_session_process(h2_session *session, int async, int *pkeepalive);
apr_status_t h2_session_pre_close(h2_session *session, int async);
void h2_session_abort(h2_session *session, apr_status_t reason);
int h2_session_push_enabled(h2_session *session);
struct h2_stream *h2_session_push(h2_session *session,
                                  struct h2_stream *is, struct h2_push *push);
apr_status_t h2_session_set_prio(h2_session *session,
                                 struct h2_stream *stream,
                                 const struct h2_priority *prio);
void h2_session_dispatch_event(h2_session *session, h2_session_event_t ev,
                               int arg, const char *msg);
typedef enum {
    H2_CONF_MAX_STREAMS,
    H2_CONF_WIN_SIZE,
    H2_CONF_MIN_WORKERS,
    H2_CONF_MAX_WORKERS,
    H2_CONF_MAX_WORKER_IDLE_LIMIT,
    H2_CONF_STREAM_MAX_MEM,
    H2_CONF_DIRECT,
    H2_CONF_MODERN_TLS_ONLY,
    H2_CONF_UPGRADE,
    H2_CONF_TLS_WARMUP_SIZE,
    H2_CONF_TLS_COOLDOWN_SECS,
    H2_CONF_PUSH,
    H2_CONF_PUSH_DIARY_SIZE,
    H2_CONF_COPY_FILES,
    H2_CONF_EARLY_HINTS,
    H2_CONF_PADDING_BITS,
    H2_CONF_PADDING_ALWAYS,
    H2_CONF_OUTPUT_BUFFER,
    H2_CONF_STREAM_TIMEOUT,
    H2_CONF_MAX_DATA_FRAME_LEN,
    H2_CONF_PROXY_REQUESTS,
    H2_CONF_WEBSOCKETS,
    H2_CONF_MAX_HEADER_BLOCK_LEN,
    H2_CONF_MAX_STREAM_ERRORS,
} h2_config_var_t;
struct apr_hash_t;
struct h2_priority;
struct h2_push_res;
typedef struct h2_push_res {
    const char *uri_ref;
    int critical;
} h2_push_res;
void *h2_config_create_dir(apr_pool_t *pool, char *x);
void *h2_config_merge_dir(apr_pool_t *pool, void *basev, void *addv);
void *h2_config_create_svr(apr_pool_t *pool, server_rec *s);
void *h2_config_merge_svr(apr_pool_t *pool, void *basev, void *addv);
extern const command_rec h2_cmds[];
int h2_config_geti(request_rec *r, server_rec *s, h2_config_var_t var);
apr_int64_t h2_config_geti64(request_rec *r, server_rec *s, h2_config_var_t var);
int h2_config_cgeti(conn_rec *c, h2_config_var_t var);
apr_int64_t h2_config_cgeti64(conn_rec *c, h2_config_var_t var);
int h2_config_sgeti(server_rec *s, h2_config_var_t var);
apr_int64_t h2_config_sgeti64(server_rec *s, h2_config_var_t var);
int h2_config_rgeti(request_rec *r, h2_config_var_t var);
apr_int64_t h2_config_rgeti64(request_rec *r, h2_config_var_t var);
apr_array_header_t *h2_config_push_list(request_rec *r);
apr_table_t *h2_config_early_headers(request_rec *r);
void h2_get_workers_config(server_rec *s, int *pminw, int *pmaxw,
                           apr_time_t *pidle_limit);
void h2_config_init(apr_pool_t *pool);
const struct h2_priority *h2_cconfig_get_priority(conn_rec *c, const char *content_type);
struct h2_session;
struct h2_stream;
struct h2_mplx;
struct h2_bucket_beam;
struct h2_response_parser;
struct h2_c2_transit;
struct h2_conn_ctx_t {
    const char *id;
    server_rec *server;
    const char *protocol;
    struct h2_session *session;
    struct h2_mplx *mplx;
    struct h2_c2_transit *transit;
    int pre_conn_done;
    int stream_id;
    apr_pool_t *req_pool;
    const struct h2_request *request;
    struct h2_bucket_beam *beam_out;
    struct h2_bucket_beam *beam_in;
    unsigned input_chunked:1;
    unsigned is_upgrade:1;
    apr_file_t *pipe_in[2];
    apr_pollfd_t pfd;
    int has_final_response;
    apr_status_t last_err;
    apr_off_t bytes_sent;
                 apr_uint32_t started;
    apr_time_t started_at;
                 apr_uint32_t done;
    apr_time_t done_at;
};
typedef struct h2_conn_ctx_t h2_conn_ctx_t;
h2_conn_ctx_t *h2_conn_ctx_create_for_c1(conn_rec *c, server_rec *s, const char *protocol);
void h2_conn_ctx_assign_session(h2_conn_ctx_t *ctx, struct h2_session *session);
apr_status_t h2_conn_ctx_init_for_c2(h2_conn_ctx_t **pctx, conn_rec *c,
                                     struct h2_mplx *mplx, struct h2_stream *stream,
                                     struct h2_c2_transit *transit);
void h2_conn_ctx_detach(conn_rec *c);
void h2_conn_ctx_set_timeout(h2_conn_ctx_t *conn_ctx, apr_interval_time_t timeout);
extern const char *h2_protocol_ids_clear[];
extern const char *h2_protocol_ids_tls[];
const char *h2_protocol_err_description(unsigned int h2_error);
apr_status_t h2_protocol_init(apr_pool_t *pool, server_rec *s);
int h2_protocol_is_acceptable_c1(conn_rec *c, request_rec *r, int require_all);
struct apr_pool_t;
struct apr_thread_mutex_t;
struct apr_thread_cond_t;
struct h2_bucket_beam;
struct h2_config;
struct h2_ihash_t;
struct h2_stream;
struct h2_request;
struct apr_thread_cond_t;
struct h2_workers;
struct h2_iqueue;
typedef struct apr_queue_t apr_queue_t;
apr_status_t apr_queue_create(apr_queue_t **queue,
                                           unsigned int queue_capacity,
                                           apr_pool_t *a);
apr_status_t apr_queue_push(apr_queue_t *queue, void *data);
apr_status_t apr_queue_pop(apr_queue_t *queue, void **data);
apr_status_t apr_queue_trypush(apr_queue_t *queue, void *data);
apr_status_t apr_queue_trypop(apr_queue_t *queue, void **data);
unsigned int apr_queue_size(apr_queue_t *queue);
apr_status_t apr_queue_interrupt_all(apr_queue_t *queue);
apr_status_t apr_queue_term(apr_queue_t *queue);
struct apr_thread_mutex_t;
struct apr_thread_cond_t;
struct h2_mplx;
struct h2_request;
struct h2_fifo;
typedef struct h2_workers h2_workers;
h2_workers *h2_workers_create(server_rec *s, apr_pool_t *pool,
                              int max_slots, int min_active, apr_time_t idle_limit);
void h2_workers_shutdown(h2_workers *workers, int graceful);
apr_uint32_t h2_workers_get_max_workers(h2_workers *workers);
typedef struct ap_conn_producer_t ap_conn_producer_t;
typedef conn_rec *ap_conn_producer_next(void *baton, int *pmore);
typedef void ap_conn_producer_done(void *baton, conn_rec *conn);
typedef void ap_conn_producer_shutdown(void *baton, int graceful);
ap_conn_producer_t *h2_workers_register(h2_workers *workers,
                                        apr_pool_t *producer_pool,
                                        const char *name,
                                        ap_conn_producer_next *fn_next,
                                        ap_conn_producer_done *fn_done,
                                        ap_conn_producer_shutdown *fn_shutdown,
                                        void *baton);
apr_status_t h2_workers_join(h2_workers *workers, ap_conn_producer_t *producer);
apr_status_t h2_workers_activate(h2_workers *workers, ap_conn_producer_t *producer);
typedef struct h2_c2_transit h2_c2_transit;
struct h2_c2_transit {
    apr_pool_t *pool;
    apr_bucket_alloc_t *bucket_alloc;
};
typedef struct h2_mplx h2_mplx;
struct h2_mplx {
    int child_num;
    apr_uint32_t id;
    conn_rec *c1;
    apr_pool_t *pool;
    int in_stream_cleanup;
    struct h2_stream *stream0;
    server_rec *s;
    int shutdown;
    int aborted;
    int polling;
    ap_conn_producer_t *producer;
    struct h2_ihash_t *streams;
    struct h2_ihash_t *shold;
    apr_array_header_t *spurge;
    struct h2_iqueue *q;
    apr_size_t stream_max_mem;
    apr_uint32_t max_streams;
    apr_uint32_t max_stream_id_started;
    apr_uint32_t processing_count;
    apr_uint32_t processing_limit;
    apr_uint32_t processing_max;
    apr_time_t last_mood_change;
    apr_interval_time_t mood_update_interval;
    apr_uint32_t irritations_since;
    apr_thread_mutex_t *lock;
    struct apr_thread_cond_t *join_wait;
    apr_pollset_t *pollset;
    apr_array_header_t *streams_ev_in;
    apr_array_header_t *streams_ev_out;
    apr_thread_mutex_t *poll_lock;
    struct h2_iqueue *streams_input_read;
    struct h2_iqueue *streams_output_written;
    struct h2_workers *workers;
    apr_uint32_t max_spare_transits;
    apr_array_header_t *c2_transits;
};
apr_status_t h2_mplx_c1_child_init(apr_pool_t *pool, server_rec *s);
h2_mplx *h2_mplx_c1_create(int child_id, apr_uint32_t id,
                           struct h2_stream *stream0,
                           server_rec *s, apr_pool_t *master,
                           struct h2_workers *workers);
void h2_mplx_c1_destroy(h2_mplx *m);
int h2_mplx_c1_shutdown(h2_mplx *m);
apr_status_t h2_mplx_c1_stream_cleanup(h2_mplx *m, struct h2_stream *stream,
                                       unsigned int *pstream_count);
int h2_mplx_c1_stream_is_running(h2_mplx *m, struct h2_stream *stream);
void h2_mplx_c1_process(h2_mplx *m,
                        struct h2_iqueue *read_to_process,
                        h2_stream_get_fn *get_stream,
                        h2_stream_pri_cmp_fn *cmp,
                        struct h2_session *session,
                        unsigned int *pstream_count);
apr_status_t h2_mplx_c1_reprioritize(h2_mplx *m, h2_stream_pri_cmp_fn *cmp,
                                    struct h2_session *session);
typedef void stream_ev_callback(void *ctx, struct h2_stream *stream);
apr_status_t h2_mplx_c1_poll(h2_mplx *m, apr_interval_time_t timeout,
                            stream_ev_callback *on_stream_input,
                            stream_ev_callback *on_stream_output,
                            void *on_ctx);
void h2_mplx_c2_input_read(h2_mplx *m, conn_rec *c2);
void h2_mplx_c2_output_written(h2_mplx *m, conn_rec *c2);
typedef int h2_mplx_stream_cb(struct h2_stream *s, void *userdata);
apr_status_t h2_mplx_c1_streams_do(h2_mplx *m, h2_mplx_stream_cb *cb, void *ctx);
int h2_mplx_c1_all_streams_want_send_data(h2_mplx *m);
int h2_mplx_c1_all_streams_send_win_exhausted(h2_mplx *m);
apr_status_t h2_mplx_c1_client_rst(h2_mplx *m, int stream_id,
                                   struct h2_stream *stream);
const struct h2_stream *h2_mplx_c2_stream_get(h2_mplx *m, int stream_id);
apr_status_t h2_mplx_worker_pop_c2(h2_mplx *m, conn_rec **out_c2);
void h2_mplx_c1_going_keepalive(h2_mplx *m);
struct h2_request;
struct h2_ngheader;
struct h2_session;
struct h2_stream;
typedef struct h2_push {
    const struct h2_request *req;
    h2_priority *priority;
} h2_push;
typedef enum {
    H2_PUSH_DIGEST_APR_HASH,
    H2_PUSH_DIGEST_SHA256
} h2_push_digest_type;
typedef struct h2_push_diary h2_push_diary;
typedef void h2_push_digest_calc(h2_push_diary *diary, apr_uint64_t *phash, h2_push *push);
struct h2_push_diary {
    apr_array_header_t *entries;
    int NMax;
    int N;
    apr_uint64_t mask;
    unsigned int mask_bits;
    const char *authority;
    h2_push_digest_type dtype;
    h2_push_digest_calc *dcalc;
};
apr_array_header_t *h2_push_collect(apr_pool_t *p,
                                    const struct h2_request *req,
                                    apr_uint32_t push_policy,
                                    const struct h2_headers *res);
h2_push_diary *h2_push_diary_create(apr_pool_t *p, int N);
apr_array_header_t *h2_push_diary_update(struct h2_session *session, apr_array_header_t *pushes);
apr_array_header_t *h2_push_collect_update(struct h2_stream *stream,
                                           const struct h2_request *req,
                                           const struct h2_headers *res);
apr_status_t h2_push_diary_digest_get(h2_push_diary *diary, apr_pool_t *p,
                                      int maxP, const char *authority,
                                      const char **pdata, apr_size_t *plen);
struct h2_hd_scratch;
h2_request *h2_request_create(int id, apr_pool_t *pool, const char *method,
                              const char *scheme, const char *authority,
                              const char *path, apr_table_t *header);
apr_status_t h2_request_rcreate(h2_request **preq, apr_pool_t *pool,
                                request_rec *r,
                                struct h2_hd_scratch *scratch);
apr_status_t h2_request_add_header(h2_request *req, apr_pool_t *pool,
                                   const char *name, size_t nlen,
                                   const char *value, size_t vlen,
                                   struct h2_hd_scratch *scratch,
                                   int *pwas_added);
apr_status_t h2_request_add_trailer(h2_request *req, apr_pool_t *pool,
                                    const char *name, size_t nlen,
                                    const char *value, size_t vlen);
apr_status_t h2_request_end_headers(h2_request *req, apr_pool_t *pool,
                                     size_t raw_bytes);
h2_request *h2_request_clone(apr_pool_t *p, const h2_request *src);
request_rec *h2_create_request_rec(const h2_request *req, conn_rec *conn,
                                   int no_body);
apr_status_t h2_switch_init(apr_pool_t *pool, server_rec *s);
void h2_switch_register_hooks(void);
struct apr_thread_mutex_t;
struct apr_thread_cond_t;
typedef struct h2_bucket_beam h2_bucket_beam;
typedef void h2_beam_io_callback(void *ctx, h2_bucket_beam *beam,
                                 apr_off_t bytes);
typedef void h2_beam_ev_callback(void *ctx, h2_bucket_beam *beam);
typedef struct {
    struct h2_bucket_list { struct apr_bucket * volatile next; struct apr_bucket * volatile prev; } list;
} h2_blist;
struct h2_bucket_beam {
    int id;
    const char *name;
    conn_rec *from;
    apr_pool_t *pool;
    h2_blist buckets_to_send;
    h2_blist buckets_consumed;
    h2_blist buckets_eor;
    apr_size_t max_buf_size;
    apr_interval_time_t timeout;
    int aborted;
    int closed;
    int tx_mem_limits;
    int copy_files;
    struct apr_thread_mutex_t *lock;
    struct apr_thread_cond_t *change;
    h2_beam_ev_callback *was_empty_cb;
    void *was_empty_ctx;
    h2_beam_ev_callback *recv_cb;
    void *recv_ctx;
    h2_beam_ev_callback *send_cb;
    void *send_ctx;
    h2_beam_ev_callback *eagain_cb;
    void *eagain_ctx;
    apr_off_t recv_bytes;
    apr_off_t recv_bytes_reported;
    h2_beam_io_callback *cons_io_cb;
    void *cons_ctx;
};
apr_status_t h2_beam_create(h2_bucket_beam **pbeam,
                            conn_rec *from,
                            apr_pool_t *pool,
                            int id, const char *tag,
                            apr_size_t buffer_size,
                            apr_interval_time_t timeout);
apr_status_t h2_beam_destroy(h2_bucket_beam *beam, conn_rec *c);
void h2_beam_set_copy_files(h2_bucket_beam * beam, int enabled);
apr_status_t h2_beam_send(h2_bucket_beam *beam, conn_rec *from,
                          apr_bucket_brigade *bb,
                          apr_read_type_e block,
                          apr_off_t *pwritten);
apr_status_t h2_beam_receive(h2_bucket_beam *beam, conn_rec *to,
                             apr_bucket_brigade *bb,
                             apr_read_type_e block,
                             apr_off_t readbytes);
int h2_beam_empty(h2_bucket_beam *beam);
void h2_beam_abort(h2_bucket_beam *beam, conn_rec *c);
void h2_beam_close(h2_bucket_beam *beam, conn_rec *c);
void h2_beam_timeout_set(h2_bucket_beam *beam,
                         apr_interval_time_t timeout);
apr_interval_time_t h2_beam_timeout_get(h2_bucket_beam *beam);
void h2_beam_buffer_size_set(h2_bucket_beam *beam,
                             apr_size_t buffer_size);
apr_size_t h2_beam_buffer_size_get(h2_bucket_beam *beam);
void h2_beam_on_consumed(h2_bucket_beam *beam,
                         h2_beam_io_callback *io_cb, void *ctx);
void h2_beam_on_received(h2_bucket_beam *beam,
                         h2_beam_ev_callback *recv_cb, void *ctx);
void h2_beam_on_eagain(h2_bucket_beam *beam,
                       h2_beam_ev_callback *eagain_cb, void *ctx);
void h2_beam_on_send(h2_bucket_beam *beam,
                     h2_beam_ev_callback *on_send_cb, void *ctx);
void h2_beam_on_was_empty(h2_bucket_beam *beam,
                          h2_beam_ev_callback *was_empty_cb, void *ctx);
int h2_beam_report_consumption(h2_bucket_beam *beam);
apr_off_t h2_beam_get_buffered(h2_bucket_beam *beam);
apr_off_t h2_beam_get_mem_used(h2_bucket_beam *beam);
int h2_beam_is_complete(h2_bucket_beam *beam);
const h2_request *h2_ws_rewrite_request(const h2_request *req,
                                        conn_rec *c2, int no_body);
void h2_ws_register_hooks(void);
static void h2_hooks(apr_pool_t *pool);
extern module http2_module; static int * const aplog_module_index __attribute__((unused)) = &(http2_module.module_index); module http2_module = {
    20120211, 142, -1, "/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c", ((void *)0), ((void *)0), 0x41503234UL, ((void *)0),
    h2_config_create_dir,
    h2_config_merge_dir,
    h2_config_create_svr,
    h2_config_merge_svr,
    h2_cmds,
    h2_hooks,
    (1 << 0)
};
static int h2_h2_fixups(request_rec *r);
typedef struct {
    unsigned int change_prio : 1;
    unsigned int sha256 : 1;
    unsigned int inv_headers : 1;
    unsigned int dyn_windows : 1;
} features;
static features myfeats;
static int mpm_warned;
static int h2_post_config(apr_pool_t *p, apr_pool_t *plog,
                          apr_pool_t *ptemp, server_rec *s)
{
    void *data = ((void *)0);
    const char *mod_h2_init_key = "mod_http2_init_counter";
    nghttp2_info *ngh2;
    apr_status_t status;
    (void)plog;(void)ptemp;
    myfeats.change_prio = 1;
    myfeats.sha256 = 1;
    myfeats.inv_headers = 1;
    myfeats.dyn_windows = 1;
    apr_pool_userdata_get(&data, mod_h2_init_key, s->process->pool);
    if ( data == ((void *)0) ) {
        do { const server_rec *sr__ = s; if (( (((7)&15) <= 5) || (sr__ == ((void *)0)) || ((((((aplog_module_index ? *aplog_module_index : -1)) < 0 || (&(sr__)->log)->module_levels == ((void *)0) || (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)] < 0) ? (&(sr__)->log)->level : (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)])) >= ((7)&15) ) )) ap_log_error_("/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c", 112, (aplog_module_index ? *aplog_module_index : -1), 7, 0, sr__, "AH" "03089" ": " "initializing post config dry run"); } while(0);
        apr_pool_userdata_set((const void *)1, mod_h2_init_key,
                              apr_pool_cleanup_null, s->process->pool);
        return 0;
    }
    ngh2 = nghttp2_version(0);
    do { const server_rec *sr__ = s; if (( (((6)&15) <= 5) || (sr__ == ((void *)0)) || ((((((aplog_module_index ? *aplog_module_index : -1)) < 0 || (&(sr__)->log)->module_levels == ((void *)0) || (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)] < 0) ? (&(sr__)->log)->level : (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)])) >= ((6)&15) ) )) ap_log_error_("/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c", 120, (aplog_module_index ? *aplog_module_index : -1), 6, 0, sr__, "AH" "03090" ": " "mod_http2 (v%s, feats=%s%s%s%s, nghttp2 %s), initializing...", "2.0.42", myfeats.change_prio? "CHPRIO" : "", myfeats.sha256? "+SHA256" : "", myfeats.inv_headers? "+INVHD" : "", myfeats.dyn_windows? "+DWINS" : "", ngh2? ngh2->version_str : "unknown"); } while(0);
    if (!h2_mpm_supported() && !mpm_warned) {
        mpm_warned = 1;
        do { const server_rec *sr__ = s; if (( (((4)&15) <= 5) || (sr__ == ((void *)0)) || ((((((aplog_module_index ? *aplog_module_index : -1)) < 0 || (&(sr__)->log)->module_levels == ((void *)0) || (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)] < 0) ? (&(sr__)->log)->level : (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)])) >= ((4)&15) ) )) ap_log_error_("/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c", 131, (aplog_module_index ? *aplog_module_index : -1), 4, 0, sr__, "AH" "10034" ": " "The mpm module (%s) is not supported by mod_http2. The mpm determines " "how things are processed in your server. HTTP/2 has more demands in " "this regard and the currently selected mpm will just not do. " "This is an advisory warning. Your server will continue to work, but " "the HTTP/2 protocol will be inactive.", h2_conn_mpm_name()); } while(0);
    }
    status = h2_protocol_init(p, s);
    if (status == 0) {
        status = h2_switch_init(p, s);
    }
    return status;
}
static char *http2_var_lookup(apr_pool_t *, server_rec *,
                         conn_rec *, request_rec *, char *name);
static int http2_is_h2(conn_rec *);
static void http2_get_num_workers(server_rec *s, int *minw, int *maxw)
{
    apr_time_t tdummy;
    h2_get_workers_config(s, minw, maxw, &tdummy);
}
static void h2_child_init(apr_pool_t *pchild, server_rec *s)
{
    apr_status_t rv;
    rv = h2_c1_child_init(pchild, s);
    if (0 == rv) {
        rv = h2_c2_child_init(pchild, s);
    }
    if (0 != rv) {
        do { const server_rec *sr__ = s; if (( (((3)&15) <= 5) || (sr__ == ((void *)0)) || ((((((aplog_module_index ? *aplog_module_index : -1)) < 0 || (&(sr__)->log)->module_levels == ((void *)0) || (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)] < 0) ? (&(sr__)->log)->level : (&(sr__)->log)->module_levels[(aplog_module_index ? *aplog_module_index : -1)])) >= ((3)&15) ) )) ap_log_error_("/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c", 172, (aplog_module_index ? *aplog_module_index : -1), 3, rv, sr__, "AH" "02949" ": " "initializing connection handling"); } while(0);
    }
}
static void h2_hooks(apr_pool_t *pool)
{
    static const char *const mod_ssl[] = { "mod_ssl.c", ((void *)0)};
    do { apr_OFN_http2_is_h2_t *apu__opt = http2_is_h2; apr_dynamic_fn_register("http2_is_h2",(apr_opt_fn_t *)apu__opt); } while (0);
    do { apr_OFN_http2_var_lookup_t *apu__opt = http2_var_lookup; apr_dynamic_fn_register("http2_var_lookup",(apr_opt_fn_t *)apu__opt); } while (0);
    do { apr_OFN_http2_get_num_workers_t *apu__opt = http2_get_num_workers; apr_dynamic_fn_register("http2_get_num_workers",(apr_opt_fn_t *)apu__opt); } while (0);
    ap_log_perror_("/tmp/claude-1000/-home-alexandre-dev2-test/a20fc3be-f055-4c31-8891-4783a160b8fd/scratchpad/tsan/dl/httpd-2.4.70/modules/http2/mod_http2.c",187,(aplog_module_index ? *aplog_module_index : -1), (7 + 1), 0, pool, "installing hooks");
    ap_hook_post_config(h2_post_config, mod_ssl, ((void *)0), 10);
    ap_hook_child_init(h2_child_init, ((void *)0), ((void *)0), 10);
    ap_hook_child_stopping(h2_c1_child_stopping, ((void *)0), ((void *)0), 10);
    h2_c1_register_hooks();
    h2_switch_register_hooks();
    h2_c2_register_hooks();
    h2_ws_register_hooks();
    ap_hook_fixups(h2_h2_fixups, ((void *)0),((void *)0), 10);
}
static const char *val_HTTP2(apr_pool_t *p, server_rec *s,
                             conn_rec *c, request_rec *r, h2_conn_ctx_t *ctx)
{
    return ctx? "on" : "off";
}
static const char *val_H2_PUSH(apr_pool_t *p, server_rec *s,
                               conn_rec *c, request_rec *r,
                               h2_conn_ctx_t *conn_ctx)
{
    if (conn_ctx) {
        if (r) {
            if (conn_ctx->stream_id) {
                const h2_stream *stream = h2_mplx_c2_stream_get(conn_ctx->mplx, conn_ctx->stream_id);
                if (stream && stream->push_policy != H2_PUSH_NONE) {
                    return "on";
                }
            }
        }
        else if (c && h2_session_push_enabled(conn_ctx->session)) {
            return "on";
        }
    }
    else if (s) {
        if (h2_config_geti(r, s, H2_CONF_PUSH)) {
            return "on";
        }
    }
    return "off";
}
static const char *val_H2_PUSHED(apr_pool_t *p, server_rec *s,
                                 conn_rec *c, request_rec *r,
                                 h2_conn_ctx_t *conn_ctx)
{
    if (conn_ctx) {
        if (conn_ctx->stream_id && !(conn_ctx->stream_id&0x01)) {
            return "PUSHED";
        }
    }
    return "";
}
static const char *val_H2_PUSHED_ON(apr_pool_t *p, server_rec *s,
                                    conn_rec *c, request_rec *r,
                                    h2_conn_ctx_t *conn_ctx)
{
    if (conn_ctx) {
        if (conn_ctx->stream_id && !(conn_ctx->stream_id&0x01)) {
            const h2_stream *stream = h2_mplx_c2_stream_get(conn_ctx->mplx, conn_ctx->stream_id);
            if (stream) {
                return apr_itoa(p, stream->initiated_on);
            }
        }
    }
    return "";
}
static const char *val_H2_STREAM_TAG(apr_pool_t *p, server_rec *s,
                                     conn_rec *c, request_rec *r, h2_conn_ctx_t *ctx)
{
    if (c) {
        h2_conn_ctx_t *conn_ctx = ((c)? (h2_conn_ctx_t*)(((void **)((c)->conn_config))[(&http2_module)->module_index]) : ((void *)0));
        if (conn_ctx) {
            return conn_ctx->stream_id == 0? conn_ctx->id
               : apr_psprintf(p, "%s-%d", conn_ctx->id, conn_ctx->stream_id);
        }
    }
    return "";
}
static const char *val_H2_STREAM_ID(apr_pool_t *p, server_rec *s,
                                    conn_rec *c, request_rec *r, h2_conn_ctx_t *ctx)
{
    const char *cp = val_H2_STREAM_TAG(p, s, c, r, ctx);
    if (cp && (cp = strrchr(cp, '-'))) {
        return ++cp;
    }
    return ((void *)0);
}
typedef const char *h2_var_lookup(apr_pool_t *p, server_rec *s,
                                  conn_rec *c, request_rec *r, h2_conn_ctx_t *ctx);
typedef struct h2_var_def {
    const char *name;
    h2_var_lookup *lookup;
    unsigned int subprocess : 1;
} h2_var_def;
static h2_var_def H2_VARS[] = {
    { "HTTP2", val_HTTP2, 1 },
    { "H2PUSH", val_H2_PUSH, 1 },
    { "H2_PUSH", val_H2_PUSH, 1 },
    { "H2_PUSHED", val_H2_PUSHED, 1 },
    { "H2_PUSHED_ON", val_H2_PUSHED_ON, 1 },
    { "H2_STREAM_ID", val_H2_STREAM_ID, 1 },
    { "H2_STREAM_TAG", val_H2_STREAM_TAG, 1 },
};
static int http2_is_h2(conn_rec *c)
{
    return ((c->master? c->master : c)? (h2_conn_ctx_t*)(((void **)((c->master? c->master : c)->conn_config))[(&http2_module)->module_index]) : ((void *)0)) != ((void *)0);
}
static char *http2_var_lookup(apr_pool_t *p, server_rec *s,
                              conn_rec *c, request_rec *r, char *name)
{
    unsigned int i;
    for (i = 0; i < (sizeof(H2_VARS)/sizeof((H2_VARS)[0])); ++i) {
        h2_var_def *vdef = &H2_VARS[i];
        if (!strcmp(vdef->name, name)) {
            h2_conn_ctx_t *ctx = (r? ((c)? (h2_conn_ctx_t*)(((void **)((c)->conn_config))[(&http2_module)->module_index]) : ((void *)0)) :
                           ((c->master? c->master : c)? (h2_conn_ctx_t*)(((void **)((c->master? c->master : c)->conn_config))[(&http2_module)->module_index]) : ((void *)0)));
            return (char *)vdef->lookup(p, s, c, r, ctx);
        }
    }
    return (char*)"";
}
static int h2_h2_fixups(request_rec *r)
{
    if (r->connection->master) {
        h2_conn_ctx_t *ctx = ((r->connection)? (h2_conn_ctx_t*)(((void **)((r->connection)->conn_config))[(&http2_module)->module_index]) : ((void *)0));
        unsigned int i;
        for (i = 0; ctx && i < (sizeof(H2_VARS)/sizeof((H2_VARS)[0])); ++i) {
            h2_var_def *vdef = &H2_VARS[i];
            if (vdef->subprocess) {
                apr_table_setn(r->subprocess_env, vdef->name,
                               vdef->lookup(r->pool, r->server, r->connection,
                                            r, ctx));
            }
        }
    }
    return -1;
}
